﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BakeBookerGUI_1._0
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
            // Asigna los eventos Enter y Leave a tus TextBox
            txtUsuario.Enter += TxtUsuario_Enter;
            txtUsuario.Leave += TxtUsuario_Leave;

            txtContraseña.Enter += TxtContraseña_Enter;
            txtContraseña.Leave += TxtContraseña_Leave;

            // Establece el texto de marcador de posición
            TxtUsuario_Leave(null, EventArgs.Empty);
            TxtContraseña_Leave(null, EventArgs.Empty);

        }


        private void label4_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }


        // METODOS Y EVENTOS RELACIONADOS A LOS TXT BOXS DE USUARIO & CONTRASEÑA
        private void txtContraseña_TextChanged(object sender, EventArgs e)
        {
          
        }
        private void TxtUsuario_Enter(object sender, EventArgs e)
        {
            // Borra el texto de marcador de posición al hacer clic
            if (txtUsuario.Text == "Usuario")
            {
                txtUsuario.Text = "";
                txtUsuario.ForeColor = System.Drawing.Color.Black;
            }
        }

        private void TxtUsuario_Leave(object sender, EventArgs e)
        {
            // Restaura el texto de marcador de posición si el campo está vacío
            if (string.IsNullOrWhiteSpace(txtUsuario.Text))
            {
                txtUsuario.Text = "Usuario";
                txtUsuario.ForeColor = System.Drawing.Color.Gray;
            }
        }

        private void TxtContraseña_Enter(object sender, EventArgs e)
        {
            if (txtContraseña.Text == "Contraseña")
            {
                txtContraseña.Text = "";
                txtContraseña.ForeColor = System.Drawing.Color.Black;
                txtContraseña.PasswordChar = '*'; // Mostrar asteriscos para la contraseña
            }
        }

        private void TxtContraseña_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtContraseña.Text))
            {
                txtContraseña.Text = "Contraseña";
                txtContraseña.ForeColor = System.Drawing.Color.Gray;
                txtContraseña.PasswordChar = '\0'; // Mostrar texto plano si el campo está vacío
            }
        }


        //BOTON Y ENLACE PARA INICIAR SESION
        private void btnIniciarSesion_Click_1(object sender, EventArgs e)
        {

            string usuario, contraseña;

            usuario = txtUsuario.Text;
            contraseña = txtContraseña.Text;
            try
            {
                // CONEXION JESUS
                // string connectionString = $"Data Source=IDEAPAD;Initial Catalog=BakeBooker;User ID={usuario};Password={contraseña}";
                //CONEXION USVALDO  Data Source=DESKTOP-I2LH62T\SQLSERVER_DEV;Initial Catalog=BakeBooker;Integrated Security=True
                string connectionString = $"Data Source=IDEAPAD;Initial Catalog=BakeBooker3;User ID={usuario};Password={contraseña}";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();
                        MessageBox.Show("Conexión exitosa a la base de datos.");
                        frmADMIN entrada = new frmADMIN(usuario, contraseña);
                        entrada.Show();
                        this.Hide();
                        // Puedes realizar operaciones adicionales aquí después de establecer la conexión
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error al conectar a la base de datos: " + ex.Message);
                    }
                }

            }
            catch
            {
                MessageBox.Show("error de try catch");
            }


        }
    }
}
