﻿using System;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Diagnostics.Contracts;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace BakeBookerGUI_1._0
{
    public partial class frmADMIN : Form
    {
        private SqlConnection sqlConnection;
        //CONEXION JESUS
        //private string connectionString = "Data Source=IDEAPAD;Initial Catalog=BakeBooker;Integrated Security=True";
        // CONEXION USVALDO
        private string connectionString = @"";
        private string UsuarioRol;
        private string ContraseñaRol;
        private int paginaActual = 0;
        private int paginaActualEmpleado = 0;
        private int paginaActualCliente = 0;
        private int paginaActualPedido = 0;
        private int paginaActualProducto = 0;
        // Variable privada para almacenar la ruta de la imagen
            static int idclienteparabuscar = 1;
        static int idpedidoparabuscar = 1;
        static int IDCLIENTE = 1;
        static int IDPRODUCTO = 1;
        static int CANTIDADPRODUCTO = 1;
        static int IDPEDIDO = 1;
        static int IDPEDIDO2 = 1;
      static  string fototorta = "torta.png";
      static  string rutaDirectorioEjecucion = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
      static  string rutaImagen = Path.Combine(rutaDirectorioEjecucion, fototorta);
        static string NOMBREPEDIDO = "";
        static int ANTICIPOPEDIDO = 0;
        static int TOTALPEDIDO = 0;
        static string FORMAENTREGAPEDIDO = "Recoger";
        static string FOTOORDEN = "";
        static string FOTOORDEN2 = "D:\\Descargas-SSD\\BakeBookerGUI_1.0\\Resources\\torta.png";

        static DateTime FECHAPEDIDO = DateTime.Now;
        static DateTime FECHAENTREGA = DateTime.Now;
        public frmADMIN(string usuario, string contraseña)
        {
            InitializeComponent();
            this.UsuarioRol = usuario;
            this.ContraseñaRol = contraseña;
            //this.connectionString = $"Data Source=IDEAPAD;Initial Catalog=BakeBooker3;User ID={usuario};Password={contraseña}";
            this.connectionString = $"Data Source=IDEAPAD;Initial Catalog=BakeBooker3;User ID={UsuarioRol};Password={ContraseñaRol}";
            VerificarRolUsuario();
           /* using (SqlConnection conexionrol = new SqlConnection(connectionString))
            {
                conexionrol.Open();
            }*/
            sqlConnection = new SqlConnection(connectionString);
            //DgvGeneral.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            //Refrescar();


            // Asigna eventos Click para cada botón del menú central

            btnEmpleados.Click += (sender, e) => CambiarPaginaMenuPrincipal(1);
            btnClientes.Click += (sender, e) => CambiarPaginaMenuPrincipal(2);
            btnPedidos.Click += (sender, e) => CambiarPaginaMenuPrincipal(3);
            btnProductos.Click += (sender, e) => CambiarPaginaMenuPrincipal(4);
            btnReportes.Click += (sender, e) => CambiarPaginaMenuPrincipal(5);

            // Inicialmente, muestra la primera página
            CambiarPaginaMenuPrincipal(0);

            //ASIGNAR EVENTOS CLICK A BOTONES MENU EMPLEADOS

            btnBEMempleado.Click += (sender, e) => CambiarPaginaMenuEmpleado(1);
            btnEmpleadoNuevo.Click += (sender, e) => CambiarPaginaMenuEmpleado(0);
            CambiarPaginaMenuEmpleado(0);

            //ASIGNAR EVENTOS CLICK A BOTONES MENU  Clientes

            btnBEMclientes.Click += (sender, e) => CambiarPaginaMenuCliente(1);
            btnClienteNuevo.Click += (sender, e) => CambiarPaginaMenuCliente(0);
            CambiarPaginaMenuCliente(0);

            //ASIGNAR EVENTOS CLICK A BOTONES MENU  PEDIDOS

            btnBEMPedidos.Click += (sender, e) => CambiarPaginaMenuCliente(1);
            btnIniciarPedido.Click += (sender, e) => CambiarPaginaMenuCliente(0);
            CambiarPaginaMenuPedidos(0);
            DatosIDProducto();
            MostrarProductos();

        }
        private void MostrarProductos()
        {
            try
            {
                string query = $"SELECT * FROM Producto"; // Utiliza el nombre de la tabla proporcionado
                SqlCommand cmd = new SqlCommand(query, sqlConnection);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dgvResultadoProductos.DataSource = dataTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        private void MostrarEmpleados()
        {
            try
            {
                string query = $"SELECT * FROM Empleado"; // Utiliza el nombre de la tabla proporcionado
                SqlCommand cmd = new SqlCommand(query, sqlConnection);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dgvResultadosEmpleados.DataSource = dataTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        private void MostrarPedidosCliente(int IDcliente)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
  
                    string query = "SELECT * FROM Pedido_detalles WHERE ID_pedido = @SelectedID order by ID_detalle DESC";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@SelectedID", IDcliente);
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);
                        DGVListaPedido.DataSource = dataTable;
                    }
                
                
            }
        }
        private void MostrarPedidosCliente2(int IDcliente)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                string query = "SELECT * FROM Pedido_detalles WHERE ID_pedido = @SelectedID order by ID_detalle DESC";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@SelectedID", IDcliente);
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    DGVBUSQUEDADETALLESPEDIDO.DataSource = dataTable;
                }


            }
        }
        private void MostrarPedidos(int IDcliente)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                string query = "SELECT * FROM Pedido WHERE ID_cliente = @SelectedID order by ID_Pedido DESC";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@SelectedID", IDcliente);
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dataGridView1.DataSource = dataTable;
                }


            }
        }
        private void MostrarPedidos2(int IDcliente)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                string query = "SELECT * FROM Pedido WHERE ID_cliente = @SelectedID order by ID_Pedido DESC";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@SelectedID", IDcliente);
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    DGVBUSQUEDAPEDIDO.DataSource = dataTable;
                }


            }
        }
        private void MostrarProductosCliente(int IDcliente)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
               
                    string query = "SELECT * FROM Pedido_Producto WHERE ID_pedido = @SelectedID order by ID_PEDIDOPRODUCTO DESC";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@SelectedID", IDcliente);
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        DGVListaPedido.DataSource = dataTable;
                    }
                
            }
        }
        private void MostrarProductosCliente2(int IDcliente)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                string query = "SELECT * FROM Pedido_Producto WHERE ID_pedido = @SelectedID order by ID_PEDIDOPRODUCTO DESC";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@SelectedID", IDcliente);
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    DGVBUSQUEDADETALLESPEDIDO.DataSource = dataTable;
                }

            }
        }
        private void RefrescarProducto()
        {
            if (CBBNombreProducto.SelectedIndex != -1)
            {
                // Obtiene el valor seleccionado en el ComboBox
                string nombreProducto = CBBNombreProducto.SelectedItem.ToString();

                // Realiza una consulta para obtener otros datos del producto seleccionado
                string consulta = "SELECT * FROM Producto WHERE Nombre = @NombreProducto"; // Ajusta la consulta según tu tabla y estructura
                using (SqlConnection conexion = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(consulta, conexion);
                    cmd.Parameters.AddWithValue("@NombreProducto", nombreProducto);

                    try
                    {
                        conexion.Open();
                        SqlDataReader reader = cmd.ExecuteReader();
                        if (reader.Read())
                        {
                            // Asigna los valores de la base de datos a tus variables
                            int ID_producto = Convert.ToInt32(reader["ID_producto"]);
                            string Nombre = reader["Nombre"].ToString();
                            string Descripcion = reader["Descripcion"].ToString();
                            int Precio = Convert.ToInt32(reader["Precio"]);
                            DateTime Fecha_Ingreso = Convert.ToDateTime(reader["Fecha_Ingreso"]);
                            int Cantidad_Disponible = Convert.ToInt32(reader["Cantidad_Disponible"]);
                            DateTime Fecha_Expiracion = Convert.ToDateTime(reader["Fecha_expiracion"]);
                            string Foto = reader["Foto"].ToString();
                            LBLIDPRODUCTO.Text = ID_producto.ToString();
                            LBLcostoUnitarioProducto.Text = Precio.ToString("C"); // Mostrar el precio unitario formateado como moneda
                            LBLCantidadDisponible.Text = Cantidad_Disponible.ToString();
                            TXTDescripcion.Text = Descripcion.ToString();
                            IDPRODUCTO = ID_producto;
                            pbxImagenPastel.Text = Foto;

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error al obtener datos del producto: " + ex.Message);
                    }
                }
            }
        }
        private void MetodoPedidoDetalle(string operacion)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                     SqlCommand cmd = new SqlCommand("GestionarPedidoDetalles", sqlConnection);
                    cmd.CommandType = CommandType.StoredProcedure;
                    if (operacion == "I")
                    {
                        int? id = null;
                        int id_pedido = IDPEDIDO;
                        int cantidadpisos = CBBCantdidadPisos.SelectedIndex;
                        string tipo_de_pan = txtTipoDePan.Text;
                        string relleno_pan = CBBRellenoPan.SelectedItem.ToString();
                        string tamaño = CBBTamañoPedido.SelectedItem.ToString();
                        int cantidad = Convert.ToInt32(txtCantidaddePersonas.Text);
                        string foto =FOTOORDEN;
                        int precio = Convert.ToInt32(txtPrecioPastel.Text);
                        string Notas = string.IsNullOrEmpty(txtNotasPedido.Text) ? null : txtNotasPedido.Text;

                   
                        cmd.Parameters.AddWithValue("@ID_detalle", id);
                        cmd.Parameters.AddWithValue("@ID_pedido", id_pedido);
                        cmd.Parameters.AddWithValue("@Cantidad_Pisos", cantidadpisos);
                        cmd.Parameters.AddWithValue("@Sabor_Pan", tipo_de_pan);
                        cmd.Parameters.AddWithValue("@Relleno_Pan", relleno_pan);
                        cmd.Parameters.AddWithValue("@Tamaño_Pastel", tamaño);
                        cmd.Parameters.AddWithValue("@Cantidad_personas", cantidad);
                        cmd.Parameters.AddWithValue("@Foto", foto);
                        cmd.Parameters.AddWithValue("@Precio", precio);
                        if (Notas != null)
                        {
                            cmd.Parameters.AddWithValue("@Notas", Notas);
                        }
                        else
                        {
                            cmd.Parameters.AddWithValue("@Notas", DBNull.Value);
                        }
                    }
                    else
                    {
                        int id =Convert.ToInt32(txtIDOrdenModificar.Text);
                        int id_pedido =Convert.ToInt32(txtIDPEDIDOMODIFICAR.Text);
                        int cantidadpisos =Convert.ToInt32(CBBCantidadDePisosModificar.SelectedIndex);
                        string tipo_de_pan = txtTipodePanModificar.Text;
                        string relleno_pan = CBBRellenodePanModificar.SelectedItem.ToString();
                        string tamaño = CBBTamañodePedidoModificar.SelectedItem.ToString();
                        int cantidad = Convert.ToInt32(txtCantidadDePersonasModificar.Text);
                        string fototorta = "torta.png";
                        string rutaDirectorioEjecucion = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
                        string rutaImagen = Path.Combine(rutaDirectorioEjecucion, fototorta);

                        string foto = rutaImagen;
                        if(FOTOORDEN2!="")
                        {
                            foto = FOTOORDEN2;
                        }
                        int precio = Convert.ToInt32(txtPrecioOrdenModificar.Text);
                        string Notas = string.IsNullOrEmpty(txtNotasModificar.Text) ? null : txtNotasPedido.Text;


                       cmd.Parameters.AddWithValue("@ID_detalle", id);
                        cmd.Parameters.AddWithValue("@ID_pedido", id_pedido);
                        cmd.Parameters.AddWithValue("@Cantidad_Pisos", cantidadpisos);
                        cmd.Parameters.AddWithValue("@Sabor_Pan", tipo_de_pan);
                        cmd.Parameters.AddWithValue("@Relleno_Pan", relleno_pan);
                        cmd.Parameters.AddWithValue("@Tamaño_Pastel", tamaño);
                        cmd.Parameters.AddWithValue("@Cantidad_personas", cantidad);
                        cmd.Parameters.AddWithValue("@Foto", foto);
                        cmd.Parameters.AddWithValue("@Precio", precio);
                        if (Notas != null)
                        {
                            cmd.Parameters.AddWithValue("@Notas", Notas);
                        }
                        else
                        {
                            cmd.Parameters.AddWithValue("@Notas", DBNull.Value);
                        }

                    }


                    cmd.Parameters.AddWithValue("@Operacion", operacion);
                    sqlConnection.Open();
                    cmd.ExecuteNonQuery();
                    sqlConnection.Close();
                }
            }
            finally
            {
                if (sqlConnection.State != ConnectionState.Closed)
                {
                    sqlConnection.Close();
                }
            }

        }

        private void MetodoPedidoProducto(string operacion)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("GestionarPedidoProducto", sqlConnection);
                    cmd.CommandType = CommandType.StoredProcedure;
                    if (operacion == "I")
                    {
                        int id =Convert.ToInt32( LBLIDPRODUCTO.Text);
                        int id_pedido = IDPEDIDO;
                        int id_producto = IDPRODUCTO;
                        int Cantidad = Convert.ToInt32(comboboxCantidadProducto.SelectedItem);

                        cmd.Parameters.AddWithValue("@ID_PEDIDOPRODUCTO", id);
                        cmd.Parameters.AddWithValue("@ID_Pedido", id_pedido);
                        cmd.Parameters.AddWithValue("@ID_Producto", id_producto);
                        cmd.Parameters.AddWithValue("@Cantidad", Cantidad);
                        cmd.Parameters.AddWithValue("@Operacion", operacion);
                    }else 
                    {
                        int id = Convert.ToInt32(txtIDPedidoModifcar.Text);
                        int id_pedido =Convert.ToInt32( txtIDPEDIDOPRODUCTOMODIFICAR.Text);
                        int id_producto = Convert.ToInt32(txtIDPRODUCTOMODIFICAR.Text);
                        int Cantidad = Convert.ToInt32(CBBCANTIDADMODIFICAR.SelectedItem);

                        cmd.Parameters.AddWithValue("@ID_PEDIDOPRODUCTO", id);
                        cmd.Parameters.AddWithValue("@ID_Pedido", id_pedido);
                        cmd.Parameters.AddWithValue("@ID_Producto", id_producto);
                        cmd.Parameters.AddWithValue("@Cantidad", Cantidad);
                        cmd.Parameters.AddWithValue("@Operacion", operacion);
                    }
                

                    sqlConnection.Open();
                    cmd.ExecuteNonQuery();
                    sqlConnection.Close();
                }
            }
            finally
            {

            }
            
        }

        private void MetodoProducto(string operacion)
        {
            try
            {
                string conexion = "Data Source=IDEAPAD;Initial Catalog=BakeBooker3;Integrated Security=True";
                using (SqlConnection con = new SqlConnection(conexion))
                {
                    SqlCommand cmd = new SqlCommand("GestionarProducto", con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    if (operacion == "I")
                    {
                        string id = null; // El ID puede ser nulo al insertar ya que se genera automáticamente
                        string nombre = txtNombreProducto.Text;
                        string descripcion = txtDescripcionProducto.Text;
                        double precio = Convert.ToDouble(txtPrecioProducto.Text);
                        int cantidadDisponible = Convert.ToInt32(txtCantidadProducto.Text);
                        DateTime FechaIngreso = DTPFechaIngresoProducto.Value;
                        DateTime fechaExpiracion = DTPFechaExpiracionProducto.Value;
 
                        string foto = rutaImagen;
                        if (FOTOORDEN2 != "")
                        {
                            foto = FOTOORDEN2;
                        }
                        cmd.Parameters.AddWithValue("@ID_producto", id);
                        cmd.Parameters.AddWithValue("@Nombre", nombre);
                        cmd.Parameters.AddWithValue("@Descripcion", descripcion);
                        cmd.Parameters.AddWithValue("@Precio", precio);
                        cmd.Parameters.AddWithValue("@Fecha_Ingreso", FechaIngreso);
                        cmd.Parameters.AddWithValue("@Cantidad_Disponible", cantidadDisponible);
                        cmd.Parameters.AddWithValue("@Fecha_expiracion", fechaExpiracion);
                        cmd.Parameters.AddWithValue("@Foto", foto);

                    }
                    else if (operacion == "U" || operacion == "D")
                    {
                        string id = lblIDProducto2.Text; 
                        string nombre = txtNombreProducto2.Text;
                        string descripcion = txtDescripcionProducto2.Text;
                        int precio = Convert.ToInt32(txtPrecioProducto2.Text);
                        int cantidadDisponible = Convert.ToInt32(txtCantidadProducto2.Text);
                        DateTime FechaIngreso = DTPFECHAPEDIDOMODIFICAR.Value;
                        DateTime fechaExpiracion = DTPFECHAENTREGAMOD.Value;
                        string foto = rutaImagen;
                        if (FOTOORDEN2 != "")
                        {
                            foto = FOTOORDEN2;
                        }
                        cmd.Parameters.AddWithValue("@ID_producto", id);
                        cmd.Parameters.AddWithValue("@Nombre", nombre);
                        cmd.Parameters.AddWithValue("@Descripcion", descripcion);
                        cmd.Parameters.AddWithValue("@Precio", precio);
                        cmd.Parameters.AddWithValue("@Fecha_Ingreso", FechaIngreso);
                        cmd.Parameters.AddWithValue("@Cantidad_Disponible", cantidadDisponible);
                        cmd.Parameters.AddWithValue("@Fecha_expiracion", fechaExpiracion);
                        cmd.Parameters.AddWithValue("@Foto", foto);
                    }


                    cmd.Parameters.AddWithValue("@Operacion", operacion);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void MetodoEmpleado(string operacion)
        {
            string conexion = "Data Source=IDEAPAD;Initial Catalog=BakeBooker3;Integrated Security=True";

            try
            {
                using (SqlConnection con = new SqlConnection(conexion))
                {
                    SqlCommand cmd = new SqlCommand("GestionarEmpleado", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    if (operacion == "I")
                    {
                    int? ID=null;
                    string nombre = txtnombreEmpleado.Text;
                    string apellido = txtApellidoEmpleado.Text;
                    string usuario = txtUsuarioEmpleado.Text;
                    string contraseña = txtContraseñaEmpleado.Text;
                        string puesto = "General";

                        if (rbdGeneral.Checked)
                        {
                            puesto = "General";
                        }
                        else if (rbdAdmin.Checked)
                        {
                            puesto = "Administrador";

                        }

                        cmd.Parameters.AddWithValue("@ID_empleado", ID);
                    cmd.Parameters.AddWithValue("@Nombre", nombre);
                    cmd.Parameters.AddWithValue("@Apellido", apellido);  
                        cmd.Parameters.AddWithValue("@Puesto", puesto);
                    cmd.Parameters.AddWithValue("@Usuario", usuario);
                    cmd.Parameters.AddWithValue("@Contraseña", contraseña);
                  
                    }else
                    {
                        int ID =Convert.ToInt32(txtIDEmpleado2.Text);
                        string nombre = txtNombreEmpleado2.Text;
                        string apellido = txtApellidoEmpleado2.Text;
                        string usuario = txtUsuarioEmpleado2.Text;
                        string contraseña = txtContraseñaEmpleado2.Text;
                        string puesto = "General";

                        if (rdbGeneral.Checked)
                        {
                            puesto = "General";
                        }
                        else
                        {
                            puesto = "Administrador";

                        }
                        cmd.Parameters.AddWithValue("@ID_empleado", ID);
                        cmd.Parameters.AddWithValue("@Nombre", nombre);
                        cmd.Parameters.AddWithValue("@Apellido", apellido);
                        cmd.Parameters.AddWithValue("@Usuario", usuario);
                        cmd.Parameters.AddWithValue("@Contraseña", contraseña);
                        cmd.Parameters.AddWithValue("@Puesto", puesto);
                   
                    }
                        cmd.Parameters.AddWithValue("@Operacion", operacion);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                                             
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void MetodoCliente(string operacion)
        {
            try
            {
                string conexion = "Data Source=IDEAPAD;Initial Catalog=BakeBooker3;Integrated Security=True";
                using (SqlConnection con = new SqlConnection(conexion))
                {
                    SqlCommand cmd = new SqlCommand("GestionarCliente", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    if (operacion == "I")
                    {
                        string id = null;
                        string nombre = txtNombreCliente.Text;
                        string apellido = txtApellidoCliente.Text;
                        string calle = txtCalleCliente.Text;
                        double numexterior = Convert.ToDouble(txtNumExteriorCliente.Text);
                        int? numinterior = null;
                        if (!string.IsNullOrEmpty(txtNumInteriorCliente.Text))
                        {
                            if (int.TryParse(txtNumInteriorCliente.Text, out int resultado))
                            {
                                numinterior = resultado;
                            }
                            else
                            {
                                MessageBox.Show("El numero interior mal.");
                                return;
                            }
                        }
                        string rfc = string.IsNullOrEmpty(txtRFCCliente.Text) ? null : txtRFCCliente.Text;
                        string telefono = txtTelefonoCliente.Text;
                        string correo = txtCorreoCliente.Text;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@ID_cliente", id);
                        cmd.Parameters.AddWithValue("@Nombre", nombre);
                        cmd.Parameters.AddWithValue("@Apellido", apellido);
                        cmd.Parameters.AddWithValue("@Calle", calle);
                        cmd.Parameters.AddWithValue("@Numero_Exterior", numexterior);
                        cmd.Parameters.AddWithValue("@Telefono", telefono);
                        cmd.Parameters.AddWithValue("@Correo_electronico", correo);
                        if (numinterior != null)
                        {
                            cmd.Parameters.AddWithValue("@Numero_interior", numinterior);
                        }
                        else
                        {
                            cmd.Parameters.AddWithValue("@Numero_interior", DBNull.Value);
                        }
                        if (rfc != null)
                        {
                            cmd.Parameters.AddWithValue("@RFC", rfc);
                        }
                        else
                        {
                            cmd.Parameters.AddWithValue("@RFC", DBNull.Value);
                        }
                    }
                    else
                    {
                        string id = txtIDBCliente.Text;
                        string nombre = txtNombreBCliente.Text;
                        string apellido = txtApellidoBCliente.Text;
                        string calle = txtCalleBCliente.Text;
                        double numexterior = Convert.ToDouble(txtNumExteriorBCliente.Text);
                        int? numinterior = null;
                        if (!string.IsNullOrEmpty(txtNumInteriorBCliente.Text))
                        {
                            if (int.TryParse(txtNumInteriorBCliente.Text, out int resultado))
                            {
                                numinterior = resultado;
                            }
                            else
                            {
                                MessageBox.Show("El numero interior mal.");
                                return;
                            }
                        }
                        string rfc = string.IsNullOrEmpty(txtRFCBCliente.Text) ? null : txtRFCBCliente.Text;
                        string telefono = txtTelefonoBCliente.Text;
                        string correo = txtCorreoBCliente.Text;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@ID_cliente", id);
                        cmd.Parameters.AddWithValue("@Nombre", nombre);
                        cmd.Parameters.AddWithValue("@Apellido", apellido);
                        cmd.Parameters.AddWithValue("@Calle", calle);
                        cmd.Parameters.AddWithValue("@Numero_Exterior", numexterior);
                        cmd.Parameters.AddWithValue("@Telefono", telefono);
                        cmd.Parameters.AddWithValue("@Correo_electronico", correo);
                        if (numinterior != null)
                        {
                            cmd.Parameters.AddWithValue("@Numero_interior", numinterior);
                        }
                        else
                        {
                            cmd.Parameters.AddWithValue("@Numero_interior", DBNull.Value);
                        }
                        if (rfc != null)
                        {
                            cmd.Parameters.AddWithValue("@RFC", rfc);
                        }
                        else
                        {
                            cmd.Parameters.AddWithValue("@RFC", DBNull.Value);
                        }

                    }
                    cmd.Parameters.AddWithValue("@Operacion", operacion);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }

        }
      
        private void MetodoPedido(string operacion)
        {
            try
            {
                string conexion = "Data Source=IDEAPAD;Initial Catalog=BakeBooker3;Integrated Security=True";
                using (SqlConnection con = new SqlConnection(conexion))
                {
                    SqlCommand cmd = new SqlCommand("GestionarPedido", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    if (operacion == "I")
                    {
                       
                        int id_cliente = IDCLIENTE;
                        int anticipo =0;
                        int Total =0;
                        string Forma_entrega = FORMAENTREGAPEDIDO;
                        DateTime FechaDeEntrega = DTPFechaDeEntregaPedido.Value;
                        if (radiobuttonRecoger.Checked)
                        {
                            Forma_entrega = "Recoger";
                        }else if (radioButtonLlevar.Checked)
                        {
                            Forma_entrega = "Llevar";
                        }
                        if (!string.IsNullOrEmpty(txtPedidos_Anticipo.Text))
                        {
                            if (int.TryParse(txtPedidos_Anticipo.Text, out int resultado))
                            {
                                anticipo = resultado;
                            }
                            else
                            {
                                MessageBox.Show("El numero anticipo esta mal mal.");
                                return;
                            }
                        }

                        cmd.CommandType = CommandType.StoredProcedure;
                        DateTime FechaDeEntrega1 = DTPfechadepedido.Value;
                        cmd.Parameters.AddWithValue("@Fecha_de_pedido", FechaDeEntrega1);

                        cmd.Parameters.AddWithValue("@ID_cliente", id_cliente);
                        cmd.Parameters.AddWithValue("@Anticipo", anticipo);
                        cmd.Parameters.AddWithValue("@Total", Total);
                        cmd.Parameters.AddWithValue("@Forma_entrega", Forma_entrega);
                        cmd.Parameters.AddWithValue("@Fecha_de_entrega", FechaDeEntrega);
   
                    }
                    else
                    {
                        string id_pedido = txtIDPEDIDOMODFICIAR.Text;
                        string id_cliente = TXTIDCLIENTEMODIFICAR.Text;
                        int anticipo =Convert.ToInt32(TXTANTICIPOMODIFICAR.Text);
                        int Total = Convert.ToInt32(TXTTOTALMODIFICAR.Text);                        
                        DateTime fechaPedido = DTPFECHAPEDIDOMODIFICAR.Value;
                        string Forma_entrega = "Recoger";
                        if (RADRECOGERMODIFICAR.Checked)
                        {
                            Forma_entrega = "Recoger";
                        }
                        else if (RADLLEVARMODIFICAR.Checked)
                        {
                            Forma_entrega = "Llevar";
                        }
                        DateTime FechaDeEntrega = DTPFECHAENTREGAMOD.Value;
                       

                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@ID_pedido", id_pedido);
                        cmd.Parameters.AddWithValue("@ID_cliente", id_cliente);
                        cmd.Parameters.AddWithValue("@Anticipo", anticipo);
                        cmd.Parameters.AddWithValue("@Total", Total);
                        cmd.Parameters.AddWithValue("@Forma_entrega", Forma_entrega);
                        cmd.Parameters.AddWithValue("@Fecha_de_pedido", FechaDeEntrega);
                        cmd.Parameters.AddWithValue("@Fecha_de_entrega", FechaDeEntrega);
                    }
                    cmd.Parameters.AddWithValue("@Operacion", operacion);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                }
            }
            finally
            {

            }

        }
        private void DatosIDProducto()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT Nombre FROM Producto";

                SqlCommand command = new SqlCommand(query, connection);
                SqlDataReader reader;

                try
                {
                    connection.Open();
                    reader = command.ExecuteReader();

                    // Limpiar el ComboBox antes de cargar nuevos datos
                    CBBNombreProducto.Items.Clear();

                    while (reader.Read())
                    {
                        string idProducto = reader.GetString(0);
                        CBBNombreProducto.Items.Add(idProducto); // Agregar el ID al ComboBox
                    }

                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al cargar datos: " + ex.Message);
                }
            }
            
        }

        private void VerificarRolUsuario()
        {
            try
            {
                // Abre una conexión para verificar el rol del usuario
                using (SqlConnection conexion = new SqlConnection(connectionString))
                {
                    conexion.Open();

                    // Consulta para obtener el puesto del usuario
                    string consulta = "SELECT Puesto FROM Empleado WHERE Usuario = @Usuario";

                    using (SqlCommand cmd = new SqlCommand(consulta, conexion))
                    {
                        // Ajusta el parámetro según cómo hayas almacenado el usuario en la base de datos
                        cmd.Parameters.AddWithValue("@Usuario", UsuarioRol);

                        // Ejecuta la consulta y obtén el resultado
                        object resultado = cmd.ExecuteScalar();

                        // Verifica el resultado y ajusta la visibilidad de los botones
                        if (resultado != null)
                        {
                            string puesto = resultado.ToString();

                            if (puesto == "General")
                            {
                                btnEmpleados.Visible = false;
                                btnReportes.Visible = false;
                            }
                            // Puedes agregar más lógica para otros roles si es necesario
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Manejo de errores (puedes mostrar un mensaje de error, log, etc.)
                MessageBox.Show($"Error al verificar el rol del usuario: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        ///               MENU                    /// <summary>
        private void CambiarPaginaMenuPrincipal(int indicePagina)
        {
            // Si la página actual es diferente de la nueva página, muestra la confirmación
            if (paginaActual != indicePagina)
            {
                DialogResult resultado = MessageBox.Show("¿Estás seguro de salir de la página actual?", "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                // Si el usuario confirma, cambia la página
                if (resultado == DialogResult.Yes)
                {
                    tabCentral.SelectedIndex = indicePagina;
                    paginaActual = indicePagina;
                }
                ActualizarColoresBotonesMenu();
            }
            else
            {
                // Si la página actual es la misma que la nueva página, simplemente cambia la página
                tabCentral.SelectedIndex = indicePagina;
                paginaActual = indicePagina;

                // Actualiza los colores de los botones
                ActualizarColoresBotonesMenu();
            }

        }
        private void ActualizarColoresBotonesMenu()
        {
            // Restablece los colores de todos los botones

            btnEmpleados.BackColor = Color.Transparent;
            btnClientes.BackColor = Color.Transparent;
            btnPedidos.BackColor = Color.Transparent;
            btnProductos.BackColor = Color.Transparent;
            btnReportes.BackColor = Color.Transparent;

            // Establece el color brillante para el botón de la página actual
            switch (paginaActual)
            {
                case 0:
                    break;
                case 1:
                    btnEmpleados.BackColor = Color.LightCoral;
                    break;
                case 2:
                    btnClientes.BackColor = Color.LightCoral;
                    break;
                case 3:
                    btnPedidos.BackColor = Color.LightCoral;
                    break;
                case 4:
                    btnProductos.BackColor = Color.LightCoral;
                    break;
                case 5:
                    btnReportes.BackColor = Color.LightCoral;
                    ObtenerCantidadPedidosPorMesReporte();
                    break;
            }
        }

        //              EMPLEADOS
        private void CambiarPaginaMenuEmpleado(int indicePagina)
        {
            // Si la página actual es diferente de la nueva página, muestra la confirmación
            if (paginaActualEmpleado != indicePagina)
            {
                DialogResult resultado = MessageBox.Show("¿Estás seguro de salir de la página actual?", "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                // Si el usuario confirma, cambia la página
                if (resultado == DialogResult.Yes)
                {
                    tabEmpleado.SelectedIndex = indicePagina;
                    paginaActualEmpleado = indicePagina;
                }
                ActualizarColoresBotonesEmpleado();
            }
            else
            {
                tabEmpleado.SelectedIndex = indicePagina;
                paginaActualEmpleado = indicePagina;

                // Actualiza los colores de los botones
                ActualizarColoresBotonesEmpleado();
            }

        }
        private void ActualizarColoresBotonesEmpleado()
        {
            // Restablece los colores de todos los botones




            btnBEMempleado.BackColor = Color.Transparent;
            btnEmpleadoNuevo.BackColor = Color.Transparent;


            // Establece el color brillante para el botón de la página actual
            switch (paginaActualEmpleado)
            {
                case 0:
                    btnEmpleadoNuevo.BackColor = Color.IndianRed;
                    break;
                case 1:
                    btnBEMempleado.BackColor = Color.IndianRed;
                    break;


            }
        }


        //              CLIENTES
        private void CambiarPaginaMenuCliente(int indicePagina)
        {
            RefrescarClientes();
            // Si la página actual es diferente de la nueva página, muestra la confirmación
            if (paginaActualCliente != indicePagina)
            {
                DialogResult resultado = MessageBox.Show("¿Estás seguro de salir de la página actual?", "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                // Si el usuario confirma, cambia la página
                if (resultado == DialogResult.Yes)
                {
                    tabCliente.SelectedIndex = indicePagina;
                    paginaActualCliente = indicePagina;
                }
                ActualizarColoresBotonesCliente();
            }
            else
            {
                // Si la página actual es la misma que la nueva página, simplemente cambia la página
                tabCliente.SelectedIndex = indicePagina;
                paginaActualCliente = indicePagina;

                // Actualiza los colores de los botones
                ActualizarColoresBotonesCliente();
            }

        }
        private void ActualizarColoresBotonesCliente()
        {
            // Restablece los colores de todos los botones




            btnBEMclientes.BackColor = Color.Transparent;
            btnClienteNuevo.BackColor = Color.Transparent;


            // Establece el color brillante para el botón de la página actual
            switch (paginaActualCliente)
            {
                case 0:
                    btnClienteNuevo.BackColor = Color.IndianRed;
                    break;
                case 1:
                    btnBEMclientes.BackColor = Color.IndianRed;
                    break;

            }
        }

         private void RefrescarClientes()
            {   
            string query = $"SELECT * FROM Cliente"; // Utiliza el nombre de la tabla proporcionado
            SqlCommand cmd = new SqlCommand(query, sqlConnection);
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);
            dgvResultadosClientes.DataSource = dataTable;

            txtIDBCliente.Text = "";
            txtNombreBCliente.Text = "";
            txtApellidoBCliente.Text = "";
            txtCorreoBCliente.Text = "";
            txtCalleBCliente.Text = "";
            txtNumExteriorBCliente.Text = "";
            txtNumInteriorBCliente.Text = "";
            txtTelefonoBCliente.Text = "";
            txtRFCBCliente.Text = "";


         
            txtNombreCliente.Text = "";
            txtApellidoCliente.Text = "";
            txtCorreoCliente.Text = "";
            txtCalleCliente.Text = "";
            txtNumExteriorCliente.Text = "";
            txtNumInteriorCliente.Text = "";
            txtTelefonoCliente.Text = "";
            txtRFCCliente.Text = "";

        }
        //              PEDIDOS
        private void CambiarPaginaMenuPedidos(int indicePagina)
        {

            // Si la página actual es diferente de la nueva página, muestra la confirmación
            if (paginaActualPedido != indicePagina)
            {
                DialogResult resultado = MessageBox.Show("¿Estás seguro de salir de la página actual?", "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                // Si el usuario confirma, cambia la página
                if (resultado == DialogResult.Yes)
                {
                    tabPedido.SelectedIndex = indicePagina;
                    paginaActualPedido = indicePagina;
                }
                ActualizarColoresBotonesPedido();

            }
            else
            {
                // Si la página actual es la misma que la nueva página, simplemente cambia la página
                tabPedido.SelectedIndex = indicePagina;
                paginaActualPedido = indicePagina;

                // Actualiza los colores de los botones
                ActualizarColoresBotonesPedido();
            }

        }
     
        private void ActualizarColoresBotonesPedido()
        {
            // Restablece los colores de todos los botones

            btnBEMPedidos.BackColor = Color.Transparent;
            btnIniciarPedido.BackColor = Color.Transparent;


            // Establece el color brillante para el botón de la página actual
            switch (paginaActualCliente)
            {
                case 0:
                    btnIniciarPedido.BackColor = Color.IndianRed;
                    break;
                case 1:
                    btnBEMPedidos.BackColor = Color.IndianRed;

                    break;

            }
        }

        //REPORTES
        private void ClearChart()
        {
            chart1.Series["Mes"].Points.Clear();
        }
        private void ObtenerCantidadPedidosPorMesReporte()
        {
            DataTable dataTable = new DataTable();
        SqlConnection conexion = new SqlConnection(connectionString);
        SqlDataAdapter da = new SqlDataAdapter("EXEC ObtenerCantidadPedidosPorMes;", conexion);
        da.Fill(dataTable);

            // Limpia los puntos existentes en el gráfico
          ClearChart();

            int xnfilas = dataTable.Rows.Count;
            for (int k = 0; k<xnfilas; k++)
            {


                chart1.Series["Mes"].Points.AddXY(dataTable.Rows[k]["Mes"], dataTable.Rows[k]["CantidadPedidos"]);
            }
}


        private void frmADMIN_Load(object sender, EventArgs e)
        {

        }


        private void btnBuscaEmpleadoCriterio_Click(object sender, EventArgs e)
        {
            if (radIDempleado.Checked)
            {
                int IDaBuscar=Convert.ToInt32(txtBuscarEmpleado.Text);

                try
                {
                    using (SqlConnection conexion = new SqlConnection(connectionString))
                    {
                        using (SqlCommand comando = new SqlCommand("BuscarEmpleadosID", conexion))
                        {
                            comando.CommandType = CommandType.StoredProcedure;

                            comando.Parameters.Add("@idABuscar", SqlDbType.NVarChar).Value = IDaBuscar;

                            conexion.Open();

                            SqlDataAdapter adaptador = new SqlDataAdapter(comando);
                            DataTable tablaResultados = new DataTable();
                            adaptador.Fill(tablaResultados);

                            if (tablaResultados.Rows.Count > 0)
                            {
                                dgvResultadosEmpleados.DataSource = tablaResultados;
                                // ComboboxBuscar.DisplayMember = "Nombre";
                                //ComboboxBuscar.ValueMember = "Nombre";

                            }
                            else
                            {
                                //ComboboxBuscar.DataSource = null;
                                MessageBox.Show("No se encontraron resultados.");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    if (sqlConnection.State != ConnectionState.Closed)
                    {
                        sqlConnection.Close();
                    }
                }
            }
            else
            {
                string nombreABuscar = txtBuscarEmpleado.Text.Trim();


                if (!string.IsNullOrEmpty(nombreABuscar))
                {
                    try
                    {
                        using (SqlConnection conexion = new SqlConnection(connectionString))
                        {
                            using (SqlCommand comando = new SqlCommand("BuscarEmpleados", conexion))
                            {
                                comando.CommandType = CommandType.StoredProcedure;

                                comando.Parameters.Add("@nombreABuscar", SqlDbType.NVarChar).Value = nombreABuscar;

                                conexion.Open();

                                SqlDataAdapter adaptador = new SqlDataAdapter(comando);
                                DataTable tablaResultados = new DataTable();
                                adaptador.Fill(tablaResultados);

                                if (tablaResultados.Rows.Count > 0)
                                {
                                    dgvResultadosEmpleados.DataSource = tablaResultados;
                                    // ComboboxBuscar.DisplayMember = "Nombre";
                                    //ComboboxBuscar.ValueMember = "Nombre";

                                }
                                else
                                {
                                    //ComboboxBuscar.DataSource = null;
                                    MessageBox.Show("No se encontraron resultados.");
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                    finally
                    {
                        if (sqlConnection.State != ConnectionState.Closed)
                        {
                            sqlConnection.Close();
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Por favor, ingresa un nombre para buscar.");
                }
            }
        }

        private void btnEmpleados_Click(object sender, EventArgs e)
        {

        }


        private void btnBuscarCliente_Click(object sender, EventArgs e)
        {
            string nombreABuscar = txtBuscarCliente.Text.Trim();
            if (!string.IsNullOrEmpty(nombreABuscar))
            {
                try
                {
                    using (SqlConnection conexion = new SqlConnection(connectionString))
                    {
                        using (SqlCommand comando = new SqlCommand("BuscarNombresSimilares", conexion))
                        {
                            comando.CommandType = CommandType.StoredProcedure;

                            comando.Parameters.Add("@nombreABuscar", SqlDbType.NVarChar).Value = nombreABuscar;

                            conexion.Open();

                            SqlDataAdapter adaptador = new SqlDataAdapter(comando);
                            DataTable tablaResultados = new DataTable();
                            adaptador.Fill(tablaResultados);

                            if (tablaResultados.Rows.Count > 0)
                            {
                                dgvResultadosClientes.DataSource = tablaResultados;
                                // ComboboxBuscar.DisplayMember = "Nombre";
                                //ComboboxBuscar.ValueMember = "Nombre";

                            }
                            else
                            {
                                //ComboboxBuscar.DataSource = null;
                                MessageBox.Show("No se encontraron resultados.");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    if (sqlConnection.State != ConnectionState.Closed)
                    {
                        sqlConnection.Close();
                    }
                }
            }
            else
            {
                MessageBox.Show("Por favor, ingresa un nombre para buscar.");
            }
        }

        private void btnCrearCliente_Click(object sender, EventArgs e)
        {
            MetodoCliente("I");
            RefrescarClientes();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            MetodoCliente("U");
            RefrescarClientes();
        }

        private void btnEliminarCliente_Click(object sender, EventArgs e)
        {
            MetodoCliente("D");
            RefrescarClientes();
        }


        private void btnCargarImagen_Click(object sender, EventArgs e)
        {
            // Configura el OpenFileDialog
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Archivos de imagen|*.jpg;*.jpeg;*.png;*.gif;*.bmp|Todos los archivos|*.*";
            openFileDialog.Title = "Seleccionar imagen";

            // Muestra el cuadro de diálogo
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                // Obtiene la ruta de la imagen seleccionada
                string rutaImagen = openFileDialog.FileName;

                try
                {
                    // Carga la imagen en el PictureBox
                    pbxImagenPastel.Image = new System.Drawing.Bitmap(rutaImagen);
                    FOTOORDEN = rutaImagen;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error al cargar la imagen: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnCrearEmpleado_Click(object sender, EventArgs e)
        {
            MetodoEmpleado("I");
            MessageBox.Show("Empleado insertado");

        }

        private void dgvResultadosClientes_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            gpbMostrarCliente.Focus();
            gpbMostrarCliente.Visible = true;

            if (e.RowIndex >= 0) // Verifica si se ha hecho clic en una fila válida
            {
                DataGridViewRow filaSeleccionada = dgvResultadosClientes.Rows[e.RowIndex];
                txtIDBCliente.Text = filaSeleccionada.Cells["ID_cliente"].Value.ToString();
                txtNombreBCliente.Text = filaSeleccionada.Cells["nombre"].Value.ToString();
                txtApellidoBCliente.Text = filaSeleccionada.Cells["apellido"].Value.ToString();
                txtCorreoBCliente.Text = filaSeleccionada.Cells["correo_electronico"].Value.ToString();
                txtCalleBCliente.Text = filaSeleccionada.Cells["calle"].Value.ToString();
                txtNumExteriorBCliente.Text = filaSeleccionada.Cells["numero_exterior"].Value.ToString();
                txtNumInteriorBCliente.Text = filaSeleccionada.Cells["numero_interior"].Value.ToString();
                txtTelefonoBCliente.Text = filaSeleccionada.Cells["telefono"].Value.ToString();
                txtRFCBCliente.Text = filaSeleccionada.Cells["rfc"].Value.ToString();

                gpbMostrarCliente.Visible = true;

            }
        }

        private void dgvResultadosEmpleados_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Verifica si se ha hecho clic en una fila válida
            {
                DataGridViewRow filaSeleccionada = dgvResultadosEmpleados.Rows[e.RowIndex];
                txtIDEmpleado2.Text = filaSeleccionada.Cells["ID_empleado"].Value.ToString();
                txtNombreEmpleado2.Text = filaSeleccionada.Cells["Nombre"].Value.ToString();
                txtApellidoEmpleado2.Text = filaSeleccionada.Cells["Apellido"].Value.ToString();
                txtUsuarioEmpleado2.Text = filaSeleccionada.Cells["Usuario"].Value.ToString();
                txtContraseñaEmpleado2.Text = filaSeleccionada.Cells["Contraseña"].Value.ToString();
                string puesto= filaSeleccionada.Cells["Puesto"].Value.ToString();
                if (puesto == "Administrador")
                {
                    rdbAdmin.Checked = true;
                }
                else
                {
                    rdbGeneral.Checked= true;
                }
            }
        }

        private void btnEliminarEmpleado_Click(object sender, EventArgs e)
        {
            MetodoEmpleado("D");
        }

        private void btnModificarEmpleado_Click(object sender, EventArgs e)
        {
            MetodoEmpleado("U");
        }

        private void btnPedidoPastel_Click(object sender, EventArgs e)
        {
            MostrarPedidosCliente(idpedidoparabuscar);
            PedidosYProductos.SelectedTab = Pedido;
        }

        private void btnPedidoProducto_Click(object sender, EventArgs e)
        {
            MostrarProductosCliente(idpedidoparabuscar);
            PedidosYProductos.SelectedTab = Producto;

        }

        private void btnBuscarClientePedido_Click(object sender, EventArgs e)
        {
            string nombreABuscar = txtNombreClientePedido.Text.Trim();


            if (!string.IsNullOrEmpty(nombreABuscar))
            {
                try
                {
                    using (SqlConnection conexion = new SqlConnection(connectionString))
                    {
                        using (SqlCommand comando = new SqlCommand("BuscarNombresSimilares", conexion))
                        {
                            comando.CommandType = CommandType.StoredProcedure;

                            comando.Parameters.Add("@nombreABuscar", SqlDbType.NVarChar).Value = nombreABuscar;

                            conexion.Open();

                            SqlDataAdapter adaptador = new SqlDataAdapter(comando);
                            DataTable tablaResultados = new DataTable();
                            adaptador.Fill(tablaResultados);

                            if (tablaResultados.Rows.Count > 0)
                            {
                                DGVPEDIDOINICIO.DataSource = tablaResultados;

                            }
                            else
                            {
                                //ComboboxBuscar.DataSource = null;
                                MessageBox.Show("No se encontraron resultados.");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    if (sqlConnection.State != ConnectionState.Closed)
                    {
                        sqlConnection.Close();
                    }
                }
            }
            else
            {
                MessageBox.Show("Por favor, ingresa un nombre para buscar.");
            }
        }

        private void DGVPEDIDOINICIO_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Verifica si se ha hecho clic en una fila válida
            {
                DataGridViewRow filaSeleccionada = DGVPEDIDOINICIO.Rows[e.RowIndex];

                object valorCelda = filaSeleccionada.Cells["ID_cliente"].Value;
                object Idcliente = filaSeleccionada.Cells["ID_cliente"].Value;

              
              
                if (valorCelda != null && int.TryParse(valorCelda.ToString(), out int idCliente))
                {
                    idclienteparabuscar = idCliente;
                    IDCLIENTE = idCliente;

                }
                MostrarPedidos(idclienteparabuscar);
            }
        }
        private void MostrarPedidosID()
        {

        }

        private void btnAgregarAPedido_Click(object sender, EventArgs e)
        {
            if (PedidosYProductos.SelectedTab == Pedido)
            {
                MetodoPedidoDetalle("I");
                MostrarPedidosCliente(idpedidoparabuscar);
            }
            else
            {
                MetodoPedidoProducto("I");
                MostrarProductosCliente(idpedidoparabuscar);
                RefrescarProducto();
            }
            MostrarPedidos(idclienteparabuscar);
         
         

        }

        private void btnCrearPedido_Click(object sender, EventArgs e)
        {
            MetodoPedido("I");
            MostrarPedidos(idclienteparabuscar);
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Verifica si se ha hecho clic en una fila válida
            {
                DataGridViewRow filaSeleccionada = dataGridView1.Rows[e.RowIndex];

                object valorCelda = filaSeleccionada.Cells["ID_pedido"].Value;
                

                if (valorCelda != null && int.TryParse(valorCelda.ToString(), out int idPedido))
                {
                    idpedidoparabuscar = idPedido;

                    //aquiva elmetodo de mostrarpedidos
                }
                else
                {
                    MessageBox.Show("problema con la seleccion de id para pedido");
                }
                IDPEDIDO = idpedidoparabuscar;
                MostrarPedidosCliente(idpedidoparabuscar);
            }
        }

        private void comboboxIDProducto_SelectedIndexChanged(object sender, EventArgs e)
        {
            RefrescarProducto();
        }

        private void btnBEMPedidos_Click(object sender, EventArgs e)
        {

        }

        private void btnBuscarPedido_Click(object sender, EventArgs e)
        {
            string nombreABuscar = txtBusquedaPedido.Text.Trim();


            if (!string.IsNullOrEmpty(nombreABuscar))
            {
                try
                {
                    using (SqlConnection conexion = new SqlConnection(connectionString))
                    {
                        using (SqlCommand comando = new SqlCommand("BuscarNombresSimilares", conexion))
                        {
                            comando.CommandType = CommandType.StoredProcedure;

                            comando.Parameters.Add("@nombreABuscar", SqlDbType.NVarChar).Value = nombreABuscar;

                            conexion.Open();

                            SqlDataAdapter adaptador = new SqlDataAdapter(comando);
                            DataTable tablaResultados = new DataTable();
                            adaptador.Fill(tablaResultados);

                            if (tablaResultados.Rows.Count > 0)
                            {
                                DGVCLIENTEBUSQUEDA.DataSource = tablaResultados;
                                // ComboboxBuscar.DisplayMember = "Nombre";
                                //ComboboxBuscar.ValueMember = "Nombre";

                            }
                            else
                            {
                                //ComboboxBuscar.DataSource = null;
                                MessageBox.Show("No se encontraron resultados.");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    if (sqlConnection.State != ConnectionState.Closed)
                    {
                        sqlConnection.Close();
                    }
                }
            }
            else
            {
                MessageBox.Show("Por favor, ingresa un nombre para buscar.");
            }
        }

        private void DGVCLIENTEBUSQUEDA_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Verifica si se ha hecho clic en una fila válida
            {
                DataGridViewRow filaSeleccionada = DGVCLIENTEBUSQUEDA.Rows[e.RowIndex];

                object valorCelda = filaSeleccionada.Cells["ID_cliente"].Value;
                object Idcliente = filaSeleccionada.Cells["ID_cliente"].Value;



                if (valorCelda != null && int.TryParse(valorCelda.ToString(), out int idCliente))
                {
                    idclienteparabuscar = idCliente;
                    IDCLIENTE = idCliente;

                }
                MostrarPedidos2(idclienteparabuscar);

            }
        }

        private void DGVBUSQUEDAPEDIDO_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Verifica si se ha hecho clic en una fila válida
            {
                DataGridViewRow filaSeleccionada = DGVBUSQUEDAPEDIDO.Rows[e.RowIndex];
                object valorCelda = filaSeleccionada.Cells["ID_pedido"].Value;
                if (valorCelda != null && int.TryParse(valorCelda.ToString(), out int idPedido))
                {
                    idpedidoparabuscar = idPedido;      
                }
                else
                {
                    MessageBox.Show("problema con la seleccion de id para pedido");
                }
                 IDPEDIDO = idpedidoparabuscar;
                 TABMODIFICARPEDIDO.SelectedTab = Pedido2; 
                MostrarPedidosCliente2(idpedidoparabuscar);
                txtIDPEDIDOMODFICIAR.Text = filaSeleccionada.Cells["ID_cliente"].Value.ToString();

                TXTIDCLIENTEMODIFICAR.Text = filaSeleccionada.Cells["ID_cliente"].Value.ToString();
                string fechapedido= filaSeleccionada.Cells["Fecha_de_pedido"].Value.ToString();
               
                if (DateTime.TryParse(fechapedido, out DateTime stringi))
                { DTPFECHAPEDIDOMODIFICAR.Value = stringi;
                   
                }
                TXTANTICIPOMODIFICAR.Text = filaSeleccionada.Cells["Anticipo"].Value.ToString();
               
                TXTTOTALMODIFICAR.Text = filaSeleccionada.Cells["Total"].Value.ToString();
                string formaentrega= filaSeleccionada.Cells["Forma_entrega"].Value.ToString();
                if (formaentrega == "Recoger")
                {
                    RADRECOGERMODIFICAR.Checked=true;
                }
                else
                {
                    RADLLEVARMODIFICAR.Checked = true;
                }
                string fechaentrega = filaSeleccionada.Cells["Fecha_de_entrega"].Value.ToString();

                if (DateTime.TryParse(fechaentrega, out DateTime entrega))
                {
                    DTPFECHAENTREGAMOD.Value = entrega;

                }
               
            }
        }

        private void btnOrdenMod_Click(object sender, EventArgs e)
        {
            TABMODIFICARPEDIDO.SelectedTab = Orden2;
            MostrarPedidosCliente2(idpedidoparabuscar);

        }

        private void bntProductoMod_Click(object sender, EventArgs e)
        {
            TABMODIFICARPEDIDO.SelectedTab = Producto2;
            MostrarProductosCliente2(idpedidoparabuscar);


        }

        private void btnPedidoMod_Click(object sender, EventArgs e)
        {
            TABMODIFICARPEDIDO.SelectedTab = Pedido2;

        }

        private void btnModGen_Click(object sender, EventArgs e)
        {
            if (TABMODIFICARPEDIDO.SelectedTab == Pedido2)
            { MetodoPedido("U");
                           MostrarPedidosCliente2(idclienteparabuscar);

            }else if (TABMODIFICARPEDIDO.SelectedTab == Orden2)
            {
                MetodoPedidoDetalle("U");   
                MostrarPedidosCliente2(idclienteparabuscar);

            }
            else
            { MetodoPedidoProducto("U");
                MostrarProductosCliente2(idclienteparabuscar);

            }
        }

        private void btnEliminarGen_Click(object sender, EventArgs e)
        {
            if (TABMODIFICARPEDIDO.SelectedTab == Pedido2)
            {

            }
            else if (TABMODIFICARPEDIDO.SelectedTab == Orden2)
            {

            }
            else
            {

            }
        }

        private void btnAgregarProducto_Click(object sender, EventArgs e)
        {
            TABCONTROLPRODUCTO.SelectedTab = InsertarProducto;
        }

        private void btnModificarProducto2_Click(object sender, EventArgs e)
        {
            TABCONTROLPRODUCTO.SelectedTab = Modificar;

        }

        private void DGVBUSQUEDADETALLESPEDIDO_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Verifica si se ha hecho clic en una fila válida
            {
                DataGridViewRow filaSeleccionada = DGVBUSQUEDADETALLESPEDIDO.Rows[e.RowIndex];
                if (TABMODIFICARPEDIDO.SelectedTab == Orden2)
                {
                    txtIDOrdenModificar.Text = filaSeleccionada.Cells["ID_detalle"].Value.ToString();
                    txtIDPEDIDOMODIFICAR.Text = filaSeleccionada.Cells["ID_pedido"].Value.ToString();
                  CBBCantidadDePisosModificar.Text = filaSeleccionada.Cells["Cantidad_Pisos"].Value.ToString();
                  txtTipodePanModificar.Text = filaSeleccionada.Cells["Sabor_Pan"].Value.ToString(); 
                  CBBRellenodePanModificar.Text = filaSeleccionada.Cells["Relleno_Pan"].Value.ToString();
                  CBBTamañodePedidoModificar.Text = filaSeleccionada.Cells["Tamaño_Pastel"].Value.ToString();
                txtCantidadDePersonasModificar.Text = filaSeleccionada.Cells["Cantidad_Personas"].Value.ToString();
                txtPrecioOrdenModificar.Text = filaSeleccionada.Cells["Precio"].Value.ToString();
                txtNotasModificar.Text = filaSeleccionada.Cells["Notas"].Value.ToString();
                    PBMODIFICARPEDIDO.Image = Image.FromFile(filaSeleccionada.Cells["Foto"].Value.ToString());
                }
                else if(TABMODIFICARPEDIDO.SelectedTab==Producto2)
                {
                    txtIDPEDIDOPRODUCTOMODIFICAR.Text= filaSeleccionada.Cells["ID_PEDIDOPRODUCTO"].Value.ToString();
                    txtIDPedidoModifcar.Text = filaSeleccionada.Cells["ID_pedido"].Value.ToString();
                    txtIDPRODUCTOMODIFICAR.Text = filaSeleccionada.Cells["ID_producto"].Value.ToString();
                
                    CBBCANTIDADMODIFICAR.Text = filaSeleccionada.Cells["Cantidad"].Value.ToString();

                }
                else
                {

                }
                object valorCelda = filaSeleccionada.Cells["ID_pedido"].Value;

                if (valorCelda != null && int.TryParse(valorCelda.ToString(), out int idPedido))
                {
                    IDPEDIDO2 = idPedido;
                }
                else
                {
                    MessageBox.Show("problema con la seleccion de id para pedido");
                }
            }
        }

        private void btnSubirImagenModificar_Click(object sender, EventArgs e)
        {
            // Configura el OpenFileDialog
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Archivos de imagen|*.jpg;*.jpeg;*.png;*.gif;*.bmp|Todos los archivos|*.*";
            openFileDialog.Title = "Seleccionar imagen";

            // Muestra el cuadro de diálogo
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                // Obtiene la ruta de la imagen seleccionada
                string rutaImagen = openFileDialog.FileName;

                try
                {
                    // Carga la imagen en el PictureBox
                    PBMODIFICARPEDIDO.Image = new System.Drawing.Bitmap(rutaImagen);
                    FOTOORDEN2 = rutaImagen;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error al cargar la imagen: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnSUBI_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvResultadoProductos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Verifica si se ha hecho clic en una fila válida
            {
                DataGridViewRow filaSeleccionada = dgvResultadoProductos.Rows[e.RowIndex];
                lblIDProducto2.Text = filaSeleccionada.Cells["ID_producto"].Value.ToString();
                txtNombreProducto2.Text = filaSeleccionada.Cells["Nombre"].Value.ToString();
                txtDescripcionProducto2.Text = filaSeleccionada.Cells["Descripcion"].Value.ToString();
                txtPrecioProducto2.Text = filaSeleccionada.Cells["Precio"].Value.ToString();
                txtContraseñaEmpleado2.Text = filaSeleccionada.Cells["Fecha_Ingreso"].Value.ToString();
                txtCantidadProducto2.Text = filaSeleccionada.Cells["Cantidad_Disponible"].Value.ToString();
                txtContraseñaEmpleado2.Text = filaSeleccionada.Cells["Fecha_expiracion"].Value.ToString();
                PBProductoModificar.Image = Image.FromFile(filaSeleccionada.Cells["Foto"].Value.ToString());
            }
        }

        private void DGVBUSQUEDADETALLESPEDIDO_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {            
            MetodoProducto("I");
            MostrarProductos();
        }

        private void btnModificarProducto_Click(object sender, EventArgs e)
        {
            MetodoProducto("U");
            MostrarProductos();

        }

        private void btnEliminarProducto_Click(object sender, EventArgs e)
        {
            MetodoProducto("D");
            MostrarProductos();

        }

        private void btnAgregarImagenProducto_Click(object sender, EventArgs e)
        {
            // Configura el OpenFileDialog
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Archivos de imagen|*.jpg;*.jpeg;*.png;*.gif;*.bmp|Todos los archivos|*.*";
            openFileDialog.Title = "Seleccionar imagen";

            // Muestra el cuadro de diálogo
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                // Obtiene la ruta de la imagen seleccionada
                string rutaImagen = openFileDialog.FileName;

                try
                {
                    // Carga la imagen en el PictureBox
                    PBInsertarImagenProducto.Image = new System.Drawing.Bitmap(rutaImagen);
                    FOTOORDEN2 = rutaImagen;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error al cargar la imagen: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnModificarImagenproducto_Click(object sender, EventArgs e)
        {
            // Configura el OpenFileDialog
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Archivos de imagen|*.jpg;*.jpeg;*.png;*.gif;*.bmp|Todos los archivos|*.*";
            openFileDialog.Title = "Seleccionar imagen";

            // Muestra el cuadro de diálogo
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                // Obtiene la ruta de la imagen seleccionada
                string rutaImagen = openFileDialog.FileName;

                try
                {
                    // Carga la imagen en el PictureBox
                    PBProductoModificar.Image = new System.Drawing.Bitmap(rutaImagen);
                    FOTOORDEN2 = rutaImagen;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error al cargar la imagen: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnBEMempleado_Click(object sender, EventArgs e)
        {
            MostrarEmpleados();
        }

        private void btnEmpleadoNuevo_Click(object sender, EventArgs e)
        {

        }
    }
}
