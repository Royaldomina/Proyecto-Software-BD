﻿namespace BakeBookerGUI_1._0
{
    partial class frmADMIN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.panelHome = new System.Windows.Forms.Panel();
            this.pbxHome = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnEmpleados = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnClientes = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnPedidos = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.btnProductos = new System.Windows.Forms.Button();
            this.panelCentral = new System.Windows.Forms.Panel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.btnReportes = new System.Windows.Forms.Button();
            this.tabCentral = new System.Windows.Forms.TabControl();
            this.tabHome = new System.Windows.Forms.TabPage();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.labelBienvenida = new System.Windows.Forms.Label();
            this.tabEmpleados = new System.Windows.Forms.TabPage();
            this.panelEmpleados = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnBEMempleado = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.btnEmpleadoNuevo = new System.Windows.Forms.Button();
            this.tabEmpleado = new System.Windows.Forms.TabControl();
            this.tabEmpleadoNuevo = new System.Windows.Forms.TabPage();
            this.panelNuevoEmpleado = new System.Windows.Forms.Panel();
            this.panel66 = new System.Windows.Forms.Panel();
            this.panel67 = new System.Windows.Forms.Panel();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.txtContraseñaEmpleado = new System.Windows.Forms.TextBox();
            this.txtUsuarioEmpleado = new System.Windows.Forms.TextBox();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.btnCrearEmpleado = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.rbdGeneral = new System.Windows.Forms.RadioButton();
            this.txtApellidoEmpleado = new System.Windows.Forms.TextBox();
            this.rbdAdmin = new System.Windows.Forms.RadioButton();
            this.txtnombreEmpleado = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tabEmpleadoBuscar = new System.Windows.Forms.TabPage();
            this.gbxMostrarEmpleados = new System.Windows.Forms.GroupBox();
            this.panel68 = new System.Windows.Forms.Panel();
            this.txtIDEmpleado2 = new System.Windows.Forms.TextBox();
            this.label57 = new System.Windows.Forms.Label();
            this.panel18 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.rdbGeneral = new System.Windows.Forms.RadioButton();
            this.txtApellidoEmpleado2 = new System.Windows.Forms.TextBox();
            this.rdbAdmin = new System.Windows.Forms.RadioButton();
            this.txtNombreEmpleado2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtContraseñaEmpleado2 = new System.Windows.Forms.TextBox();
            this.txtUsuarioEmpleado2 = new System.Windows.Forms.TextBox();
            this.btnModificarEmpleado = new System.Windows.Forms.Button();
            this.btnEliminarEmpleado = new System.Windows.Forms.Button();
            this.dgvResultadosEmpleados = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.radNombreEmpleado = new System.Windows.Forms.RadioButton();
            this.radIDempleado = new System.Windows.Forms.RadioButton();
            this.btnBuscarEmpleado = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtBuscarEmpleado = new System.Windows.Forms.TextBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.tabClientes = new System.Windows.Forms.TabPage();
            this.panel21 = new System.Windows.Forms.Panel();
            this.btnBEMclientes = new System.Windows.Forms.Button();
            this.tabCliente = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel30 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel35 = new System.Windows.Forms.Panel();
            this.panel36 = new System.Windows.Forms.Panel();
            this.panel37 = new System.Windows.Forms.Panel();
            this.txtNumExteriorCliente = new System.Windows.Forms.TextBox();
            this.txtCalleCliente = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.txtRFCCliente = new System.Windows.Forms.TextBox();
            this.txtNumInteriorCliente = new System.Windows.Forms.TextBox();
            this.panel31 = new System.Windows.Forms.Panel();
            this.panel32 = new System.Windows.Forms.Panel();
            this.panel33 = new System.Windows.Forms.Panel();
            this.panel34 = new System.Windows.Forms.Panel();
            this.btnCrearCliente = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.txtApellidoCliente = new System.Windows.Forms.TextBox();
            this.txtNombreCliente = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.txtTelefonoCliente = new System.Windows.Forms.TextBox();
            this.txtCorreoCliente = new System.Windows.Forms.TextBox();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.gpbMostrarCliente = new System.Windows.Forms.GroupBox();
            this.panel65 = new System.Windows.Forms.Panel();
            this.txtIDBCliente = new System.Windows.Forms.TextBox();
            this.panel11 = new System.Windows.Forms.Panel();
            this.label54 = new System.Windows.Forms.Label();
            this.panel23 = new System.Windows.Forms.Panel();
            this.panel24 = new System.Windows.Forms.Panel();
            this.panel25 = new System.Windows.Forms.Panel();
            this.txtNumExteriorBCliente = new System.Windows.Forms.TextBox();
            this.txtCalleBCliente = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txtRFCBCliente = new System.Windows.Forms.TextBox();
            this.txtNumInteriorBCliente = new System.Windows.Forms.TextBox();
            this.panel26 = new System.Windows.Forms.Panel();
            this.panel27 = new System.Windows.Forms.Panel();
            this.panel38 = new System.Windows.Forms.Panel();
            this.panel39 = new System.Windows.Forms.Panel();
            this.txtApellidoBCliente = new System.Windows.Forms.TextBox();
            this.txtNombreBCliente = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.txtTelefonoBCliente = new System.Windows.Forms.TextBox();
            this.txtCorreoBCliente = new System.Windows.Forms.TextBox();
            this.btnModificarCliente = new System.Windows.Forms.Button();
            this.btnEliminarCliente = new System.Windows.Forms.Button();
            this.dgvResultadosClientes = new System.Windows.Forms.DataGridView();
            this.panel28 = new System.Windows.Forms.Panel();
            this.radNombreCliente = new System.Windows.Forms.RadioButton();
            this.btnBuscarCliente = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.txtBuscarCliente = new System.Windows.Forms.TextBox();
            this.panel29 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel20 = new System.Windows.Forms.Panel();
            this.panel22 = new System.Windows.Forms.Panel();
            this.btnClienteNuevo = new System.Windows.Forms.Button();
            this.tabPedidos = new System.Windows.Forms.TabPage();
            this.tabPedido = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panel85 = new System.Windows.Forms.Panel();
            this.label38 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.btnCrearPedido = new System.Windows.Forms.Button();
            this.txtPedidos_Anticipo = new System.Windows.Forms.TextBox();
            this.DTPFechaDeEntregaPedido = new System.Windows.Forms.DateTimePicker();
            this.radiobuttonRecoger = new System.Windows.Forms.RadioButton();
            this.label49 = new System.Windows.Forms.Label();
            this.radioButtonLlevar = new System.Windows.Forms.RadioButton();
            this.panel83 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.asdasdasd = new System.Windows.Forms.Label();
            this.panel74 = new System.Windows.Forms.Panel();
            this.DGVListaPedido = new System.Windows.Forms.DataGridView();
            this.label58 = new System.Windows.Forms.Label();
            this.btnPedidoPastel = new System.Windows.Forms.Button();
            this.btnPedidoProducto = new System.Windows.Forms.Button();
            this.panel62 = new System.Windows.Forms.Panel();
            this.panel63 = new System.Windows.Forms.Panel();
            this.btnTerminarPedido = new System.Windows.Forms.Button();
            this.btnAgregarAPedido = new System.Windows.Forms.Button();
            this.PanelPastel = new System.Windows.Forms.Panel();
            this.PedidosYProductos = new System.Windows.Forms.TabControl();
            this.Pedido = new System.Windows.Forms.TabPage();
            this.CBBTamañoPedido = new System.Windows.Forms.ComboBox();
            this.CBBRellenoPan = new System.Windows.Forms.ComboBox();
            this.panel64 = new System.Windows.Forms.Panel();
            this.pbxImagenPastel = new System.Windows.Forms.PictureBox();
            this.label52 = new System.Windows.Forms.Label();
            this.CBBCantdidadPisos = new System.Windows.Forms.ComboBox();
            this.txtPrecioPastel = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.btnCargarImagen = new System.Windows.Forms.Button();
            this.txtCantidaddePersonas = new System.Windows.Forms.TextBox();
            this.panel49 = new System.Windows.Forms.Panel();
            this.panel47 = new System.Windows.Forms.Panel();
            this.label32 = new System.Windows.Forms.Label();
            this.panel46 = new System.Windows.Forms.Panel();
            this.panel45 = new System.Windows.Forms.Panel();
            this.label47 = new System.Windows.Forms.Label();
            this.txtNotasPedido = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.panel44 = new System.Windows.Forms.Panel();
            this.txtTipoDePan = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.Producto = new System.Windows.Forms.TabPage();
            this.panel73 = new System.Windows.Forms.Panel();
            this.label76 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.panel69 = new System.Windows.Forms.Panel();
            this.panel70 = new System.Windows.Forms.Panel();
            this.label74 = new System.Windows.Forms.Label();
            this.panel71 = new System.Windows.Forms.Panel();
            this.panel72 = new System.Windows.Forms.Panel();
            this.label75 = new System.Windows.Forms.Label();
            this.LBLCantidadDisponible = new System.Windows.Forms.Label();
            this.LBLcostoUnitarioProducto = new System.Windows.Forms.Label();
            this.LBLIDPRODUCTO = new System.Windows.Forms.Label();
            this.comboboxCantidadProducto = new System.Windows.Forms.ComboBox();
            this.CBBNombreProducto = new System.Windows.Forms.ComboBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.TXTDescripcion = new System.Windows.Forms.TextBox();
            this.label63 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.panel50 = new System.Windows.Forms.Panel();
            this.panel43 = new System.Windows.Forms.Panel();
            this.btnBuscarClientePedido = new System.Windows.Forms.Button();
            this.label53 = new System.Windows.Forms.Label();
            this.DGVPEDIDOINICIO = new System.Windows.Forms.DataGridView();
            this.panel51 = new System.Windows.Forms.Panel();
            this.label33 = new System.Windows.Forms.Label();
            this.txtNombreClientePedido = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.panel48 = new System.Windows.Forms.Panel();
            this.btnPedidoMod = new System.Windows.Forms.Button();
            this.btnOrdenMod = new System.Windows.Forms.Button();
            this.bntProductoMod = new System.Windows.Forms.Button();
            this.panel86 = new System.Windows.Forms.Panel();
            this.DGVBUSQUEDAPEDIDO = new System.Windows.Forms.DataGridView();
            this.label79 = new System.Windows.Forms.Label();
            this.panel87 = new System.Windows.Forms.Panel();
            this.DGVBUSQUEDADETALLESPEDIDO = new System.Windows.Forms.DataGridView();
            this.label83 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.TABMODIFICARPEDIDO = new System.Windows.Forms.TabControl();
            this.Pedido2 = new System.Windows.Forms.TabPage();
            this.panel106 = new System.Windows.Forms.Panel();
            this.label88 = new System.Windows.Forms.Label();
            this.txtIDPEDIDOMODFICIAR = new System.Windows.Forms.TextBox();
            this.RADRECOGERMODIFICAR = new System.Windows.Forms.RadioButton();
            this.RADLLEVARMODIFICAR = new System.Windows.Forms.RadioButton();
            this.DTPFECHAENTREGAMOD = new System.Windows.Forms.DateTimePicker();
            this.DTPFECHAPEDIDOMODIFICAR = new System.Windows.Forms.DateTimePicker();
            this.panel82 = new System.Windows.Forms.Panel();
            this.label51 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.TXTANTICIPOMODIFICAR = new System.Windows.Forms.TextBox();
            this.panel84 = new System.Windows.Forms.Panel();
            this.TXTTOTALMODIFICAR = new System.Windows.Forms.TextBox();
            this.panel88 = new System.Windows.Forms.Panel();
            this.label62 = new System.Windows.Forms.Label();
            this.panel89 = new System.Windows.Forms.Panel();
            this.panel90 = new System.Windows.Forms.Panel();
            this.label72 = new System.Windows.Forms.Label();
            this.panel91 = new System.Windows.Forms.Panel();
            this.TXTIDCLIENTEMODIFICAR = new System.Windows.Forms.TextBox();
            this.label78 = new System.Windows.Forms.Label();
            this.panel57 = new System.Windows.Forms.Panel();
            this.panel58 = new System.Windows.Forms.Panel();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.Orden2 = new System.Windows.Forms.TabPage();
            this.label34 = new System.Windows.Forms.Label();
            this.txtIDOrdenModificar = new System.Windows.Forms.TextBox();
            this.txtIDPEDIDOMODIFICAR = new System.Windows.Forms.TextBox();
            this.panel104 = new System.Windows.Forms.Panel();
            this.label87 = new System.Windows.Forms.Label();
            this.CBBTamañodePedidoModificar = new System.Windows.Forms.ComboBox();
            this.CBBRellenodePanModificar = new System.Windows.Forms.ComboBox();
            this.panel52 = new System.Windows.Forms.Panel();
            this.label29 = new System.Windows.Forms.Label();
            this.CBBCantidadDePisosModificar = new System.Windows.Forms.ComboBox();
            this.txtPrecioOrdenModificar = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.txtCantidadDePersonasModificar = new System.Windows.Forms.TextBox();
            this.panel53 = new System.Windows.Forms.Panel();
            this.panel54 = new System.Windows.Forms.Panel();
            this.label41 = new System.Windows.Forms.Label();
            this.panel55 = new System.Windows.Forms.Panel();
            this.panel56 = new System.Windows.Forms.Panel();
            this.label42 = new System.Windows.Forms.Label();
            this.txtNotasModificar = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.panel59 = new System.Windows.Forms.Panel();
            this.txtTipodePanModificar = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.PBMODIFICARPEDIDO = new System.Windows.Forms.PictureBox();
            this.btnSubirImagenModificar = new System.Windows.Forms.Button();
            this.Producto2 = new System.Windows.Forms.TabPage();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.panel95 = new System.Windows.Forms.Panel();
            this.label84 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.panel105 = new System.Windows.Forms.Panel();
            this.label86 = new System.Windows.Forms.Label();
            this.txtIDPEDIDOPRODUCTOMODIFICAR = new System.Windows.Forms.TextBox();
            this.panel93 = new System.Windows.Forms.Panel();
            this.label81 = new System.Windows.Forms.Label();
            this.txtIDPedidoModifcar = new System.Windows.Forms.TextBox();
            this.panel96 = new System.Windows.Forms.Panel();
            this.label85 = new System.Windows.Forms.Label();
            this.txtIDPRODUCTOMODIFICAR = new System.Windows.Forms.TextBox();
            this.panel92 = new System.Windows.Forms.Panel();
            this.label80 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.panel94 = new System.Windows.Forms.Panel();
            this.CBBCANTIDADMODIFICAR = new System.Windows.Forms.ComboBox();
            this.btnModGen = new System.Windows.Forms.Button();
            this.btnEliminarGen = new System.Windows.Forms.Button();
            this.panel60 = new System.Windows.Forms.Panel();
            this.RADTELEFONOPEDIDO = new System.Windows.Forms.RadioButton();
            this.RADNOMBREPEDIDO = new System.Windows.Forms.RadioButton();
            this.DGVCLIENTEBUSQUEDA = new System.Windows.Forms.DataGridView();
            this.btnBuscarPedido = new System.Windows.Forms.Button();
            this.label46 = new System.Windows.Forms.Label();
            this.txtBusquedaPedido = new System.Windows.Forms.TextBox();
            this.panel61 = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.panel40 = new System.Windows.Forms.Panel();
            this.panel41 = new System.Windows.Forms.Panel();
            this.btnBEMPedidos = new System.Windows.Forms.Button();
            this.panel42 = new System.Windows.Forms.Panel();
            this.btnIniciarPedido = new System.Windows.Forms.Button();
            this.tabProductos = new System.Windows.Forms.TabPage();
            this.panel97 = new System.Windows.Forms.Panel();
            this.btnModificarProducto2 = new System.Windows.Forms.Button();
            this.btnAgregarProducto = new System.Windows.Forms.Button();
            this.panel75 = new System.Windows.Forms.Panel();
            this.TABCONTROLPRODUCTO = new System.Windows.Forms.TabControl();
            this.InsertarProducto = new System.Windows.Forms.TabPage();
            this.PBInsertarImagenProducto = new System.Windows.Forms.PictureBox();
            this.btnAgregarImagenProducto = new System.Windows.Forms.Button();
            this.label77 = new System.Windows.Forms.Label();
            this.txtNombreProducto = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.txtPrecioProducto = new System.Windows.Forms.TextBox();
            this.label89 = new System.Windows.Forms.Label();
            this.panel98 = new System.Windows.Forms.Panel();
            this.label90 = new System.Windows.Forms.Label();
            this.DTPFechaExpiracionProducto = new System.Windows.Forms.DateTimePicker();
            this.label91 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.txtDescripcionProducto = new System.Windows.Forms.TextBox();
            this.panel99 = new System.Windows.Forms.Panel();
            this.txtCantidadProducto = new System.Windows.Forms.TextBox();
            this.DTPFechaIngresoProducto = new System.Windows.Forms.DateTimePicker();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.panel100 = new System.Windows.Forms.Panel();
            this.panel101 = new System.Windows.Forms.Panel();
            this.panel102 = new System.Windows.Forms.Panel();
            this.panel103 = new System.Windows.Forms.Panel();
            this.Modificar = new System.Windows.Forms.TabPage();
            this.PBProductoModificar = new System.Windows.Forms.PictureBox();
            this.btnModificarImagenproducto = new System.Windows.Forms.Button();
            this.lblIDProducto2 = new System.Windows.Forms.Label();
            this.btnModificarProducto = new System.Windows.Forms.Button();
            this.label65 = new System.Windows.Forms.Label();
            this.btnEliminarProducto = new System.Windows.Forms.Button();
            this.txtNombreProducto2 = new System.Windows.Forms.TextBox();
            this.txtPrecioProducto2 = new System.Windows.Forms.TextBox();
            this.label71 = new System.Windows.Forms.Label();
            this.panel77 = new System.Windows.Forms.Panel();
            this.label70 = new System.Windows.Forms.Label();
            this.DTPFecha_expiracion = new System.Windows.Forms.DateTimePicker();
            this.label69 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.txtDescripcionProducto2 = new System.Windows.Forms.TextBox();
            this.panel76 = new System.Windows.Forms.Panel();
            this.txtCantidadProducto2 = new System.Windows.Forms.TextBox();
            this.DTPFecha_ingreso = new System.Windows.Forms.DateTimePicker();
            this.label68 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.panel81 = new System.Windows.Forms.Panel();
            this.panel78 = new System.Windows.Forms.Panel();
            this.panel80 = new System.Windows.Forms.Panel();
            this.panel79 = new System.Windows.Forms.Panel();
            this.dgvResultadoProductos = new System.Windows.Forms.DataGridView();
            this.tabReportes = new System.Windows.Forms.TabPage();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.label95 = new System.Windows.Forms.Label();
            this.DTPfechadepedido = new System.Windows.Forms.DateTimePicker();
            this.panelHome.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxHome)).BeginInit();
            this.panel5.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panelCentral.SuspendLayout();
            this.panel19.SuspendLayout();
            this.tabCentral.SuspendLayout();
            this.tabHome.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabEmpleados.SuspendLayout();
            this.panelEmpleados.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel6.SuspendLayout();
            this.tabEmpleado.SuspendLayout();
            this.tabEmpleadoNuevo.SuspendLayout();
            this.panelNuevoEmpleado.SuspendLayout();
            this.tabEmpleadoBuscar.SuspendLayout();
            this.gbxMostrarEmpleados.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResultadosEmpleados)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.tabClientes.SuspendLayout();
            this.panel21.SuspendLayout();
            this.tabCliente.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panel30.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.gpbMostrarCliente.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResultadosClientes)).BeginInit();
            this.panel28.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel20.SuspendLayout();
            this.panel22.SuspendLayout();
            this.tabPedidos.SuspendLayout();
            this.tabPedido.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.panel85.SuspendLayout();
            this.panel83.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel74.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVListaPedido)).BeginInit();
            this.panel62.SuspendLayout();
            this.panel63.SuspendLayout();
            this.PanelPastel.SuspendLayout();
            this.PedidosYProductos.SuspendLayout();
            this.Pedido.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxImagenPastel)).BeginInit();
            this.Producto.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.panel43.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVPEDIDOINICIO)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.panel48.SuspendLayout();
            this.panel86.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVBUSQUEDAPEDIDO)).BeginInit();
            this.panel87.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVBUSQUEDADETALLESPEDIDO)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.TABMODIFICARPEDIDO.SuspendLayout();
            this.Pedido2.SuspendLayout();
            this.Orden2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PBMODIFICARPEDIDO)).BeginInit();
            this.Producto2.SuspendLayout();
            this.panel60.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVCLIENTEBUSQUEDA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panel40.SuspendLayout();
            this.panel41.SuspendLayout();
            this.panel42.SuspendLayout();
            this.tabProductos.SuspendLayout();
            this.panel97.SuspendLayout();
            this.panel75.SuspendLayout();
            this.TABCONTROLPRODUCTO.SuspendLayout();
            this.InsertarProducto.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PBInsertarImagenProducto)).BeginInit();
            this.Modificar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PBProductoModificar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResultadoProductos)).BeginInit();
            this.tabReportes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.SuspendLayout();
            // 
            // panelHome
            // 
            this.panelHome.Controls.Add(this.pbxHome);
            this.panelHome.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panelHome.Location = new System.Drawing.Point(12, 0);
            this.panelHome.Name = "panelHome";
            this.panelHome.Size = new System.Drawing.Size(184, 76);
            this.panelHome.TabIndex = 3;
            // 
            // pbxHome
            // 
            this.pbxHome.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pbxHome.Enabled = false;
            this.pbxHome.Image = global::BakeBookerGUI_1._0.Properties.Resources.Logo_para_pastelería_postres_minimalista_rosa__1_;
            this.pbxHome.Location = new System.Drawing.Point(3, 3);
            this.pbxHome.Name = "pbxHome";
            this.pbxHome.Size = new System.Drawing.Size(178, 70);
            this.pbxHome.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxHome.TabIndex = 1;
            this.pbxHome.TabStop = false;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.btnEmpleados);
            this.panel5.Location = new System.Drawing.Point(202, 3);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(210, 73);
            this.panel5.TabIndex = 5;
            // 
            // btnEmpleados
            // 
            this.btnEmpleados.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnEmpleados.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEmpleados.Font = new System.Drawing.Font("Segoe UI Semibold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmpleados.ForeColor = System.Drawing.Color.White;
            this.btnEmpleados.Image = global::BakeBookerGUI_1._0.Properties.Resources.tarjeta_de_identificacion;
            this.btnEmpleados.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEmpleados.Location = new System.Drawing.Point(3, 0);
            this.btnEmpleados.Name = "btnEmpleados";
            this.btnEmpleados.Size = new System.Drawing.Size(204, 70);
            this.btnEmpleados.TabIndex = 1;
            this.btnEmpleados.Text = "Empleados";
            this.btnEmpleados.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEmpleados.UseVisualStyleBackColor = true;
            this.btnEmpleados.Click += new System.EventHandler(this.btnEmpleados_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnClientes);
            this.panel2.Location = new System.Drawing.Point(418, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(199, 73);
            this.panel2.TabIndex = 4;
            // 
            // btnClientes
            // 
            this.btnClientes.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClientes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClientes.Font = new System.Drawing.Font("Segoe UI Semibold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClientes.ForeColor = System.Drawing.Color.White;
            this.btnClientes.Image = global::BakeBookerGUI_1._0.Properties.Resources.directorio_telefonico__1_;
            this.btnClientes.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClientes.Location = new System.Drawing.Point(0, 0);
            this.btnClientes.Name = "btnClientes";
            this.btnClientes.Size = new System.Drawing.Size(196, 70);
            this.btnClientes.TabIndex = 1;
            this.btnClientes.Text = "Clientes";
            this.btnClientes.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnClientes.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btnPedidos);
            this.panel3.Location = new System.Drawing.Point(623, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(207, 73);
            this.panel3.TabIndex = 6;
            // 
            // btnPedidos
            // 
            this.btnPedidos.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPedidos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPedidos.Font = new System.Drawing.Font("Segoe UI Semibold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPedidos.ForeColor = System.Drawing.Color.White;
            this.btnPedidos.Image = global::BakeBookerGUI_1._0.Properties.Resources.orden;
            this.btnPedidos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPedidos.Location = new System.Drawing.Point(3, 3);
            this.btnPedidos.Name = "btnPedidos";
            this.btnPedidos.Size = new System.Drawing.Size(204, 70);
            this.btnPedidos.TabIndex = 1;
            this.btnPedidos.Text = "Pedidos";
            this.btnPedidos.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnPedidos.UseVisualStyleBackColor = true;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.btnProductos);
            this.panel7.Location = new System.Drawing.Point(836, 3);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(202, 73);
            this.panel7.TabIndex = 7;
            // 
            // btnProductos
            // 
            this.btnProductos.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnProductos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProductos.Font = new System.Drawing.Font("Segoe UI Semibold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProductos.ForeColor = System.Drawing.Color.White;
            this.btnProductos.Image = global::BakeBookerGUI_1._0.Properties.Resources.pie_de_manzana;
            this.btnProductos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnProductos.Location = new System.Drawing.Point(3, 3);
            this.btnProductos.Name = "btnProductos";
            this.btnProductos.Size = new System.Drawing.Size(199, 70);
            this.btnProductos.TabIndex = 1;
            this.btnProductos.Text = "Productos";
            this.btnProductos.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnProductos.UseVisualStyleBackColor = true;
            // 
            // panelCentral
            // 
            this.panelCentral.AutoSize = true;
            this.panelCentral.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panelCentral.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panelCentral.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelCentral.Controls.Add(this.panel19);
            this.panelCentral.Controls.Add(this.panelHome);
            this.panelCentral.Controls.Add(this.panel7);
            this.panelCentral.Controls.Add(this.panel5);
            this.panelCentral.Controls.Add(this.panel3);
            this.panelCentral.Controls.Add(this.panel2);
            this.panelCentral.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelCentral.Location = new System.Drawing.Point(0, 0);
            this.panelCentral.Name = "panelCentral";
            this.panelCentral.Size = new System.Drawing.Size(1406, 86);
            this.panelCentral.TabIndex = 8;
            // 
            // panel19
            // 
            this.panel19.Controls.Add(this.btnReportes);
            this.panel19.Location = new System.Drawing.Point(1044, 6);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(202, 73);
            this.panel19.TabIndex = 8;
            // 
            // btnReportes
            // 
            this.btnReportes.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnReportes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReportes.Font = new System.Drawing.Font("Segoe UI Semibold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReportes.ForeColor = System.Drawing.Color.White;
            this.btnReportes.Image = global::BakeBookerGUI_1._0.Properties.Resources.tabla_de_crecimiento;
            this.btnReportes.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReportes.Location = new System.Drawing.Point(3, 0);
            this.btnReportes.Name = "btnReportes";
            this.btnReportes.Size = new System.Drawing.Size(196, 70);
            this.btnReportes.TabIndex = 1;
            this.btnReportes.Text = "Reportes";
            this.btnReportes.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnReportes.UseVisualStyleBackColor = true;
            // 
            // tabCentral
            // 
            this.tabCentral.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tabCentral.Controls.Add(this.tabHome);
            this.tabCentral.Controls.Add(this.tabEmpleados);
            this.tabCentral.Controls.Add(this.tabClientes);
            this.tabCentral.Controls.Add(this.tabPedidos);
            this.tabCentral.Controls.Add(this.tabProductos);
            this.tabCentral.Controls.Add(this.tabReportes);
            this.tabCentral.Controls.Add(this.tabPage5);
            this.tabCentral.HotTrack = true;
            this.tabCentral.Location = new System.Drawing.Point(0, 92);
            this.tabCentral.Multiline = true;
            this.tabCentral.Name = "tabCentral";
            this.tabCentral.SelectedIndex = 0;
            this.tabCentral.Size = new System.Drawing.Size(1403, 788);
            this.tabCentral.TabIndex = 9;
            // 
            // tabHome
            // 
            this.tabHome.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(153)))));
            this.tabHome.Controls.Add(this.pictureBox1);
            this.tabHome.Controls.Add(this.labelBienvenida);
            this.tabHome.Location = new System.Drawing.Point(4, 25);
            this.tabHome.Name = "tabHome";
            this.tabHome.Size = new System.Drawing.Size(1395, 759);
            this.tabHome.TabIndex = 5;
            this.tabHome.Text = "Inicio";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = global::BakeBookerGUI_1._0.Properties.Resources.BIENVENIDO__1_;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1395, 759);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // labelBienvenida
            // 
            this.labelBienvenida.AutoSize = true;
            this.labelBienvenida.BackColor = System.Drawing.Color.White;
            this.labelBienvenida.Location = new System.Drawing.Point(105, 304);
            this.labelBienvenida.Name = "labelBienvenida";
            this.labelBienvenida.Size = new System.Drawing.Size(0, 13);
            this.labelBienvenida.TabIndex = 1;
            // 
            // tabEmpleados
            // 
            this.tabEmpleados.BackColor = System.Drawing.Color.White;
            this.tabEmpleados.Controls.Add(this.panelEmpleados);
            this.tabEmpleados.Controls.Add(this.tabEmpleado);
            this.tabEmpleados.Location = new System.Drawing.Point(4, 25);
            this.tabEmpleados.Name = "tabEmpleados";
            this.tabEmpleados.Padding = new System.Windows.Forms.Padding(3);
            this.tabEmpleados.Size = new System.Drawing.Size(1395, 759);
            this.tabEmpleados.TabIndex = 0;
            this.tabEmpleados.Text = "Empleados";
            // 
            // panelEmpleados
            // 
            this.panelEmpleados.BackColor = System.Drawing.Color.White;
            this.panelEmpleados.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelEmpleados.Controls.Add(this.panel4);
            this.panelEmpleados.Controls.Add(this.panel6);
            this.panelEmpleados.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelEmpleados.Location = new System.Drawing.Point(3, 3);
            this.panelEmpleados.Name = "panelEmpleados";
            this.panelEmpleados.Size = new System.Drawing.Size(1389, 86);
            this.panelEmpleados.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.Controls.Add(this.btnBEMempleado);
            this.panel4.Location = new System.Drawing.Point(243, 2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(238, 81);
            this.panel4.TabIndex = 1;
            // 
            // btnBEMempleado
            // 
            this.btnBEMempleado.BackColor = System.Drawing.Color.Transparent;
            this.btnBEMempleado.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnBEMempleado.FlatAppearance.BorderSize = 0;
            this.btnBEMempleado.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.btnBEMempleado.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBEMempleado.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBEMempleado.Image = global::BakeBookerGUI_1._0.Properties.Resources.personalizacion;
            this.btnBEMempleado.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btnBEMempleado.Location = new System.Drawing.Point(3, 3);
            this.btnBEMempleado.Name = "btnBEMempleado";
            this.btnBEMempleado.Size = new System.Drawing.Size(231, 75);
            this.btnBEMempleado.TabIndex = 2;
            this.btnBEMempleado.Text = "Buscar, Eliminar o Modificar";
            this.btnBEMempleado.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnBEMempleado.UseVisualStyleBackColor = false;
            this.btnBEMempleado.Click += new System.EventHandler(this.btnBEMempleado_Click);
            // 
            // panel6
            // 
            this.panel6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel6.Controls.Add(this.btnEmpleadoNuevo);
            this.panel6.Location = new System.Drawing.Point(2, 2);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(228, 82);
            this.panel6.TabIndex = 2;
            // 
            // btnEmpleadoNuevo
            // 
            this.btnEmpleadoNuevo.BackColor = System.Drawing.Color.Transparent;
            this.btnEmpleadoNuevo.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnEmpleadoNuevo.FlatAppearance.BorderSize = 0;
            this.btnEmpleadoNuevo.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.btnEmpleadoNuevo.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnEmpleadoNuevo.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmpleadoNuevo.Image = global::BakeBookerGUI_1._0.Properties.Resources.usuario__4_;
            this.btnEmpleadoNuevo.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btnEmpleadoNuevo.Location = new System.Drawing.Point(3, 3);
            this.btnEmpleadoNuevo.Name = "btnEmpleadoNuevo";
            this.btnEmpleadoNuevo.Size = new System.Drawing.Size(219, 79);
            this.btnEmpleadoNuevo.TabIndex = 2;
            this.btnEmpleadoNuevo.Text = "Nuevo Empleado";
            this.btnEmpleadoNuevo.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnEmpleadoNuevo.UseVisualStyleBackColor = false;
            this.btnEmpleadoNuevo.Click += new System.EventHandler(this.btnEmpleadoNuevo_Click);
            // 
            // tabEmpleado
            // 
            this.tabEmpleado.Controls.Add(this.tabEmpleadoNuevo);
            this.tabEmpleado.Controls.Add(this.tabEmpleadoBuscar);
            this.tabEmpleado.Location = new System.Drawing.Point(3, 95);
            this.tabEmpleado.Multiline = true;
            this.tabEmpleado.Name = "tabEmpleado";
            this.tabEmpleado.SelectedIndex = 0;
            this.tabEmpleado.Size = new System.Drawing.Size(1396, 664);
            this.tabEmpleado.TabIndex = 1;
            // 
            // tabEmpleadoNuevo
            // 
            this.tabEmpleadoNuevo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(156)))), ((int)(((byte)(156)))));
            this.tabEmpleadoNuevo.Controls.Add(this.panelNuevoEmpleado);
            this.tabEmpleadoNuevo.Location = new System.Drawing.Point(4, 22);
            this.tabEmpleadoNuevo.Name = "tabEmpleadoNuevo";
            this.tabEmpleadoNuevo.Padding = new System.Windows.Forms.Padding(3);
            this.tabEmpleadoNuevo.Size = new System.Drawing.Size(1388, 638);
            this.tabEmpleadoNuevo.TabIndex = 1;
            this.tabEmpleadoNuevo.Text = "Nuevo Empleado";
            // 
            // panelNuevoEmpleado
            // 
            this.panelNuevoEmpleado.BackColor = System.Drawing.Color.White;
            this.panelNuevoEmpleado.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelNuevoEmpleado.Controls.Add(this.panel66);
            this.panelNuevoEmpleado.Controls.Add(this.panel67);
            this.panelNuevoEmpleado.Controls.Add(this.label55);
            this.panelNuevoEmpleado.Controls.Add(this.label56);
            this.panelNuevoEmpleado.Controls.Add(this.txtContraseñaEmpleado);
            this.panelNuevoEmpleado.Controls.Add(this.txtUsuarioEmpleado);
            this.panelNuevoEmpleado.Controls.Add(this.panel15);
            this.panelNuevoEmpleado.Controls.Add(this.panel13);
            this.panelNuevoEmpleado.Controls.Add(this.panel12);
            this.panelNuevoEmpleado.Controls.Add(this.btnCrearEmpleado);
            this.panelNuevoEmpleado.Controls.Add(this.label3);
            this.panelNuevoEmpleado.Controls.Add(this.rbdGeneral);
            this.panelNuevoEmpleado.Controls.Add(this.txtApellidoEmpleado);
            this.panelNuevoEmpleado.Controls.Add(this.rbdAdmin);
            this.panelNuevoEmpleado.Controls.Add(this.txtnombreEmpleado);
            this.panelNuevoEmpleado.Controls.Add(this.label10);
            this.panelNuevoEmpleado.Controls.Add(this.label11);
            this.panelNuevoEmpleado.Controls.Add(this.label9);
            this.panelNuevoEmpleado.Location = new System.Drawing.Point(22, 27);
            this.panelNuevoEmpleado.Name = "panelNuevoEmpleado";
            this.panelNuevoEmpleado.Size = new System.Drawing.Size(1096, 398);
            this.panelNuevoEmpleado.TabIndex = 39;
            // 
            // panel66
            // 
            this.panel66.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel66.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel66.Location = new System.Drawing.Point(31, 295);
            this.panel66.Name = "panel66";
            this.panel66.Size = new System.Drawing.Size(624, 5);
            this.panel66.TabIndex = 64;
            // 
            // panel67
            // 
            this.panel67.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel67.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel67.Location = new System.Drawing.Point(33, 246);
            this.panel67.Name = "panel67";
            this.panel67.Size = new System.Drawing.Size(622, 5);
            this.panel67.TabIndex = 63;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(29, 259);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(113, 19);
            this.label55.TabIndex = 61;
            this.label55.Text = "CONTRASEÑA:";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.Location = new System.Drawing.Point(40, 210);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(79, 19);
            this.label56.TabIndex = 62;
            this.label56.Text = "USUARIO:";
            // 
            // txtContraseñaEmpleado
            // 
            this.txtContraseñaEmpleado.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContraseñaEmpleado.Location = new System.Drawing.Point(196, 258);
            this.txtContraseñaEmpleado.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtContraseñaEmpleado.Multiline = true;
            this.txtContraseñaEmpleado.Name = "txtContraseñaEmpleado";
            this.txtContraseñaEmpleado.Size = new System.Drawing.Size(459, 32);
            this.txtContraseñaEmpleado.TabIndex = 59;
            // 
            // txtUsuarioEmpleado
            // 
            this.txtUsuarioEmpleado.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUsuarioEmpleado.Location = new System.Drawing.Point(196, 209);
            this.txtUsuarioEmpleado.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtUsuarioEmpleado.Multiline = true;
            this.txtUsuarioEmpleado.Name = "txtUsuarioEmpleado";
            this.txtUsuarioEmpleado.Size = new System.Drawing.Size(459, 32);
            this.txtUsuarioEmpleado.TabIndex = 60;
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel15.Location = new System.Drawing.Point(30, 368);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(624, 5);
            this.panel15.TabIndex = 43;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel13.Location = new System.Drawing.Point(31, 193);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(624, 5);
            this.panel13.TabIndex = 41;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel12.Location = new System.Drawing.Point(31, 119);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(624, 5);
            this.panel12.TabIndex = 40;
            // 
            // btnCrearEmpleado
            // 
            this.btnCrearEmpleado.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCrearEmpleado.Font = new System.Drawing.Font("Gadugi", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCrearEmpleado.ForeColor = System.Drawing.Color.Black;
            this.btnCrearEmpleado.Image = global::BakeBookerGUI_1._0.Properties.Resources.subir;
            this.btnCrearEmpleado.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCrearEmpleado.Location = new System.Drawing.Point(661, 165);
            this.btnCrearEmpleado.Name = "btnCrearEmpleado";
            this.btnCrearEmpleado.Size = new System.Drawing.Size(410, 99);
            this.btnCrearEmpleado.TabIndex = 39;
            this.btnCrearEmpleado.Text = "Crear Empleado";
            this.btnCrearEmpleado.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCrearEmpleado.UseVisualStyleBackColor = true;
            this.btnCrearEmpleado.Click += new System.EventHandler(this.btnCrearEmpleado_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Gadugi", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(15, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(402, 21);
            this.label3.TabIndex = 33;
            this.label3.Text = "Ingrese todos los datos del nuevo empleado";
            // 
            // rbdGeneral
            // 
            this.rbdGeneral.AutoSize = true;
            this.rbdGeneral.Checked = true;
            this.rbdGeneral.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbdGeneral.Location = new System.Drawing.Point(228, 324);
            this.rbdGeneral.Margin = new System.Windows.Forms.Padding(4);
            this.rbdGeneral.Name = "rbdGeneral";
            this.rbdGeneral.Size = new System.Drawing.Size(81, 23);
            this.rbdGeneral.TabIndex = 38;
            this.rbdGeneral.TabStop = true;
            this.rbdGeneral.Text = "General";
            this.rbdGeneral.UseVisualStyleBackColor = true;
            // 
            // txtApellidoEmpleado
            // 
            this.txtApellidoEmpleado.Location = new System.Drawing.Point(196, 156);
            this.txtApellidoEmpleado.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtApellidoEmpleado.Multiline = true;
            this.txtApellidoEmpleado.Name = "txtApellidoEmpleado";
            this.txtApellidoEmpleado.Size = new System.Drawing.Size(459, 32);
            this.txtApellidoEmpleado.TabIndex = 28;
            // 
            // rbdAdmin
            // 
            this.rbdAdmin.AutoSize = true;
            this.rbdAdmin.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbdAdmin.Location = new System.Drawing.Point(465, 324);
            this.rbdAdmin.Margin = new System.Windows.Forms.Padding(4);
            this.rbdAdmin.Name = "rbdAdmin";
            this.rbdAdmin.Size = new System.Drawing.Size(127, 23);
            this.rbdAdmin.TabIndex = 37;
            this.rbdAdmin.Text = "Administrador";
            this.rbdAdmin.UseVisualStyleBackColor = true;
            // 
            // txtnombreEmpleado
            // 
            this.txtnombreEmpleado.Location = new System.Drawing.Point(197, 63);
            this.txtnombreEmpleado.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtnombreEmpleado.Multiline = true;
            this.txtnombreEmpleado.Name = "txtnombreEmpleado";
            this.txtnombreEmpleado.Size = new System.Drawing.Size(459, 32);
            this.txtnombreEmpleado.TabIndex = 29;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(27, 328);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(73, 19);
            this.label10.TabIndex = 31;
            this.label10.Text = "PUESTO: ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(40, 76);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(77, 19);
            this.label11.TabIndex = 32;
            this.label11.Text = "NOMBRE:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(40, 155);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 19);
            this.label9.TabIndex = 30;
            this.label9.Text = "APELLIDO";
            // 
            // tabEmpleadoBuscar
            // 
            this.tabEmpleadoBuscar.BackColor = System.Drawing.Color.White;
            this.tabEmpleadoBuscar.Controls.Add(this.gbxMostrarEmpleados);
            this.tabEmpleadoBuscar.Controls.Add(this.dgvResultadosEmpleados);
            this.tabEmpleadoBuscar.Controls.Add(this.panel1);
            this.tabEmpleadoBuscar.Location = new System.Drawing.Point(4, 22);
            this.tabEmpleadoBuscar.Name = "tabEmpleadoBuscar";
            this.tabEmpleadoBuscar.Padding = new System.Windows.Forms.Padding(3);
            this.tabEmpleadoBuscar.Size = new System.Drawing.Size(1388, 638);
            this.tabEmpleadoBuscar.TabIndex = 0;
            this.tabEmpleadoBuscar.Text = "Buscar";
            // 
            // gbxMostrarEmpleados
            // 
            this.gbxMostrarEmpleados.BackColor = System.Drawing.Color.Transparent;
            this.gbxMostrarEmpleados.Controls.Add(this.panel68);
            this.gbxMostrarEmpleados.Controls.Add(this.txtIDEmpleado2);
            this.gbxMostrarEmpleados.Controls.Add(this.label57);
            this.gbxMostrarEmpleados.Controls.Add(this.panel18);
            this.gbxMostrarEmpleados.Controls.Add(this.panel8);
            this.gbxMostrarEmpleados.Controls.Add(this.panel9);
            this.gbxMostrarEmpleados.Controls.Add(this.panel16);
            this.gbxMostrarEmpleados.Controls.Add(this.panel17);
            this.gbxMostrarEmpleados.Controls.Add(this.rdbGeneral);
            this.gbxMostrarEmpleados.Controls.Add(this.txtApellidoEmpleado2);
            this.gbxMostrarEmpleados.Controls.Add(this.rdbAdmin);
            this.gbxMostrarEmpleados.Controls.Add(this.txtNombreEmpleado2);
            this.gbxMostrarEmpleados.Controls.Add(this.label2);
            this.gbxMostrarEmpleados.Controls.Add(this.label4);
            this.gbxMostrarEmpleados.Controls.Add(this.label5);
            this.gbxMostrarEmpleados.Controls.Add(this.label6);
            this.gbxMostrarEmpleados.Controls.Add(this.label7);
            this.gbxMostrarEmpleados.Controls.Add(this.txtContraseñaEmpleado2);
            this.gbxMostrarEmpleados.Controls.Add(this.txtUsuarioEmpleado2);
            this.gbxMostrarEmpleados.Controls.Add(this.btnModificarEmpleado);
            this.gbxMostrarEmpleados.Controls.Add(this.btnEliminarEmpleado);
            this.gbxMostrarEmpleados.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gbxMostrarEmpleados.Font = new System.Drawing.Font("Gadugi", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbxMostrarEmpleados.Location = new System.Drawing.Point(848, 6);
            this.gbxMostrarEmpleados.Name = "gbxMostrarEmpleados";
            this.gbxMostrarEmpleados.Size = new System.Drawing.Size(534, 561);
            this.gbxMostrarEmpleados.TabIndex = 2;
            this.gbxMostrarEmpleados.TabStop = false;
            this.gbxMostrarEmpleados.Text = "Información del Empleado";
            // 
            // panel68
            // 
            this.panel68.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel68.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel68.Location = new System.Drawing.Point(14, 87);
            this.panel68.Name = "panel68";
            this.panel68.Size = new System.Drawing.Size(498, 5);
            this.panel68.TabIndex = 62;
            // 
            // txtIDEmpleado2
            // 
            this.txtIDEmpleado2.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIDEmpleado2.Location = new System.Drawing.Point(150, 46);
            this.txtIDEmpleado2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtIDEmpleado2.Multiline = true;
            this.txtIDEmpleado2.Name = "txtIDEmpleado2";
            this.txtIDEmpleado2.Size = new System.Drawing.Size(361, 32);
            this.txtIDEmpleado2.TabIndex = 60;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.Location = new System.Drawing.Point(8, 54);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(23, 16);
            this.label57.TabIndex = 61;
            this.label57.Text = "ID:";
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel18.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel18.Location = new System.Drawing.Point(18, 348);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(498, 5);
            this.panel18.TabIndex = 59;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel8.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel8.Location = new System.Drawing.Point(18, 294);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(498, 5);
            this.panel8.TabIndex = 58;
            this.panel8.Visible = false;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel9.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel9.Location = new System.Drawing.Point(15, 245);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(498, 5);
            this.panel9.TabIndex = 57;
            this.panel9.Visible = false;
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel16.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel16.Location = new System.Drawing.Point(15, 194);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(498, 5);
            this.panel16.TabIndex = 56;
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel17.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel17.Location = new System.Drawing.Point(15, 144);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(498, 5);
            this.panel17.TabIndex = 55;
            // 
            // rdbGeneral
            // 
            this.rdbGeneral.AutoSize = true;
            this.rdbGeneral.Checked = true;
            this.rdbGeneral.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbGeneral.Location = new System.Drawing.Point(150, 316);
            this.rdbGeneral.Margin = new System.Windows.Forms.Padding(4);
            this.rdbGeneral.Name = "rdbGeneral";
            this.rdbGeneral.Size = new System.Drawing.Size(69, 20);
            this.rdbGeneral.TabIndex = 54;
            this.rdbGeneral.TabStop = true;
            this.rdbGeneral.Text = "General";
            this.rdbGeneral.UseVisualStyleBackColor = true;
            // 
            // txtApellidoEmpleado2
            // 
            this.txtApellidoEmpleado2.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtApellidoEmpleado2.Location = new System.Drawing.Point(152, 157);
            this.txtApellidoEmpleado2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtApellidoEmpleado2.Multiline = true;
            this.txtApellidoEmpleado2.Name = "txtApellidoEmpleado2";
            this.txtApellidoEmpleado2.Size = new System.Drawing.Size(361, 32);
            this.txtApellidoEmpleado2.TabIndex = 44;
            // 
            // rdbAdmin
            // 
            this.rdbAdmin.AutoSize = true;
            this.rdbAdmin.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbAdmin.Location = new System.Drawing.Point(279, 316);
            this.rdbAdmin.Margin = new System.Windows.Forms.Padding(4);
            this.rdbAdmin.Name = "rdbAdmin";
            this.rdbAdmin.Size = new System.Drawing.Size(104, 20);
            this.rdbAdmin.TabIndex = 53;
            this.rdbAdmin.Text = "Administrador";
            this.rdbAdmin.UseVisualStyleBackColor = true;
            // 
            // txtNombreEmpleado2
            // 
            this.txtNombreEmpleado2.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombreEmpleado2.Location = new System.Drawing.Point(151, 103);
            this.txtNombreEmpleado2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNombreEmpleado2.Multiline = true;
            this.txtNombreEmpleado2.Name = "txtNombreEmpleado2";
            this.txtNombreEmpleado2.Size = new System.Drawing.Size(361, 32);
            this.txtNombreEmpleado2.TabIndex = 45;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(11, 318);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 16);
            this.label2.TabIndex = 47;
            this.label2.Text = "PUESTO: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(14, 265);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(88, 16);
            this.label4.TabIndex = 51;
            this.label4.Text = "CONTRASEÑA:";
            this.label4.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(9, 111);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 16);
            this.label5.TabIndex = 48;
            this.label5.Text = "NOMBRE:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(10, 216);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 16);
            this.label6.TabIndex = 52;
            this.label6.Text = "USUARIO:";
            this.label6.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(7, 162);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 16);
            this.label7.TabIndex = 46;
            this.label7.Text = "APELLIDO";
            // 
            // txtContraseñaEmpleado2
            // 
            this.txtContraseñaEmpleado2.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContraseñaEmpleado2.Location = new System.Drawing.Point(157, 257);
            this.txtContraseñaEmpleado2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtContraseñaEmpleado2.Multiline = true;
            this.txtContraseñaEmpleado2.Name = "txtContraseñaEmpleado2";
            this.txtContraseñaEmpleado2.Size = new System.Drawing.Size(361, 32);
            this.txtContraseñaEmpleado2.TabIndex = 49;
            this.txtContraseñaEmpleado2.Visible = false;
            // 
            // txtUsuarioEmpleado2
            // 
            this.txtUsuarioEmpleado2.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUsuarioEmpleado2.Location = new System.Drawing.Point(155, 208);
            this.txtUsuarioEmpleado2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtUsuarioEmpleado2.Multiline = true;
            this.txtUsuarioEmpleado2.Name = "txtUsuarioEmpleado2";
            this.txtUsuarioEmpleado2.Size = new System.Drawing.Size(361, 32);
            this.txtUsuarioEmpleado2.TabIndex = 50;
            this.txtUsuarioEmpleado2.Visible = false;
            // 
            // btnModificarEmpleado
            // 
            this.btnModificarEmpleado.BackColor = System.Drawing.Color.Transparent;
            this.btnModificarEmpleado.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnModificarEmpleado.FlatAppearance.BorderSize = 0;
            this.btnModificarEmpleado.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.btnModificarEmpleado.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnModificarEmpleado.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModificarEmpleado.Image = global::BakeBookerGUI_1._0.Properties.Resources.conversion;
            this.btnModificarEmpleado.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btnModificarEmpleado.Location = new System.Drawing.Point(302, 462);
            this.btnModificarEmpleado.Name = "btnModificarEmpleado";
            this.btnModificarEmpleado.Size = new System.Drawing.Size(216, 93);
            this.btnModificarEmpleado.TabIndex = 4;
            this.btnModificarEmpleado.Text = "Modificar Empleado";
            this.btnModificarEmpleado.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnModificarEmpleado.UseVisualStyleBackColor = false;
            this.btnModificarEmpleado.Click += new System.EventHandler(this.btnModificarEmpleado_Click);
            // 
            // btnEliminarEmpleado
            // 
            this.btnEliminarEmpleado.BackColor = System.Drawing.Color.Transparent;
            this.btnEliminarEmpleado.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnEliminarEmpleado.FlatAppearance.BorderSize = 0;
            this.btnEliminarEmpleado.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.btnEliminarEmpleado.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnEliminarEmpleado.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEliminarEmpleado.Image = global::BakeBookerGUI_1._0.Properties.Resources.contenedor_de_basura;
            this.btnEliminarEmpleado.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btnEliminarEmpleado.Location = new System.Drawing.Point(18, 462);
            this.btnEliminarEmpleado.Name = "btnEliminarEmpleado";
            this.btnEliminarEmpleado.Size = new System.Drawing.Size(205, 93);
            this.btnEliminarEmpleado.TabIndex = 3;
            this.btnEliminarEmpleado.Text = "Eliminar empleado";
            this.btnEliminarEmpleado.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnEliminarEmpleado.UseVisualStyleBackColor = false;
            this.btnEliminarEmpleado.Click += new System.EventHandler(this.btnEliminarEmpleado_Click);
            // 
            // dgvResultadosEmpleados
            // 
            this.dgvResultadosEmpleados.AllowUserToAddRows = false;
            this.dgvResultadosEmpleados.AllowUserToDeleteRows = false;
            this.dgvResultadosEmpleados.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvResultadosEmpleados.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.dgvResultadosEmpleados.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvResultadosEmpleados.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvResultadosEmpleados.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
            this.dgvResultadosEmpleados.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dgvResultadosEmpleados.ColumnHeadersHeight = 29;
            this.dgvResultadosEmpleados.Location = new System.Drawing.Point(3, 162);
            this.dgvResultadosEmpleados.Name = "dgvResultadosEmpleados";
            this.dgvResultadosEmpleados.ReadOnly = true;
            this.dgvResultadosEmpleados.RowHeadersWidth = 51;
            this.dgvResultadosEmpleados.RowTemplate.Height = 24;
            this.dgvResultadosEmpleados.Size = new System.Drawing.Size(828, 462);
            this.dgvResultadosEmpleados.TabIndex = 1;
            this.dgvResultadosEmpleados.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvResultadosEmpleados_CellClick_1);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.radNombreEmpleado);
            this.panel1.Controls.Add(this.radIDempleado);
            this.panel1.Controls.Add(this.btnBuscarEmpleado);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.txtBuscarEmpleado);
            this.panel1.Controls.Add(this.panel10);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Location = new System.Drawing.Point(3, 6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(828, 150);
            this.panel1.TabIndex = 0;
            // 
            // radNombreEmpleado
            // 
            this.radNombreEmpleado.AutoSize = true;
            this.radNombreEmpleado.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radNombreEmpleado.Location = new System.Drawing.Point(78, 45);
            this.radNombreEmpleado.Name = "radNombreEmpleado";
            this.radNombreEmpleado.Size = new System.Drawing.Size(85, 23);
            this.radNombreEmpleado.TabIndex = 20;
            this.radNombreEmpleado.Text = "Nombre";
            this.radNombreEmpleado.UseVisualStyleBackColor = true;
            // 
            // radIDempleado
            // 
            this.radIDempleado.AutoSize = true;
            this.radIDempleado.Checked = true;
            this.radIDempleado.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radIDempleado.Location = new System.Drawing.Point(22, 45);
            this.radIDempleado.Name = "radIDempleado";
            this.radIDempleado.Size = new System.Drawing.Size(43, 23);
            this.radIDempleado.TabIndex = 19;
            this.radIDempleado.TabStop = true;
            this.radIDempleado.Text = "ID";
            this.radIDempleado.UseVisualStyleBackColor = true;
            // 
            // btnBuscarEmpleado
            // 
            this.btnBuscarEmpleado.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarEmpleado.Image = global::BakeBookerGUI_1._0.Properties.Resources.ciencias_sociales__1_;
            this.btnBuscarEmpleado.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBuscarEmpleado.Location = new System.Drawing.Point(661, 75);
            this.btnBuscarEmpleado.Name = "btnBuscarEmpleado";
            this.btnBuscarEmpleado.Size = new System.Drawing.Size(155, 62);
            this.btnBuscarEmpleado.TabIndex = 18;
            this.btnBuscarEmpleado.Text = "Buscar";
            this.btnBuscarEmpleado.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBuscarEmpleado.UseVisualStyleBackColor = true;
            this.btnBuscarEmpleado.Click += new System.EventHandler(this.btnBuscaEmpleadoCriterio_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Gadugi", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(18, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(413, 19);
            this.label1.TabIndex = 17;
            this.label1.Text = "Selecciona un criterio e ingresa el empleado a buscar";
            // 
            // txtBuscarEmpleado
            // 
            this.txtBuscarEmpleado.AccessibleDescription = "Ingresar usuario";
            this.txtBuscarEmpleado.AccessibleName = "Ingresa usuario";
            this.txtBuscarEmpleado.AccessibleRole = System.Windows.Forms.AccessibleRole.Text;
            this.txtBuscarEmpleado.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtBuscarEmpleado.BackColor = System.Drawing.Color.White;
            this.txtBuscarEmpleado.Font = new System.Drawing.Font("Nirmala UI", 14F, System.Drawing.FontStyle.Bold);
            this.txtBuscarEmpleado.ForeColor = System.Drawing.Color.Black;
            this.txtBuscarEmpleado.Location = new System.Drawing.Point(82, 85);
            this.txtBuscarEmpleado.Margin = new System.Windows.Forms.Padding(0);
            this.txtBuscarEmpleado.Name = "txtBuscarEmpleado";
            this.txtBuscarEmpleado.Size = new System.Drawing.Size(561, 32);
            this.txtBuscarEmpleado.TabIndex = 14;
            this.txtBuscarEmpleado.Tag = "";
            this.txtBuscarEmpleado.UseWaitCursor = true;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel10.Location = new System.Drawing.Point(22, 122);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(624, 10);
            this.panel10.TabIndex = 16;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::BakeBookerGUI_1._0.Properties.Resources.usuario__3_;
            this.pictureBox3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox3.Location = new System.Drawing.Point(22, 82);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(43, 39);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 15;
            this.pictureBox3.TabStop = false;
            // 
            // tabClientes
            // 
            this.tabClientes.Controls.Add(this.panel21);
            this.tabClientes.Controls.Add(this.tabCliente);
            this.tabClientes.Controls.Add(this.panel20);
            this.tabClientes.Location = new System.Drawing.Point(4, 25);
            this.tabClientes.Name = "tabClientes";
            this.tabClientes.Padding = new System.Windows.Forms.Padding(3);
            this.tabClientes.Size = new System.Drawing.Size(1395, 759);
            this.tabClientes.TabIndex = 6;
            this.tabClientes.Text = "Clientes";
            this.tabClientes.UseVisualStyleBackColor = true;
            // 
            // panel21
            // 
            this.panel21.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel21.Controls.Add(this.btnBEMclientes);
            this.panel21.Location = new System.Drawing.Point(218, 3);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(273, 77);
            this.panel21.TabIndex = 1;
            // 
            // btnBEMclientes
            // 
            this.btnBEMclientes.BackColor = System.Drawing.Color.Transparent;
            this.btnBEMclientes.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnBEMclientes.FlatAppearance.BorderSize = 0;
            this.btnBEMclientes.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.btnBEMclientes.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBEMclientes.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Bold);
            this.btnBEMclientes.Image = global::BakeBookerGUI_1._0.Properties.Resources.personalizacion;
            this.btnBEMclientes.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btnBEMclientes.Location = new System.Drawing.Point(3, 3);
            this.btnBEMclientes.Name = "btnBEMclientes";
            this.btnBEMclientes.Size = new System.Drawing.Size(265, 71);
            this.btnBEMclientes.TabIndex = 2;
            this.btnBEMclientes.Text = "Buscar, Eliminar o Modificar";
            this.btnBEMclientes.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnBEMclientes.UseVisualStyleBackColor = false;
            // 
            // tabCliente
            // 
            this.tabCliente.Controls.Add(this.tabPage2);
            this.tabCliente.Controls.Add(this.tabPage1);
            this.tabCliente.Location = new System.Drawing.Point(6, 93);
            this.tabCliente.Multiline = true;
            this.tabCliente.Name = "tabCliente";
            this.tabCliente.SelectedIndex = 0;
            this.tabCliente.Size = new System.Drawing.Size(1392, 607);
            this.tabCliente.TabIndex = 2;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(156)))), ((int)(((byte)(156)))));
            this.tabPage2.Controls.Add(this.panel30);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1384, 581);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Nuevo CLiente";
            // 
            // panel30
            // 
            this.panel30.BackColor = System.Drawing.Color.White;
            this.panel30.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel30.Controls.Add(this.panel14);
            this.panel30.Controls.Add(this.panel35);
            this.panel30.Controls.Add(this.panel36);
            this.panel30.Controls.Add(this.panel37);
            this.panel30.Controls.Add(this.txtNumExteriorCliente);
            this.panel30.Controls.Add(this.txtCalleCliente);
            this.panel30.Controls.Add(this.label8);
            this.panel30.Controls.Add(this.label12);
            this.panel30.Controls.Add(this.label20);
            this.panel30.Controls.Add(this.label25);
            this.panel30.Controls.Add(this.txtRFCCliente);
            this.panel30.Controls.Add(this.txtNumInteriorCliente);
            this.panel30.Controls.Add(this.panel31);
            this.panel30.Controls.Add(this.panel32);
            this.panel30.Controls.Add(this.panel33);
            this.panel30.Controls.Add(this.panel34);
            this.panel30.Controls.Add(this.btnCrearCliente);
            this.panel30.Controls.Add(this.label19);
            this.panel30.Controls.Add(this.txtApellidoCliente);
            this.panel30.Controls.Add(this.txtNombreCliente);
            this.panel30.Controls.Add(this.label21);
            this.panel30.Controls.Add(this.label22);
            this.panel30.Controls.Add(this.label23);
            this.panel30.Controls.Add(this.label24);
            this.panel30.Controls.Add(this.txtTelefonoCliente);
            this.panel30.Controls.Add(this.txtCorreoCliente);
            this.panel30.Location = new System.Drawing.Point(28, 17);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(1075, 428);
            this.panel30.TabIndex = 39;
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel14.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel14.Location = new System.Drawing.Point(556, 258);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(494, 5);
            this.panel14.TabIndex = 55;
            // 
            // panel35
            // 
            this.panel35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel35.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel35.Location = new System.Drawing.Point(551, 200);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(494, 5);
            this.panel35.TabIndex = 54;
            // 
            // panel36
            // 
            this.panel36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel36.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel36.Location = new System.Drawing.Point(554, 151);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(494, 5);
            this.panel36.TabIndex = 53;
            // 
            // panel37
            // 
            this.panel37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel37.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel37.Location = new System.Drawing.Point(550, 100);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(494, 5);
            this.panel37.TabIndex = 52;
            // 
            // txtNumExteriorCliente
            // 
            this.txtNumExteriorCliente.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumExteriorCliente.Location = new System.Drawing.Point(837, 114);
            this.txtNumExteriorCliente.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNumExteriorCliente.Multiline = true;
            this.txtNumExteriorCliente.Name = "txtNumExteriorCliente";
            this.txtNumExteriorCliente.Size = new System.Drawing.Size(211, 32);
            this.txtNumExteriorCliente.TabIndex = 44;
            // 
            // txtCalleCliente
            // 
            this.txtCalleCliente.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCalleCliente.Location = new System.Drawing.Point(837, 63);
            this.txtCalleCliente.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCalleCliente.Multiline = true;
            this.txtCalleCliente.Name = "txtCalleCliente";
            this.txtCalleCliente.Size = new System.Drawing.Size(212, 32);
            this.txtCalleCliente.TabIndex = 45;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(543, 229);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(128, 19);
            this.label8.TabIndex = 50;
            this.label8.Text = "RFC (OPCIONAL)";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(550, 71);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(57, 19);
            this.label12.TabIndex = 47;
            this.label12.Text = "CALLE:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(543, 171);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(241, 19);
            this.label20.TabIndex = 51;
            this.label20.Text = "NUMERO INTERIOR (OPCIONAL)";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(546, 119);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(150, 19);
            this.label25.TabIndex = 46;
            this.label25.Text = "NUMERO EXTERIOR";
            // 
            // txtRFCCliente
            // 
            this.txtRFCCliente.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRFCCliente.Location = new System.Drawing.Point(310, 221);
            this.txtRFCCliente.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtRFCCliente.Multiline = true;
            this.txtRFCCliente.Name = "txtRFCCliente";
            this.txtRFCCliente.Size = new System.Drawing.Size(212, 32);
            this.txtRFCCliente.TabIndex = 48;
            // 
            // txtNumInteriorCliente
            // 
            this.txtNumInteriorCliente.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumInteriorCliente.Location = new System.Drawing.Point(837, 163);
            this.txtNumInteriorCliente.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNumInteriorCliente.Multiline = true;
            this.txtNumInteriorCliente.Name = "txtNumInteriorCliente";
            this.txtNumInteriorCliente.Size = new System.Drawing.Size(208, 32);
            this.txtNumInteriorCliente.TabIndex = 49;
            // 
            // panel31
            // 
            this.panel31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel31.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel31.Location = new System.Drawing.Point(26, 258);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(496, 5);
            this.panel31.TabIndex = 43;
            // 
            // panel32
            // 
            this.panel32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel32.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel32.Location = new System.Drawing.Point(28, 200);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(496, 5);
            this.panel32.TabIndex = 42;
            // 
            // panel33
            // 
            this.panel33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel33.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel33.Location = new System.Drawing.Point(31, 151);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(496, 5);
            this.panel33.TabIndex = 41;
            // 
            // panel34
            // 
            this.panel34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel34.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel34.Location = new System.Drawing.Point(27, 100);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(496, 5);
            this.panel34.TabIndex = 40;
            // 
            // btnCrearCliente
            // 
            this.btnCrearCliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCrearCliente.Font = new System.Drawing.Font("Gadugi", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCrearCliente.ForeColor = System.Drawing.Color.Black;
            this.btnCrearCliente.Image = global::BakeBookerGUI_1._0.Properties.Resources.subir;
            this.btnCrearCliente.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCrearCliente.Location = new System.Drawing.Point(724, 316);
            this.btnCrearCliente.Name = "btnCrearCliente";
            this.btnCrearCliente.Size = new System.Drawing.Size(326, 91);
            this.btnCrearCliente.TabIndex = 39;
            this.btnCrearCliente.Text = "Crear Cliente";
            this.btnCrearCliente.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCrearCliente.UseVisualStyleBackColor = true;
            this.btnCrearCliente.Click += new System.EventHandler(this.btnCrearCliente_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Gadugi", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(15, 15);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(388, 21);
            this.label19.TabIndex = 33;
            this.label19.Text = "Ingrese todos los datos del nuevo CLIENTE";
            // 
            // txtApellidoCliente
            // 
            this.txtApellidoCliente.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtApellidoCliente.Location = new System.Drawing.Point(310, 114);
            this.txtApellidoCliente.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtApellidoCliente.Multiline = true;
            this.txtApellidoCliente.Name = "txtApellidoCliente";
            this.txtApellidoCliente.Size = new System.Drawing.Size(217, 32);
            this.txtApellidoCliente.TabIndex = 28;
            // 
            // txtNombreCliente
            // 
            this.txtNombreCliente.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombreCliente.Location = new System.Drawing.Point(310, 63);
            this.txtNombreCliente.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNombreCliente.Multiline = true;
            this.txtNombreCliente.Name = "txtNombreCliente";
            this.txtNombreCliente.Size = new System.Drawing.Size(218, 32);
            this.txtNombreCliente.TabIndex = 29;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(20, 229);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(88, 19);
            this.label21.TabIndex = 35;
            this.label21.Text = "TELEFONO:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(27, 71);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(78, 19);
            this.label22.TabIndex = 32;
            this.label22.Text = "NOMBRE:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(20, 171);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(72, 19);
            this.label23.TabIndex = 36;
            this.label23.Text = "CORREO:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(23, 119);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(80, 19);
            this.label24.TabIndex = 30;
            this.label24.Text = "APELLIDO";
            // 
            // txtTelefonoCliente
            // 
            this.txtTelefonoCliente.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTelefonoCliente.Location = new System.Drawing.Point(837, 216);
            this.txtTelefonoCliente.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTelefonoCliente.Multiline = true;
            this.txtTelefonoCliente.Name = "txtTelefonoCliente";
            this.txtTelefonoCliente.Size = new System.Drawing.Size(211, 32);
            this.txtTelefonoCliente.TabIndex = 33;
            // 
            // txtCorreoCliente
            // 
            this.txtCorreoCliente.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCorreoCliente.Location = new System.Drawing.Point(310, 163);
            this.txtCorreoCliente.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCorreoCliente.Multiline = true;
            this.txtCorreoCliente.Name = "txtCorreoCliente";
            this.txtCorreoCliente.Size = new System.Drawing.Size(214, 32);
            this.txtCorreoCliente.TabIndex = 34;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.White;
            this.tabPage1.Controls.Add(this.gpbMostrarCliente);
            this.tabPage1.Controls.Add(this.dgvResultadosClientes);
            this.tabPage1.Controls.Add(this.panel28);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1384, 581);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Buscar";
            // 
            // gpbMostrarCliente
            // 
            this.gpbMostrarCliente.BackColor = System.Drawing.Color.Transparent;
            this.gpbMostrarCliente.Controls.Add(this.panel65);
            this.gpbMostrarCliente.Controls.Add(this.txtIDBCliente);
            this.gpbMostrarCliente.Controls.Add(this.panel11);
            this.gpbMostrarCliente.Controls.Add(this.label54);
            this.gpbMostrarCliente.Controls.Add(this.panel23);
            this.gpbMostrarCliente.Controls.Add(this.panel24);
            this.gpbMostrarCliente.Controls.Add(this.panel25);
            this.gpbMostrarCliente.Controls.Add(this.txtNumExteriorBCliente);
            this.gpbMostrarCliente.Controls.Add(this.txtCalleBCliente);
            this.gpbMostrarCliente.Controls.Add(this.label13);
            this.gpbMostrarCliente.Controls.Add(this.label14);
            this.gpbMostrarCliente.Controls.Add(this.label15);
            this.gpbMostrarCliente.Controls.Add(this.label16);
            this.gpbMostrarCliente.Controls.Add(this.txtRFCBCliente);
            this.gpbMostrarCliente.Controls.Add(this.txtNumInteriorBCliente);
            this.gpbMostrarCliente.Controls.Add(this.panel26);
            this.gpbMostrarCliente.Controls.Add(this.panel27);
            this.gpbMostrarCliente.Controls.Add(this.panel38);
            this.gpbMostrarCliente.Controls.Add(this.panel39);
            this.gpbMostrarCliente.Controls.Add(this.txtApellidoBCliente);
            this.gpbMostrarCliente.Controls.Add(this.txtNombreBCliente);
            this.gpbMostrarCliente.Controls.Add(this.label17);
            this.gpbMostrarCliente.Controls.Add(this.label26);
            this.gpbMostrarCliente.Controls.Add(this.label27);
            this.gpbMostrarCliente.Controls.Add(this.label28);
            this.gpbMostrarCliente.Controls.Add(this.txtTelefonoBCliente);
            this.gpbMostrarCliente.Controls.Add(this.txtCorreoBCliente);
            this.gpbMostrarCliente.Controls.Add(this.btnModificarCliente);
            this.gpbMostrarCliente.Controls.Add(this.btnEliminarCliente);
            this.gpbMostrarCliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gpbMostrarCliente.Font = new System.Drawing.Font("Gadugi", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gpbMostrarCliente.Location = new System.Drawing.Point(876, 6);
            this.gpbMostrarCliente.Name = "gpbMostrarCliente";
            this.gpbMostrarCliente.Size = new System.Drawing.Size(516, 566);
            this.gpbMostrarCliente.TabIndex = 2;
            this.gpbMostrarCliente.TabStop = false;
            this.gpbMostrarCliente.Text = "Información del Cliente";
            // 
            // panel65
            // 
            this.panel65.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel65.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel65.Location = new System.Drawing.Point(13, 63);
            this.panel65.Name = "panel65";
            this.panel65.Size = new System.Drawing.Size(465, 5);
            this.panel65.TabIndex = 68;
            // 
            // txtIDBCliente
            // 
            this.txtIDBCliente.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIDBCliente.Location = new System.Drawing.Point(248, 26);
            this.txtIDBCliente.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtIDBCliente.Multiline = true;
            this.txtIDBCliente.Name = "txtIDBCliente";
            this.txtIDBCliente.Size = new System.Drawing.Size(235, 32);
            this.txtIDBCliente.TabIndex = 66;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel11.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel11.Location = new System.Drawing.Point(11, 468);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(463, 5);
            this.panel11.TabIndex = 80;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(13, 34);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(23, 16);
            this.label54.TabIndex = 67;
            this.label54.Text = "ID:";
            // 
            // panel23
            // 
            this.panel23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel23.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel23.Location = new System.Drawing.Point(9, 423);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(463, 5);
            this.panel23.TabIndex = 79;
            // 
            // panel24
            // 
            this.panel24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel24.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel24.Location = new System.Drawing.Point(12, 374);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(463, 5);
            this.panel24.TabIndex = 78;
            // 
            // panel25
            // 
            this.panel25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel25.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel25.Location = new System.Drawing.Point(8, 323);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(463, 5);
            this.panel25.TabIndex = 77;
            // 
            // txtNumExteriorBCliente
            // 
            this.txtNumExteriorBCliente.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumExteriorBCliente.Location = new System.Drawing.Point(248, 337);
            this.txtNumExteriorBCliente.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNumExteriorBCliente.Multiline = true;
            this.txtNumExteriorBCliente.Name = "txtNumExteriorBCliente";
            this.txtNumExteriorBCliente.Size = new System.Drawing.Size(227, 32);
            this.txtNumExteriorBCliente.TabIndex = 69;
            // 
            // txtCalleBCliente
            // 
            this.txtCalleBCliente.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCalleBCliente.Location = new System.Drawing.Point(248, 286);
            this.txtCalleBCliente.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCalleBCliente.Multiline = true;
            this.txtCalleBCliente.Name = "txtCalleBCliente";
            this.txtCalleBCliente.Size = new System.Drawing.Size(228, 32);
            this.txtCalleBCliente.TabIndex = 70;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(3, 446);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(119, 18);
            this.label13.TabIndex = 75;
            this.label13.Text = "RFC (OPCIONAL)";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(8, 294);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(43, 16);
            this.label14.TabIndex = 72;
            this.label14.Text = "CALLE:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(1, 394);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(222, 18);
            this.label15.TabIndex = 76;
            this.label15.Text = "NUMERO INTERIOR (OPCIONAL)";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(4, 342);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(137, 18);
            this.label16.TabIndex = 71;
            this.label16.Text = "NUMERO EXTERIOR";
            // 
            // txtRFCBCliente
            // 
            this.txtRFCBCliente.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRFCBCliente.Location = new System.Drawing.Point(248, 433);
            this.txtRFCBCliente.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtRFCBCliente.Multiline = true;
            this.txtRFCBCliente.Name = "txtRFCBCliente";
            this.txtRFCBCliente.Size = new System.Drawing.Size(230, 32);
            this.txtRFCBCliente.TabIndex = 73;
            // 
            // txtNumInteriorBCliente
            // 
            this.txtNumInteriorBCliente.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumInteriorBCliente.Location = new System.Drawing.Point(248, 386);
            this.txtNumInteriorBCliente.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNumInteriorBCliente.Multiline = true;
            this.txtNumInteriorBCliente.Name = "txtNumInteriorBCliente";
            this.txtNumInteriorBCliente.Size = new System.Drawing.Size(224, 32);
            this.txtNumInteriorBCliente.TabIndex = 74;
            // 
            // panel26
            // 
            this.panel26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel26.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel26.Location = new System.Drawing.Point(7, 268);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(465, 5);
            this.panel26.TabIndex = 68;
            // 
            // panel27
            // 
            this.panel27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel27.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel27.Location = new System.Drawing.Point(9, 210);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(465, 5);
            this.panel27.TabIndex = 67;
            // 
            // panel38
            // 
            this.panel38.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel38.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel38.Location = new System.Drawing.Point(12, 161);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(465, 5);
            this.panel38.TabIndex = 66;
            // 
            // panel39
            // 
            this.panel39.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel39.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel39.Location = new System.Drawing.Point(8, 110);
            this.panel39.Name = "panel39";
            this.panel39.Size = new System.Drawing.Size(465, 5);
            this.panel39.TabIndex = 65;
            // 
            // txtApellidoBCliente
            // 
            this.txtApellidoBCliente.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtApellidoBCliente.Location = new System.Drawing.Point(248, 124);
            this.txtApellidoBCliente.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtApellidoBCliente.Multiline = true;
            this.txtApellidoBCliente.Name = "txtApellidoBCliente";
            this.txtApellidoBCliente.Size = new System.Drawing.Size(229, 32);
            this.txtApellidoBCliente.TabIndex = 57;
            // 
            // txtNombreBCliente
            // 
            this.txtNombreBCliente.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombreBCliente.Location = new System.Drawing.Point(248, 73);
            this.txtNombreBCliente.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNombreBCliente.Multiline = true;
            this.txtNombreBCliente.Name = "txtNombreBCliente";
            this.txtNombreBCliente.Size = new System.Drawing.Size(230, 32);
            this.txtNombreBCliente.TabIndex = 58;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(1, 239);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(68, 16);
            this.label17.TabIndex = 63;
            this.label17.Text = "TELEFONO:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(8, 81);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(61, 16);
            this.label26.TabIndex = 60;
            this.label26.Text = "NOMBRE:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(1, 181);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(57, 16);
            this.label27.TabIndex = 64;
            this.label27.Text = "CORREO:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(4, 129);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(62, 16);
            this.label28.TabIndex = 59;
            this.label28.Text = "APELLIDO";
            // 
            // txtTelefonoBCliente
            // 
            this.txtTelefonoBCliente.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTelefonoBCliente.Location = new System.Drawing.Point(248, 228);
            this.txtTelefonoBCliente.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTelefonoBCliente.Multiline = true;
            this.txtTelefonoBCliente.Name = "txtTelefonoBCliente";
            this.txtTelefonoBCliente.Size = new System.Drawing.Size(230, 32);
            this.txtTelefonoBCliente.TabIndex = 61;
            // 
            // txtCorreoBCliente
            // 
            this.txtCorreoBCliente.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCorreoBCliente.Location = new System.Drawing.Point(248, 173);
            this.txtCorreoBCliente.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCorreoBCliente.Multiline = true;
            this.txtCorreoBCliente.Name = "txtCorreoBCliente";
            this.txtCorreoBCliente.Size = new System.Drawing.Size(226, 32);
            this.txtCorreoBCliente.TabIndex = 62;
            // 
            // btnModificarCliente
            // 
            this.btnModificarCliente.BackColor = System.Drawing.Color.Transparent;
            this.btnModificarCliente.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnModificarCliente.FlatAppearance.BorderSize = 0;
            this.btnModificarCliente.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.btnModificarCliente.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnModificarCliente.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModificarCliente.Image = global::BakeBookerGUI_1._0.Properties.Resources.conversion;
            this.btnModificarCliente.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btnModificarCliente.Location = new System.Drawing.Point(248, 487);
            this.btnModificarCliente.Name = "btnModificarCliente";
            this.btnModificarCliente.Size = new System.Drawing.Size(230, 76);
            this.btnModificarCliente.TabIndex = 4;
            this.btnModificarCliente.Text = "Modificar Cliente";
            this.btnModificarCliente.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnModificarCliente.UseVisualStyleBackColor = false;
            this.btnModificarCliente.Click += new System.EventHandler(this.button6_Click);
            // 
            // btnEliminarCliente
            // 
            this.btnEliminarCliente.BackColor = System.Drawing.Color.Transparent;
            this.btnEliminarCliente.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnEliminarCliente.FlatAppearance.BorderSize = 0;
            this.btnEliminarCliente.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.btnEliminarCliente.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnEliminarCliente.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEliminarCliente.Image = global::BakeBookerGUI_1._0.Properties.Resources.contenedor_de_basura;
            this.btnEliminarCliente.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btnEliminarCliente.Location = new System.Drawing.Point(12, 487);
            this.btnEliminarCliente.Name = "btnEliminarCliente";
            this.btnEliminarCliente.Size = new System.Drawing.Size(205, 77);
            this.btnEliminarCliente.TabIndex = 3;
            this.btnEliminarCliente.Text = "Eliminar Cliente";
            this.btnEliminarCliente.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnEliminarCliente.UseVisualStyleBackColor = false;
            this.btnEliminarCliente.Click += new System.EventHandler(this.btnEliminarCliente_Click);
            // 
            // dgvResultadosClientes
            // 
            this.dgvResultadosClientes.AllowUserToAddRows = false;
            this.dgvResultadosClientes.AllowUserToDeleteRows = false;
            this.dgvResultadosClientes.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvResultadosClientes.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.dgvResultadosClientes.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvResultadosClientes.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvResultadosClientes.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
            this.dgvResultadosClientes.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dgvResultadosClientes.ColumnHeadersHeight = 29;
            this.dgvResultadosClientes.Location = new System.Drawing.Point(8, 196);
            this.dgvResultadosClientes.Name = "dgvResultadosClientes";
            this.dgvResultadosClientes.ReadOnly = true;
            this.dgvResultadosClientes.RowHeadersWidth = 51;
            this.dgvResultadosClientes.RowTemplate.Height = 24;
            this.dgvResultadosClientes.Size = new System.Drawing.Size(843, 410);
            this.dgvResultadosClientes.TabIndex = 1;
            this.dgvResultadosClientes.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvResultadosClientes_CellClick);
            // 
            // panel28
            // 
            this.panel28.BackColor = System.Drawing.Color.Transparent;
            this.panel28.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel28.Controls.Add(this.radNombreCliente);
            this.panel28.Controls.Add(this.btnBuscarCliente);
            this.panel28.Controls.Add(this.label18);
            this.panel28.Controls.Add(this.txtBuscarCliente);
            this.panel28.Controls.Add(this.panel29);
            this.panel28.Controls.Add(this.pictureBox2);
            this.panel28.Location = new System.Drawing.Point(6, 6);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(845, 177);
            this.panel28.TabIndex = 0;
            // 
            // radNombreCliente
            // 
            this.radNombreCliente.AutoSize = true;
            this.radNombreCliente.Checked = true;
            this.radNombreCliente.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radNombreCliente.Location = new System.Drawing.Point(73, 53);
            this.radNombreCliente.Name = "radNombreCliente";
            this.radNombreCliente.Size = new System.Drawing.Size(85, 23);
            this.radNombreCliente.TabIndex = 20;
            this.radNombreCliente.TabStop = true;
            this.radNombreCliente.Text = "Nombre";
            this.radNombreCliente.UseVisualStyleBackColor = true;
            // 
            // btnBuscarCliente
            // 
            this.btnBuscarCliente.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarCliente.Image = global::BakeBookerGUI_1._0.Properties.Resources.ciencias_sociales__1_;
            this.btnBuscarCliente.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBuscarCliente.Location = new System.Drawing.Point(603, 72);
            this.btnBuscarCliente.Name = "btnBuscarCliente";
            this.btnBuscarCliente.Size = new System.Drawing.Size(230, 72);
            this.btnBuscarCliente.TabIndex = 18;
            this.btnBuscarCliente.Text = "Buscar Cliente";
            this.btnBuscarCliente.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBuscarCliente.UseVisualStyleBackColor = true;
            this.btnBuscarCliente.Click += new System.EventHandler(this.btnBuscarCliente_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Gadugi", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(18, 10);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(289, 19);
            this.label18.TabIndex = 17;
            this.label18.Text = "Selecionar criterio e ingresar Cliente ";
            // 
            // txtBuscarCliente
            // 
            this.txtBuscarCliente.AccessibleDescription = "Ingresar usuario";
            this.txtBuscarCliente.AccessibleName = "Ingresa usuario";
            this.txtBuscarCliente.AccessibleRole = System.Windows.Forms.AccessibleRole.Text;
            this.txtBuscarCliente.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtBuscarCliente.BackColor = System.Drawing.Color.White;
            this.txtBuscarCliente.Font = new System.Drawing.Font("Nirmala UI", 14F, System.Drawing.FontStyle.Bold);
            this.txtBuscarCliente.ForeColor = System.Drawing.Color.Black;
            this.txtBuscarCliente.Location = new System.Drawing.Point(82, 92);
            this.txtBuscarCliente.Margin = new System.Windows.Forms.Padding(0);
            this.txtBuscarCliente.Name = "txtBuscarCliente";
            this.txtBuscarCliente.Size = new System.Drawing.Size(433, 32);
            this.txtBuscarCliente.TabIndex = 14;
            this.txtBuscarCliente.Tag = "";
            this.txtBuscarCliente.UseWaitCursor = true;
            // 
            // panel29
            // 
            this.panel29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel29.Location = new System.Drawing.Point(22, 134);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(524, 10);
            this.panel29.TabIndex = 16;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::BakeBookerGUI_1._0.Properties.Resources.usuario__3_;
            this.pictureBox2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox2.Location = new System.Drawing.Point(22, 89);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(43, 39);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 15;
            this.pictureBox2.TabStop = false;
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.Color.White;
            this.panel20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel20.Controls.Add(this.panel22);
            this.panel20.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel20.Location = new System.Drawing.Point(3, 3);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(1389, 84);
            this.panel20.TabIndex = 1;
            // 
            // panel22
            // 
            this.panel22.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel22.Controls.Add(this.btnClienteNuevo);
            this.panel22.Location = new System.Drawing.Point(6, 0);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(202, 77);
            this.panel22.TabIndex = 2;
            // 
            // btnClienteNuevo
            // 
            this.btnClienteNuevo.BackColor = System.Drawing.Color.Transparent;
            this.btnClienteNuevo.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnClienteNuevo.FlatAppearance.BorderSize = 0;
            this.btnClienteNuevo.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.btnClienteNuevo.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnClienteNuevo.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClienteNuevo.Image = global::BakeBookerGUI_1._0.Properties.Resources.usuario__4_;
            this.btnClienteNuevo.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btnClienteNuevo.Location = new System.Drawing.Point(3, 3);
            this.btnClienteNuevo.Name = "btnClienteNuevo";
            this.btnClienteNuevo.Size = new System.Drawing.Size(194, 71);
            this.btnClienteNuevo.TabIndex = 2;
            this.btnClienteNuevo.Text = "Nuevo Cliente";
            this.btnClienteNuevo.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnClienteNuevo.UseVisualStyleBackColor = false;
            // 
            // tabPedidos
            // 
            this.tabPedidos.Controls.Add(this.tabPedido);
            this.tabPedidos.Controls.Add(this.panel40);
            this.tabPedidos.Location = new System.Drawing.Point(4, 25);
            this.tabPedidos.Name = "tabPedidos";
            this.tabPedidos.Padding = new System.Windows.Forms.Padding(3);
            this.tabPedidos.Size = new System.Drawing.Size(1395, 759);
            this.tabPedidos.TabIndex = 1;
            this.tabPedidos.Text = "Pedidos";
            this.tabPedidos.UseVisualStyleBackColor = true;
            // 
            // tabPedido
            // 
            this.tabPedido.Controls.Add(this.tabPage3);
            this.tabPedido.Controls.Add(this.tabPage4);
            this.tabPedido.Location = new System.Drawing.Point(3, 89);
            this.tabPedido.Multiline = true;
            this.tabPedido.Name = "tabPedido";
            this.tabPedido.SelectedIndex = 0;
            this.tabPedido.Size = new System.Drawing.Size(1393, 610);
            this.tabPedido.TabIndex = 3;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(156)))), ((int)(((byte)(156)))));
            this.tabPage3.Controls.Add(this.panel85);
            this.tabPage3.Controls.Add(this.panel83);
            this.tabPage3.Controls.Add(this.panel74);
            this.tabPage3.Controls.Add(this.panel62);
            this.tabPage3.Controls.Add(this.panel43);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1385, 584);
            this.tabPage3.TabIndex = 1;
            this.tabPage3.Text = "Nuevo Pedido";
            // 
            // panel85
            // 
            this.panel85.BackColor = System.Drawing.Color.White;
            this.panel85.Controls.Add(this.label95);
            this.panel85.Controls.Add(this.DTPfechadepedido);
            this.panel85.Controls.Add(this.label38);
            this.panel85.Controls.Add(this.label60);
            this.panel85.Controls.Add(this.btnCrearPedido);
            this.panel85.Controls.Add(this.txtPedidos_Anticipo);
            this.panel85.Controls.Add(this.DTPFechaDeEntregaPedido);
            this.panel85.Controls.Add(this.radiobuttonRecoger);
            this.panel85.Controls.Add(this.label49);
            this.panel85.Controls.Add(this.radioButtonLlevar);
            this.panel85.Location = new System.Drawing.Point(2, 191);
            this.panel85.Name = "panel85";
            this.panel85.Size = new System.Drawing.Size(629, 100);
            this.panel85.TabIndex = 54;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(340, 44);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(113, 17);
            this.label38.TabIndex = 52;
            this.label38.Text = "Fecha de entrega";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Gadugi", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.Location = new System.Drawing.Point(5, 7);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(107, 19);
            this.label60.TabIndex = 51;
            this.label60.Text = "Crear Pedido";
            // 
            // btnCrearPedido
            // 
            this.btnCrearPedido.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCrearPedido.Image = global::BakeBookerGUI_1._0.Properties.Resources.ciencias_sociales__1_;
            this.btnCrearPedido.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCrearPedido.Location = new System.Drawing.Point(508, 23);
            this.btnCrearPedido.Name = "btnCrearPedido";
            this.btnCrearPedido.Size = new System.Drawing.Size(111, 59);
            this.btnCrearPedido.TabIndex = 50;
            this.btnCrearPedido.Text = "Crear Pedido";
            this.btnCrearPedido.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCrearPedido.UseVisualStyleBackColor = true;
            this.btnCrearPedido.Click += new System.EventHandler(this.btnCrearPedido_Click);
            // 
            // txtPedidos_Anticipo
            // 
            this.txtPedidos_Anticipo.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPedidos_Anticipo.Location = new System.Drawing.Point(247, 5);
            this.txtPedidos_Anticipo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtPedidos_Anticipo.Name = "txtPedidos_Anticipo";
            this.txtPedidos_Anticipo.Size = new System.Drawing.Size(101, 26);
            this.txtPedidos_Anticipo.TabIndex = 46;
            // 
            // DTPFechaDeEntregaPedido
            // 
            this.DTPFechaDeEntregaPedido.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DTPFechaDeEntregaPedido.Location = new System.Drawing.Point(343, 67);
            this.DTPFechaDeEntregaPedido.Name = "DTPFechaDeEntregaPedido";
            this.DTPFechaDeEntregaPedido.Size = new System.Drawing.Size(159, 26);
            this.DTPFechaDeEntregaPedido.TabIndex = 44;
            // 
            // radiobuttonRecoger
            // 
            this.radiobuttonRecoger.AutoSize = true;
            this.radiobuttonRecoger.Checked = true;
            this.radiobuttonRecoger.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radiobuttonRecoger.Location = new System.Drawing.Point(38, 54);
            this.radiobuttonRecoger.Margin = new System.Windows.Forms.Padding(4);
            this.radiobuttonRecoger.Name = "radiobuttonRecoger";
            this.radiobuttonRecoger.Size = new System.Drawing.Size(68, 20);
            this.radiobuttonRecoger.TabIndex = 48;
            this.radiobuttonRecoger.TabStop = true;
            this.radiobuttonRecoger.Text = "Recoger";
            this.radiobuttonRecoger.UseVisualStyleBackColor = true;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(168, 13);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(73, 17);
            this.label49.TabIndex = 47;
            this.label49.Text = "ANTICIPO:";
            // 
            // radioButtonLlevar
            // 
            this.radioButtonLlevar.AutoSize = true;
            this.radioButtonLlevar.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonLlevar.Location = new System.Drawing.Point(38, 75);
            this.radioButtonLlevar.Margin = new System.Windows.Forms.Padding(4);
            this.radioButtonLlevar.Name = "radioButtonLlevar";
            this.radioButtonLlevar.Size = new System.Drawing.Size(59, 20);
            this.radioButtonLlevar.TabIndex = 49;
            this.radioButtonLlevar.Text = "LLevar";
            this.radioButtonLlevar.UseVisualStyleBackColor = true;
            // 
            // panel83
            // 
            this.panel83.BackColor = System.Drawing.Color.White;
            this.panel83.Controls.Add(this.dataGridView1);
            this.panel83.Controls.Add(this.asdasdasd);
            this.panel83.Location = new System.Drawing.Point(2, 297);
            this.panel83.Name = "panel83";
            this.panel83.Size = new System.Drawing.Size(630, 137);
            this.panel83.TabIndex = 53;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.Maroon;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(2, 29);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(625, 91);
            this.dataGridView1.TabIndex = 40;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // asdasdasd
            // 
            this.asdasdasd.AutoSize = true;
            this.asdasdasd.Font = new System.Drawing.Font("Gadugi", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.asdasdasd.Location = new System.Drawing.Point(6, 7);
            this.asdasdasd.Name = "asdasdasd";
            this.asdasdasd.Size = new System.Drawing.Size(70, 19);
            this.asdasdasd.TabIndex = 51;
            this.asdasdasd.Text = "Pedidos";
            // 
            // panel74
            // 
            this.panel74.BackColor = System.Drawing.Color.White;
            this.panel74.Controls.Add(this.DGVListaPedido);
            this.panel74.Controls.Add(this.label58);
            this.panel74.Controls.Add(this.btnPedidoPastel);
            this.panel74.Controls.Add(this.btnPedidoProducto);
            this.panel74.Location = new System.Drawing.Point(2, 440);
            this.panel74.Name = "panel74";
            this.panel74.Size = new System.Drawing.Size(631, 131);
            this.panel74.TabIndex = 52;
            // 
            // DGVListaPedido
            // 
            this.DGVListaPedido.AllowUserToAddRows = false;
            this.DGVListaPedido.AllowUserToDeleteRows = false;
            this.DGVListaPedido.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DGVListaPedido.BackgroundColor = System.Drawing.Color.Maroon;
            this.DGVListaPedido.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.DGVListaPedido.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVListaPedido.Location = new System.Drawing.Point(3, 28);
            this.DGVListaPedido.Name = "DGVListaPedido";
            this.DGVListaPedido.ReadOnly = true;
            this.DGVListaPedido.RowHeadersWidth = 51;
            this.DGVListaPedido.RowTemplate.Height = 24;
            this.DGVListaPedido.Size = new System.Drawing.Size(484, 91);
            this.DGVListaPedido.TabIndex = 40;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Gadugi", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.Location = new System.Drawing.Point(7, 6);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(157, 19);
            this.label58.TabIndex = 51;
            this.label58.Text = "Detalles del pedido";
            // 
            // btnPedidoPastel
            // 
            this.btnPedidoPastel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPedidoPastel.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPedidoPastel.ForeColor = System.Drawing.Color.Black;
            this.btnPedidoPastel.Image = global::BakeBookerGUI_1._0.Properties.Resources.pastel;
            this.btnPedidoPastel.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btnPedidoPastel.Location = new System.Drawing.Point(508, 8);
            this.btnPedidoPastel.Name = "btnPedidoPastel";
            this.btnPedidoPastel.Size = new System.Drawing.Size(113, 59);
            this.btnPedidoPastel.TabIndex = 39;
            this.btnPedidoPastel.Text = "Orden";
            this.btnPedidoPastel.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnPedidoPastel.UseVisualStyleBackColor = true;
            this.btnPedidoPastel.Click += new System.EventHandler(this.btnPedidoPastel_Click);
            // 
            // btnPedidoProducto
            // 
            this.btnPedidoProducto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPedidoProducto.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPedidoProducto.ForeColor = System.Drawing.Color.Black;
            this.btnPedidoProducto.Image = global::BakeBookerGUI_1._0.Properties.Resources.macarron;
            this.btnPedidoProducto.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btnPedidoProducto.Location = new System.Drawing.Point(508, 69);
            this.btnPedidoProducto.Name = "btnPedidoProducto";
            this.btnPedidoProducto.Size = new System.Drawing.Size(113, 57);
            this.btnPedidoProducto.TabIndex = 45;
            this.btnPedidoProducto.Text = "Producto";
            this.btnPedidoProducto.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnPedidoProducto.UseVisualStyleBackColor = true;
            this.btnPedidoProducto.Click += new System.EventHandler(this.btnPedidoProducto_Click);
            // 
            // panel62
            // 
            this.panel62.Controls.Add(this.panel63);
            this.panel62.Controls.Add(this.PanelPastel);
            this.panel62.Controls.Add(this.panel50);
            this.panel62.Location = new System.Drawing.Point(636, 1);
            this.panel62.Name = "panel62";
            this.panel62.Size = new System.Drawing.Size(743, 570);
            this.panel62.TabIndex = 42;
            // 
            // panel63
            // 
            this.panel63.BackColor = System.Drawing.Color.White;
            this.panel63.Controls.Add(this.btnTerminarPedido);
            this.panel63.Controls.Add(this.btnAgregarAPedido);
            this.panel63.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel63.Location = new System.Drawing.Point(0, 482);
            this.panel63.Name = "panel63";
            this.panel63.Size = new System.Drawing.Size(743, 88);
            this.panel63.TabIndex = 43;
            // 
            // btnTerminarPedido
            // 
            this.btnTerminarPedido.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTerminarPedido.Image = global::BakeBookerGUI_1._0.Properties.Resources.subir__1_;
            this.btnTerminarPedido.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btnTerminarPedido.Location = new System.Drawing.Point(372, 5);
            this.btnTerminarPedido.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnTerminarPedido.Name = "btnTerminarPedido";
            this.btnTerminarPedido.Size = new System.Drawing.Size(366, 83);
            this.btnTerminarPedido.TabIndex = 54;
            this.btnTerminarPedido.Text = "Terminar Pedido";
            this.btnTerminarPedido.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnTerminarPedido.UseVisualStyleBackColor = true;
            // 
            // btnAgregarAPedido
            // 
            this.btnAgregarAPedido.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAgregarAPedido.Image = global::BakeBookerGUI_1._0.Properties.Resources.torta;
            this.btnAgregarAPedido.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btnAgregarAPedido.Location = new System.Drawing.Point(3, 3);
            this.btnAgregarAPedido.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAgregarAPedido.Name = "btnAgregarAPedido";
            this.btnAgregarAPedido.Size = new System.Drawing.Size(363, 80);
            this.btnAgregarAPedido.TabIndex = 24;
            this.btnAgregarAPedido.Text = "Agregar al pedido";
            this.btnAgregarAPedido.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnAgregarAPedido.UseVisualStyleBackColor = true;
            this.btnAgregarAPedido.Click += new System.EventHandler(this.btnAgregarAPedido_Click);
            // 
            // PanelPastel
            // 
            this.PanelPastel.BackColor = System.Drawing.Color.White;
            this.PanelPastel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.PanelPastel.Controls.Add(this.PedidosYProductos);
            this.PanelPastel.Controls.Add(this.label48);
            this.PanelPastel.Location = new System.Drawing.Point(0, 4);
            this.PanelPastel.Name = "PanelPastel";
            this.PanelPastel.Size = new System.Drawing.Size(744, 474);
            this.PanelPastel.TabIndex = 41;
            // 
            // PedidosYProductos
            // 
            this.PedidosYProductos.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.PedidosYProductos.Controls.Add(this.Pedido);
            this.PedidosYProductos.Controls.Add(this.Producto);
            this.PedidosYProductos.ItemSize = new System.Drawing.Size(0, 21);
            this.PedidosYProductos.Location = new System.Drawing.Point(3, 24);
            this.PedidosYProductos.Name = "PedidosYProductos";
            this.PedidosYProductos.SelectedIndex = 0;
            this.PedidosYProductos.Size = new System.Drawing.Size(733, 450);
            this.PedidosYProductos.TabIndex = 9;
            // 
            // Pedido
            // 
            this.Pedido.Controls.Add(this.CBBTamañoPedido);
            this.Pedido.Controls.Add(this.CBBRellenoPan);
            this.Pedido.Controls.Add(this.panel64);
            this.Pedido.Controls.Add(this.pbxImagenPastel);
            this.Pedido.Controls.Add(this.label52);
            this.Pedido.Controls.Add(this.CBBCantdidadPisos);
            this.Pedido.Controls.Add(this.txtPrecioPastel);
            this.Pedido.Controls.Add(this.label36);
            this.Pedido.Controls.Add(this.label31);
            this.Pedido.Controls.Add(this.btnCargarImagen);
            this.Pedido.Controls.Add(this.txtCantidaddePersonas);
            this.Pedido.Controls.Add(this.panel49);
            this.Pedido.Controls.Add(this.panel47);
            this.Pedido.Controls.Add(this.label32);
            this.Pedido.Controls.Add(this.panel46);
            this.Pedido.Controls.Add(this.panel45);
            this.Pedido.Controls.Add(this.label47);
            this.Pedido.Controls.Add(this.txtNotasPedido);
            this.Pedido.Controls.Add(this.label30);
            this.Pedido.Controls.Add(this.panel44);
            this.Pedido.Controls.Add(this.txtTipoDePan);
            this.Pedido.Controls.Add(this.label37);
            this.Pedido.Location = new System.Drawing.Point(4, 25);
            this.Pedido.Name = "Pedido";
            this.Pedido.Padding = new System.Windows.Forms.Padding(3);
            this.Pedido.Size = new System.Drawing.Size(725, 421);
            this.Pedido.TabIndex = 0;
            this.Pedido.Text = "Pedido";
            this.Pedido.UseVisualStyleBackColor = true;
            // 
            // CBBTamañoPedido
            // 
            this.CBBTamañoPedido.FormattingEnabled = true;
            this.CBBTamañoPedido.Items.AddRange(new object[] {
            "Pequeño",
            "Mediano",
            "Grande",
            "Extra Grande",
            "Quinceñera"});
            this.CBBTamañoPedido.Location = new System.Drawing.Point(220, 144);
            this.CBBTamañoPedido.Name = "CBBTamañoPedido";
            this.CBBTamañoPedido.Size = new System.Drawing.Size(121, 21);
            this.CBBTamañoPedido.TabIndex = 53;
            // 
            // CBBRellenoPan
            // 
            this.CBBRellenoPan.FormattingEnabled = true;
            this.CBBRellenoPan.Items.AddRange(new object[] {
            "Vainilla",
            "Fresa",
            "Chocolate"});
            this.CBBRellenoPan.Location = new System.Drawing.Point(223, 60);
            this.CBBRellenoPan.Name = "CBBRellenoPan";
            this.CBBRellenoPan.Size = new System.Drawing.Size(121, 21);
            this.CBBRellenoPan.TabIndex = 52;
            // 
            // panel64
            // 
            this.panel64.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel64.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel64.Location = new System.Drawing.Point(8, 223);
            this.panel64.Name = "panel64";
            this.panel64.Size = new System.Drawing.Size(337, 5);
            this.panel64.TabIndex = 51;
            // 
            // pbxImagenPastel
            // 
            this.pbxImagenPastel.BackColor = System.Drawing.Color.Transparent;
            this.pbxImagenPastel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbxImagenPastel.ErrorImage = global::BakeBookerGUI_1._0.Properties.Resources.Logo_para_pastelería_postres_minimalista_rosa__1_;
            this.pbxImagenPastel.InitialImage = global::BakeBookerGUI_1._0.Properties.Resources.Logo_para_pastelería_postres_minimalista_rosa__1_;
            this.pbxImagenPastel.Location = new System.Drawing.Point(357, 169);
            this.pbxImagenPastel.Margin = new System.Windows.Forms.Padding(4);
            this.pbxImagenPastel.Name = "pbxImagenPastel";
            this.pbxImagenPastel.Size = new System.Drawing.Size(364, 221);
            this.pbxImagenPastel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbxImagenPastel.TabIndex = 37;
            this.pbxImagenPastel.TabStop = false;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(6, 201);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(43, 16);
            this.label52.TabIndex = 50;
            this.label52.Text = "Precio ";
            // 
            // CBBCantdidadPisos
            // 
            this.CBBCantdidadPisos.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBBCantdidadPisos.FormattingEnabled = true;
            this.CBBCantdidadPisos.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6"});
            this.CBBCantdidadPisos.Location = new System.Drawing.Point(224, 249);
            this.CBBCantdidadPisos.Margin = new System.Windows.Forms.Padding(4);
            this.CBBCantdidadPisos.Name = "CBBCantdidadPisos";
            this.CBBCantdidadPisos.Size = new System.Drawing.Size(118, 24);
            this.CBBCantdidadPisos.TabIndex = 28;
            // 
            // txtPrecioPastel
            // 
            this.txtPrecioPastel.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrecioPastel.Location = new System.Drawing.Point(223, 198);
            this.txtPrecioPastel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtPrecioPastel.Name = "txtPrecioPastel";
            this.txtPrecioPastel.Size = new System.Drawing.Size(122, 23);
            this.txtPrecioPastel.TabIndex = 49;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(5, 64);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(85, 16);
            this.label36.TabIndex = 25;
            this.label36.Text = "Relleno de pan";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(5, 102);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(121, 16);
            this.label31.TabIndex = 32;
            this.label31.Text = "Cantidad de personas";
            // 
            // btnCargarImagen
            // 
            this.btnCargarImagen.Font = new System.Drawing.Font("Gadugi", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCargarImagen.Image = global::BakeBookerGUI_1._0.Properties.Resources.camara_fotografica;
            this.btnCargarImagen.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnCargarImagen.Location = new System.Drawing.Point(355, 86);
            this.btnCargarImagen.Name = "btnCargarImagen";
            this.btnCargarImagen.Size = new System.Drawing.Size(364, 71);
            this.btnCargarImagen.TabIndex = 47;
            this.btnCargarImagen.Text = "Subir Imagen";
            this.btnCargarImagen.UseVisualStyleBackColor = true;
            this.btnCargarImagen.Click += new System.EventHandler(this.btnCargarImagen_Click);
            // 
            // txtCantidaddePersonas
            // 
            this.txtCantidaddePersonas.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCantidaddePersonas.Location = new System.Drawing.Point(222, 99);
            this.txtCantidaddePersonas.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCantidaddePersonas.Name = "txtCantidaddePersonas";
            this.txtCantidaddePersonas.Size = new System.Drawing.Size(122, 23);
            this.txtCantidaddePersonas.TabIndex = 31;
            // 
            // panel49
            // 
            this.panel49.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel49.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel49.Location = new System.Drawing.Point(8, 172);
            this.panel49.Name = "panel49";
            this.panel49.Size = new System.Drawing.Size(337, 5);
            this.panel49.TabIndex = 45;
            // 
            // panel47
            // 
            this.panel47.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel47.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel47.Location = new System.Drawing.Point(7, 130);
            this.panel47.Name = "panel47";
            this.panel47.Size = new System.Drawing.Size(337, 5);
            this.panel47.TabIndex = 44;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(6, 150);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(107, 16);
            this.label32.TabIndex = 30;
            this.label32.Text = "Tamaño de Pedido";
            // 
            // panel46
            // 
            this.panel46.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel46.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel46.Location = new System.Drawing.Point(7, 87);
            this.panel46.Name = "panel46";
            this.panel46.Size = new System.Drawing.Size(337, 5);
            this.panel46.TabIndex = 43;
            // 
            // panel45
            // 
            this.panel45.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel45.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel45.Location = new System.Drawing.Point(7, 42);
            this.panel45.Name = "panel45";
            this.panel45.Size = new System.Drawing.Size(337, 5);
            this.panel45.TabIndex = 42;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(2, 19);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(70, 16);
            this.label47.TabIndex = 23;
            this.label47.Text = "Tipo de pan";
            // 
            // txtNotasPedido
            // 
            this.txtNotasPedido.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNotasPedido.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNotasPedido.Location = new System.Drawing.Point(7, 303);
            this.txtNotasPedido.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNotasPedido.Multiline = true;
            this.txtNotasPedido.Name = "txtNotasPedido";
            this.txtNotasPedido.Size = new System.Drawing.Size(338, 87);
            this.txtNotasPedido.TabIndex = 33;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(6, 283);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(38, 16);
            this.label30.TabIndex = 34;
            this.label30.Text = "Notas";
            // 
            // panel44
            // 
            this.panel44.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel44.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel44.Location = new System.Drawing.Point(8, 275);
            this.panel44.Name = "panel44";
            this.panel44.Size = new System.Drawing.Size(337, 5);
            this.panel44.TabIndex = 41;
            // 
            // txtTipoDePan
            // 
            this.txtTipoDePan.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTipoDePan.Location = new System.Drawing.Point(223, 16);
            this.txtTipoDePan.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTipoDePan.Name = "txtTipoDePan";
            this.txtTipoDePan.Size = new System.Drawing.Size(118, 23);
            this.txtTipoDePan.TabIndex = 21;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(3, 252);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(104, 16);
            this.label37.TabIndex = 22;
            this.label37.Text = "Cantidad de pisos:";
            // 
            // Producto
            // 
            this.Producto.Controls.Add(this.panel73);
            this.Producto.Controls.Add(this.label76);
            this.Producto.Controls.Add(this.label64);
            this.Producto.Controls.Add(this.label73);
            this.Producto.Controls.Add(this.panel69);
            this.Producto.Controls.Add(this.panel70);
            this.Producto.Controls.Add(this.label74);
            this.Producto.Controls.Add(this.panel71);
            this.Producto.Controls.Add(this.panel72);
            this.Producto.Controls.Add(this.label75);
            this.Producto.Controls.Add(this.LBLCantidadDisponible);
            this.Producto.Controls.Add(this.LBLcostoUnitarioProducto);
            this.Producto.Controls.Add(this.LBLIDPRODUCTO);
            this.Producto.Controls.Add(this.comboboxCantidadProducto);
            this.Producto.Controls.Add(this.CBBNombreProducto);
            this.Producto.Controls.Add(this.pictureBox5);
            this.Producto.Controls.Add(this.TXTDescripcion);
            this.Producto.Controls.Add(this.label63);
            this.Producto.Location = new System.Drawing.Point(4, 25);
            this.Producto.Name = "Producto";
            this.Producto.Padding = new System.Windows.Forms.Padding(3);
            this.Producto.Size = new System.Drawing.Size(725, 421);
            this.Producto.TabIndex = 1;
            this.Producto.Text = "Producto";
            this.Producto.UseVisualStyleBackColor = true;
            // 
            // panel73
            // 
            this.panel73.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel73.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel73.Location = new System.Drawing.Point(11, 267);
            this.panel73.Name = "panel73";
            this.panel73.Size = new System.Drawing.Size(337, 5);
            this.panel73.TabIndex = 92;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label76.Location = new System.Drawing.Point(8, 241);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(73, 16);
            this.label76.TabIndex = 91;
            this.label76.Text = "ID: producto";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.Location = new System.Drawing.Point(6, 183);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(83, 16);
            this.label64.TabIndex = 84;
            this.label64.Text = "Costo Unitario";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label73.Location = new System.Drawing.Point(8, 86);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(55, 16);
            this.label73.TabIndex = 86;
            this.label73.Text = "Cantidad";
            // 
            // panel69
            // 
            this.panel69.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel69.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel69.Location = new System.Drawing.Point(8, 165);
            this.panel69.Name = "panel69";
            this.panel69.Size = new System.Drawing.Size(337, 5);
            this.panel69.TabIndex = 90;
            // 
            // panel70
            // 
            this.panel70.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel70.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel70.Location = new System.Drawing.Point(8, 113);
            this.panel70.Name = "panel70";
            this.panel70.Size = new System.Drawing.Size(337, 5);
            this.panel70.TabIndex = 89;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label74.Location = new System.Drawing.Point(6, 138);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(114, 16);
            this.label74.TabIndex = 85;
            this.label74.Text = "Cantidad Disponible";
            // 
            // panel71
            // 
            this.panel71.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel71.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel71.Location = new System.Drawing.Point(8, 206);
            this.panel71.Name = "panel71";
            this.panel71.Size = new System.Drawing.Size(337, 5);
            this.panel71.TabIndex = 88;
            // 
            // panel72
            // 
            this.panel72.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel72.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel72.Location = new System.Drawing.Point(9, 63);
            this.panel72.Name = "panel72";
            this.panel72.Size = new System.Drawing.Size(337, 5);
            this.panel72.TabIndex = 87;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label75.Location = new System.Drawing.Point(8, 36);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(56, 16);
            this.label75.TabIndex = 83;
            this.label75.Text = "Producto";
            // 
            // LBLCantidadDisponible
            // 
            this.LBLCantidadDisponible.AutoSize = true;
            this.LBLCantidadDisponible.Location = new System.Drawing.Point(220, 143);
            this.LBLCantidadDisponible.Name = "LBLCantidadDisponible";
            this.LBLCantidadDisponible.Size = new System.Drawing.Size(0, 13);
            this.LBLCantidadDisponible.TabIndex = 82;
            // 
            // LBLcostoUnitarioProducto
            // 
            this.LBLcostoUnitarioProducto.AutoSize = true;
            this.LBLcostoUnitarioProducto.Location = new System.Drawing.Point(241, 185);
            this.LBLcostoUnitarioProducto.Name = "LBLcostoUnitarioProducto";
            this.LBLcostoUnitarioProducto.Size = new System.Drawing.Size(0, 13);
            this.LBLcostoUnitarioProducto.TabIndex = 80;
            // 
            // LBLIDPRODUCTO
            // 
            this.LBLIDPRODUCTO.AutoSize = true;
            this.LBLIDPRODUCTO.Location = new System.Drawing.Point(221, 244);
            this.LBLIDPRODUCTO.Name = "LBLIDPRODUCTO";
            this.LBLIDPRODUCTO.Size = new System.Drawing.Size(0, 13);
            this.LBLIDPRODUCTO.TabIndex = 78;
            // 
            // comboboxCantidadProducto
            // 
            this.comboboxCantidadProducto.FormattingEnabled = true;
            this.comboboxCantidadProducto.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboboxCantidadProducto.Location = new System.Drawing.Point(220, 86);
            this.comboboxCantidadProducto.Name = "comboboxCantidadProducto";
            this.comboboxCantidadProducto.Size = new System.Drawing.Size(124, 21);
            this.comboboxCantidadProducto.TabIndex = 76;
            // 
            // CBBNombreProducto
            // 
            this.CBBNombreProducto.FormattingEnabled = true;
            this.CBBNombreProducto.Location = new System.Drawing.Point(222, 36);
            this.CBBNombreProducto.Name = "CBBNombreProducto";
            this.CBBNombreProducto.Size = new System.Drawing.Size(124, 21);
            this.CBBNombreProducto.TabIndex = 74;
            this.CBBNombreProducto.SelectedIndexChanged += new System.EventHandler(this.comboboxIDProducto_SelectedIndexChanged);
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox5.ErrorImage = global::BakeBookerGUI_1._0.Properties.Resources.Logo_para_pastelería_postres_minimalista_rosa__1_;
            this.pictureBox5.InitialImage = global::BakeBookerGUI_1._0.Properties.Resources.Logo_para_pastelería_postres_minimalista_rosa__1_;
            this.pictureBox5.Location = new System.Drawing.Point(363, 36);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(340, 221);
            this.pictureBox5.TabIndex = 72;
            this.pictureBox5.TabStop = false;
            // 
            // TXTDescripcion
            // 
            this.TXTDescripcion.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTDescripcion.Location = new System.Drawing.Point(9, 315);
            this.TXTDescripcion.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TXTDescripcion.Multiline = true;
            this.TXTDescripcion.Name = "TXTDescripcion";
            this.TXTDescripcion.ReadOnly = true;
            this.TXTDescripcion.Size = new System.Drawing.Size(337, 87);
            this.TXTDescripcion.TabIndex = 62;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label63.Location = new System.Drawing.Point(6, 287);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(38, 16);
            this.label63.TabIndex = 63;
            this.label63.Text = "Notas";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Dock = System.Windows.Forms.DockStyle.Top;
            this.label48.Font = new System.Drawing.Font("Gadugi", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(0, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(372, 21);
            this.label48.TabIndex = 48;
            this.label48.Text = "Ingrese los datos de la orden o Producto";
            // 
            // panel50
            // 
            this.panel50.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel50.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel50.Location = new System.Drawing.Point(2, 467);
            this.panel50.Name = "panel50";
            this.panel50.Size = new System.Drawing.Size(744, 5);
            this.panel50.TabIndex = 46;
            // 
            // panel43
            // 
            this.panel43.BackColor = System.Drawing.Color.White;
            this.panel43.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel43.Controls.Add(this.btnBuscarClientePedido);
            this.panel43.Controls.Add(this.label53);
            this.panel43.Controls.Add(this.DGVPEDIDOINICIO);
            this.panel43.Controls.Add(this.panel51);
            this.panel43.Controls.Add(this.label33);
            this.panel43.Controls.Add(this.txtNombreClientePedido);
            this.panel43.Controls.Add(this.label35);
            this.panel43.Location = new System.Drawing.Point(2, 1);
            this.panel43.Name = "panel43";
            this.panel43.Size = new System.Drawing.Size(629, 184);
            this.panel43.TabIndex = 39;
            // 
            // btnBuscarClientePedido
            // 
            this.btnBuscarClientePedido.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarClientePedido.Image = global::BakeBookerGUI_1._0.Properties.Resources.ciencias_sociales__1_;
            this.btnBuscarClientePedido.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBuscarClientePedido.Location = new System.Drawing.Point(504, 112);
            this.btnBuscarClientePedido.Name = "btnBuscarClientePedido";
            this.btnBuscarClientePedido.Size = new System.Drawing.Size(113, 61);
            this.btnBuscarClientePedido.TabIndex = 48;
            this.btnBuscarClientePedido.Text = "Buscar Cliente";
            this.btnBuscarClientePedido.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBuscarClientePedido.UseVisualStyleBackColor = true;
            this.btnBuscarClientePedido.Click += new System.EventHandler(this.btnBuscarClientePedido_Click);
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Gadugi", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(3, 64);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(167, 19);
            this.label53.TabIndex = 47;
            this.label53.Text = "Seleccione el Cliente";
            // 
            // DGVPEDIDOINICIO
            // 
            this.DGVPEDIDOINICIO.AllowUserToAddRows = false;
            this.DGVPEDIDOINICIO.AllowUserToDeleteRows = false;
            this.DGVPEDIDOINICIO.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DGVPEDIDOINICIO.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.DGVPEDIDOINICIO.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DGVPEDIDOINICIO.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.DGVPEDIDOINICIO.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
            this.DGVPEDIDOINICIO.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.DGVPEDIDOINICIO.ColumnHeadersHeight = 29;
            this.DGVPEDIDOINICIO.Location = new System.Drawing.Point(-1, 90);
            this.DGVPEDIDOINICIO.Name = "DGVPEDIDOINICIO";
            this.DGVPEDIDOINICIO.ReadOnly = true;
            this.DGVPEDIDOINICIO.RowHeadersWidth = 51;
            this.DGVPEDIDOINICIO.RowTemplate.Height = 24;
            this.DGVPEDIDOINICIO.Size = new System.Drawing.Size(484, 87);
            this.DGVPEDIDOINICIO.TabIndex = 46;
            this.DGVPEDIDOINICIO.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVPEDIDOINICIO_CellClick);
            // 
            // panel51
            // 
            this.panel51.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel51.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel51.Location = new System.Drawing.Point(5, 56);
            this.panel51.Name = "panel51";
            this.panel51.Size = new System.Drawing.Size(480, 5);
            this.panel51.TabIndex = 40;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Gadugi", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(3, 4);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(455, 21);
            this.label33.TabIndex = 33;
            this.label33.Text = "Ingresa los siguientes datos para iniciar un pedido";
            // 
            // txtNombreClientePedido
            // 
            this.txtNombreClientePedido.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombreClientePedido.Location = new System.Drawing.Point(181, 28);
            this.txtNombreClientePedido.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNombreClientePedido.Multiline = true;
            this.txtNombreClientePedido.Name = "txtNombreClientePedido";
            this.txtNombreClientePedido.Size = new System.Drawing.Size(302, 23);
            this.txtNombreClientePedido.TabIndex = 29;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(15, 32);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(126, 17);
            this.label35.TabIndex = 32;
            this.label35.Text = "Nombre del cliente:";
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.LightCoral;
            this.tabPage4.Controls.Add(this.panel48);
            this.tabPage4.Controls.Add(this.panel86);
            this.tabPage4.Controls.Add(this.panel87);
            this.tabPage4.Controls.Add(this.groupBox2);
            this.tabPage4.Controls.Add(this.panel60);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1385, 584);
            this.tabPage4.TabIndex = 0;
            this.tabPage4.Text = "Buscar";
            // 
            // panel48
            // 
            this.panel48.BackColor = System.Drawing.Color.White;
            this.panel48.Controls.Add(this.btnPedidoMod);
            this.panel48.Controls.Add(this.btnOrdenMod);
            this.panel48.Controls.Add(this.bntProductoMod);
            this.panel48.Location = new System.Drawing.Point(462, 3);
            this.panel48.Name = "panel48";
            this.panel48.Size = new System.Drawing.Size(921, 100);
            this.panel48.TabIndex = 58;
            // 
            // btnPedidoMod
            // 
            this.btnPedidoMod.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPedidoMod.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPedidoMod.ForeColor = System.Drawing.Color.Black;
            this.btnPedidoMod.Image = global::BakeBookerGUI_1._0.Properties.Resources.pastel;
            this.btnPedidoMod.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btnPedidoMod.Location = new System.Drawing.Point(3, 7);
            this.btnPedidoMod.Name = "btnPedidoMod";
            this.btnPedidoMod.Size = new System.Drawing.Size(305, 90);
            this.btnPedidoMod.TabIndex = 46;
            this.btnPedidoMod.Text = "Pedido";
            this.btnPedidoMod.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnPedidoMod.UseVisualStyleBackColor = true;
            this.btnPedidoMod.Click += new System.EventHandler(this.btnPedidoMod_Click);
            // 
            // btnOrdenMod
            // 
            this.btnOrdenMod.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOrdenMod.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOrdenMod.ForeColor = System.Drawing.Color.Black;
            this.btnOrdenMod.Image = global::BakeBookerGUI_1._0.Properties.Resources.pastel;
            this.btnOrdenMod.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btnOrdenMod.Location = new System.Drawing.Point(310, 7);
            this.btnOrdenMod.Name = "btnOrdenMod";
            this.btnOrdenMod.Size = new System.Drawing.Size(305, 90);
            this.btnOrdenMod.TabIndex = 39;
            this.btnOrdenMod.Text = "Orden";
            this.btnOrdenMod.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnOrdenMod.UseVisualStyleBackColor = true;
            this.btnOrdenMod.Click += new System.EventHandler(this.btnOrdenMod_Click);
            // 
            // bntProductoMod
            // 
            this.bntProductoMod.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bntProductoMod.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bntProductoMod.ForeColor = System.Drawing.Color.Black;
            this.bntProductoMod.Image = global::BakeBookerGUI_1._0.Properties.Resources.macarron;
            this.bntProductoMod.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.bntProductoMod.Location = new System.Drawing.Point(618, 7);
            this.bntProductoMod.Name = "bntProductoMod";
            this.bntProductoMod.Size = new System.Drawing.Size(300, 90);
            this.bntProductoMod.TabIndex = 45;
            this.bntProductoMod.Text = "Producto";
            this.bntProductoMod.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.bntProductoMod.UseVisualStyleBackColor = true;
            this.bntProductoMod.Click += new System.EventHandler(this.bntProductoMod_Click);
            // 
            // panel86
            // 
            this.panel86.BackColor = System.Drawing.Color.White;
            this.panel86.Controls.Add(this.DGVBUSQUEDAPEDIDO);
            this.panel86.Controls.Add(this.label79);
            this.panel86.Location = new System.Drawing.Point(2, 260);
            this.panel86.Name = "panel86";
            this.panel86.Size = new System.Drawing.Size(454, 162);
            this.panel86.TabIndex = 57;
            // 
            // DGVBUSQUEDAPEDIDO
            // 
            this.DGVBUSQUEDAPEDIDO.AllowUserToAddRows = false;
            this.DGVBUSQUEDAPEDIDO.AllowUserToDeleteRows = false;
            this.DGVBUSQUEDAPEDIDO.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DGVBUSQUEDAPEDIDO.BackgroundColor = System.Drawing.Color.Maroon;
            this.DGVBUSQUEDAPEDIDO.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.DGVBUSQUEDAPEDIDO.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVBUSQUEDAPEDIDO.Location = new System.Drawing.Point(9, 32);
            this.DGVBUSQUEDAPEDIDO.Name = "DGVBUSQUEDAPEDIDO";
            this.DGVBUSQUEDAPEDIDO.ReadOnly = true;
            this.DGVBUSQUEDAPEDIDO.RowHeadersWidth = 51;
            this.DGVBUSQUEDAPEDIDO.RowTemplate.Height = 24;
            this.DGVBUSQUEDAPEDIDO.Size = new System.Drawing.Size(438, 125);
            this.DGVBUSQUEDAPEDIDO.TabIndex = 40;
            this.DGVBUSQUEDAPEDIDO.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVBUSQUEDAPEDIDO_CellClick);
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Font = new System.Drawing.Font("Gadugi", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label79.Location = new System.Drawing.Point(6, 7);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(70, 19);
            this.label79.TabIndex = 51;
            this.label79.Text = "Pedidos";
            // 
            // panel87
            // 
            this.panel87.BackColor = System.Drawing.Color.White;
            this.panel87.Controls.Add(this.DGVBUSQUEDADETALLESPEDIDO);
            this.panel87.Controls.Add(this.label83);
            this.panel87.Location = new System.Drawing.Point(2, 423);
            this.panel87.Name = "panel87";
            this.panel87.Size = new System.Drawing.Size(454, 161);
            this.panel87.TabIndex = 56;
            // 
            // DGVBUSQUEDADETALLESPEDIDO
            // 
            this.DGVBUSQUEDADETALLESPEDIDO.AllowUserToAddRows = false;
            this.DGVBUSQUEDADETALLESPEDIDO.AllowUserToDeleteRows = false;
            this.DGVBUSQUEDADETALLESPEDIDO.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DGVBUSQUEDADETALLESPEDIDO.BackgroundColor = System.Drawing.Color.Maroon;
            this.DGVBUSQUEDADETALLESPEDIDO.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.DGVBUSQUEDADETALLESPEDIDO.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVBUSQUEDADETALLESPEDIDO.Location = new System.Drawing.Point(2, 28);
            this.DGVBUSQUEDADETALLESPEDIDO.Name = "DGVBUSQUEDADETALLESPEDIDO";
            this.DGVBUSQUEDADETALLESPEDIDO.ReadOnly = true;
            this.DGVBUSQUEDADETALLESPEDIDO.RowHeadersWidth = 51;
            this.DGVBUSQUEDADETALLESPEDIDO.RowTemplate.Height = 24;
            this.DGVBUSQUEDADETALLESPEDIDO.Size = new System.Drawing.Size(440, 127);
            this.DGVBUSQUEDADETALLESPEDIDO.TabIndex = 40;
            this.DGVBUSQUEDADETALLESPEDIDO.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVBUSQUEDADETALLESPEDIDO_CellClick);
            this.DGVBUSQUEDADETALLESPEDIDO.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVBUSQUEDADETALLESPEDIDO_CellContentClick);
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Font = new System.Drawing.Font("Gadugi", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label83.Location = new System.Drawing.Point(7, 6);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(157, 19);
            this.label83.TabIndex = 51;
            this.label83.Text = "Detalles del pedido";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.White;
            this.groupBox2.Controls.Add(this.TABMODIFICARPEDIDO);
            this.groupBox2.Controls.Add(this.btnModGen);
            this.groupBox2.Controls.Add(this.btnEliminarGen);
            this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox2.Font = new System.Drawing.Font("Gadugi", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(462, 106);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(921, 472);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            // 
            // TABMODIFICARPEDIDO
            // 
            this.TABMODIFICARPEDIDO.Controls.Add(this.Pedido2);
            this.TABMODIFICARPEDIDO.Controls.Add(this.Orden2);
            this.TABMODIFICARPEDIDO.Controls.Add(this.Producto2);
            this.TABMODIFICARPEDIDO.Font = new System.Drawing.Font("Gadugi", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TABMODIFICARPEDIDO.Location = new System.Drawing.Point(0, 0);
            this.TABMODIFICARPEDIDO.Name = "TABMODIFICARPEDIDO";
            this.TABMODIFICARPEDIDO.SelectedIndex = 0;
            this.TABMODIFICARPEDIDO.Size = new System.Drawing.Size(751, 469);
            this.TABMODIFICARPEDIDO.TabIndex = 82;
            // 
            // Pedido2
            // 
            this.Pedido2.Controls.Add(this.panel106);
            this.Pedido2.Controls.Add(this.label88);
            this.Pedido2.Controls.Add(this.txtIDPEDIDOMODFICIAR);
            this.Pedido2.Controls.Add(this.RADRECOGERMODIFICAR);
            this.Pedido2.Controls.Add(this.RADLLEVARMODIFICAR);
            this.Pedido2.Controls.Add(this.DTPFECHAENTREGAMOD);
            this.Pedido2.Controls.Add(this.DTPFECHAPEDIDOMODIFICAR);
            this.Pedido2.Controls.Add(this.panel82);
            this.Pedido2.Controls.Add(this.label51);
            this.Pedido2.Controls.Add(this.label59);
            this.Pedido2.Controls.Add(this.label61);
            this.Pedido2.Controls.Add(this.TXTANTICIPOMODIFICAR);
            this.Pedido2.Controls.Add(this.panel84);
            this.Pedido2.Controls.Add(this.TXTTOTALMODIFICAR);
            this.Pedido2.Controls.Add(this.panel88);
            this.Pedido2.Controls.Add(this.label62);
            this.Pedido2.Controls.Add(this.panel89);
            this.Pedido2.Controls.Add(this.panel90);
            this.Pedido2.Controls.Add(this.label72);
            this.Pedido2.Controls.Add(this.panel91);
            this.Pedido2.Controls.Add(this.TXTIDCLIENTEMODIFICAR);
            this.Pedido2.Controls.Add(this.label78);
            this.Pedido2.Controls.Add(this.panel57);
            this.Pedido2.Controls.Add(this.panel58);
            this.Pedido2.Controls.Add(this.textBox33);
            this.Pedido2.Controls.Add(this.label44);
            this.Pedido2.Controls.Add(this.label45);
            this.Pedido2.Controls.Add(this.textBox36);
            this.Pedido2.Location = new System.Drawing.Point(4, 23);
            this.Pedido2.Name = "Pedido2";
            this.Pedido2.Padding = new System.Windows.Forms.Padding(3);
            this.Pedido2.Size = new System.Drawing.Size(743, 442);
            this.Pedido2.TabIndex = 0;
            this.Pedido2.Text = "Pedido";
            this.Pedido2.UseVisualStyleBackColor = true;
            // 
            // panel106
            // 
            this.panel106.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel106.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel106.Location = new System.Drawing.Point(14, 49);
            this.panel106.Name = "panel106";
            this.panel106.Size = new System.Drawing.Size(337, 5);
            this.panel106.TabIndex = 120;
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label88.Location = new System.Drawing.Point(9, 26);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(58, 16);
            this.label88.TabIndex = 119;
            this.label88.Text = "ID pedido";
            // 
            // txtIDPEDIDOMODFICIAR
            // 
            this.txtIDPEDIDOMODFICIAR.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIDPEDIDOMODFICIAR.Location = new System.Drawing.Point(230, 23);
            this.txtIDPEDIDOMODFICIAR.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtIDPEDIDOMODFICIAR.Name = "txtIDPEDIDOMODFICIAR";
            this.txtIDPEDIDOMODFICIAR.Size = new System.Drawing.Size(118, 23);
            this.txtIDPEDIDOMODFICIAR.TabIndex = 118;
            // 
            // RADRECOGERMODIFICAR
            // 
            this.RADRECOGERMODIFICAR.AutoSize = true;
            this.RADRECOGERMODIFICAR.Checked = true;
            this.RADRECOGERMODIFICAR.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RADRECOGERMODIFICAR.Location = new System.Drawing.Point(183, 254);
            this.RADRECOGERMODIFICAR.Margin = new System.Windows.Forms.Padding(4);
            this.RADRECOGERMODIFICAR.Name = "RADRECOGERMODIFICAR";
            this.RADRECOGERMODIFICAR.Size = new System.Drawing.Size(68, 20);
            this.RADRECOGERMODIFICAR.TabIndex = 116;
            this.RADRECOGERMODIFICAR.TabStop = true;
            this.RADRECOGERMODIFICAR.Text = "Recoger";
            this.RADRECOGERMODIFICAR.UseVisualStyleBackColor = true;
            // 
            // RADLLEVARMODIFICAR
            // 
            this.RADLLEVARMODIFICAR.AutoSize = true;
            this.RADLLEVARMODIFICAR.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RADLLEVARMODIFICAR.Location = new System.Drawing.Point(289, 254);
            this.RADLLEVARMODIFICAR.Margin = new System.Windows.Forms.Padding(4);
            this.RADLLEVARMODIFICAR.Name = "RADLLEVARMODIFICAR";
            this.RADLLEVARMODIFICAR.Size = new System.Drawing.Size(59, 20);
            this.RADLLEVARMODIFICAR.TabIndex = 117;
            this.RADLLEVARMODIFICAR.Text = "LLevar";
            this.RADLLEVARMODIFICAR.UseVisualStyleBackColor = true;
            // 
            // DTPFECHAENTREGAMOD
            // 
            this.DTPFECHAENTREGAMOD.Location = new System.Drawing.Point(183, 305);
            this.DTPFECHAENTREGAMOD.Name = "DTPFECHAENTREGAMOD";
            this.DTPFECHAENTREGAMOD.Size = new System.Drawing.Size(166, 22);
            this.DTPFECHAENTREGAMOD.TabIndex = 115;
            // 
            // DTPFECHAPEDIDOMODIFICAR
            // 
            this.DTPFECHAPEDIDOMODIFICAR.Location = new System.Drawing.Point(183, 116);
            this.DTPFECHAPEDIDOMODIFICAR.Name = "DTPFECHAPEDIDOMODIFICAR";
            this.DTPFECHAPEDIDOMODIFICAR.Size = new System.Drawing.Size(163, 22);
            this.DTPFECHAPEDIDOMODIFICAR.TabIndex = 114;
            // 
            // panel82
            // 
            this.panel82.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel82.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel82.Location = new System.Drawing.Point(12, 281);
            this.panel82.Name = "panel82";
            this.panel82.Size = new System.Drawing.Size(337, 5);
            this.panel82.TabIndex = 113;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(10, 259);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(84, 16);
            this.label51.TabIndex = 112;
            this.label51.Text = "Forma entrega";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.Location = new System.Drawing.Point(9, 122);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(94, 16);
            this.label59.TabIndex = 96;
            this.label59.Text = "Fecha de pedido";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.Location = new System.Drawing.Point(9, 160);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(52, 16);
            this.label61.TabIndex = 101;
            this.label61.Text = "Anticipo";
            // 
            // TXTANTICIPOMODIFICAR
            // 
            this.TXTANTICIPOMODIFICAR.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTANTICIPOMODIFICAR.Location = new System.Drawing.Point(226, 157);
            this.TXTANTICIPOMODIFICAR.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TXTANTICIPOMODIFICAR.Name = "TXTANTICIPOMODIFICAR";
            this.TXTANTICIPOMODIFICAR.Size = new System.Drawing.Size(122, 23);
            this.TXTANTICIPOMODIFICAR.TabIndex = 100;
            // 
            // panel84
            // 
            this.panel84.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel84.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel84.Location = new System.Drawing.Point(12, 230);
            this.panel84.Name = "panel84";
            this.panel84.Size = new System.Drawing.Size(337, 5);
            this.panel84.TabIndex = 109;
            // 
            // TXTTOTALMODIFICAR
            // 
            this.TXTTOTALMODIFICAR.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTTOTALMODIFICAR.Location = new System.Drawing.Point(227, 205);
            this.TXTTOTALMODIFICAR.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TXTTOTALMODIFICAR.Name = "TXTTOTALMODIFICAR";
            this.TXTTOTALMODIFICAR.Size = new System.Drawing.Size(122, 23);
            this.TXTTOTALMODIFICAR.TabIndex = 98;
            // 
            // panel88
            // 
            this.panel88.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel88.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel88.Location = new System.Drawing.Point(11, 188);
            this.panel88.Name = "panel88";
            this.panel88.Size = new System.Drawing.Size(337, 5);
            this.panel88.TabIndex = 108;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label62.Location = new System.Drawing.Point(10, 208);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(34, 16);
            this.label62.TabIndex = 99;
            this.label62.Text = "Total";
            // 
            // panel89
            // 
            this.panel89.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel89.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel89.Location = new System.Drawing.Point(11, 145);
            this.panel89.Name = "panel89";
            this.panel89.Size = new System.Drawing.Size(337, 5);
            this.panel89.TabIndex = 107;
            // 
            // panel90
            // 
            this.panel90.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel90.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel90.Location = new System.Drawing.Point(11, 100);
            this.panel90.Name = "panel90";
            this.panel90.Size = new System.Drawing.Size(337, 5);
            this.panel90.TabIndex = 106;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label72.Location = new System.Drawing.Point(6, 77);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(56, 16);
            this.label72.TabIndex = 94;
            this.label72.Text = "ID cliente";
            // 
            // panel91
            // 
            this.panel91.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel91.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel91.Location = new System.Drawing.Point(12, 333);
            this.panel91.Name = "panel91";
            this.panel91.Size = new System.Drawing.Size(337, 5);
            this.panel91.TabIndex = 105;
            // 
            // TXTIDCLIENTEMODIFICAR
            // 
            this.TXTIDCLIENTEMODIFICAR.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTIDCLIENTEMODIFICAR.Location = new System.Drawing.Point(227, 74);
            this.TXTIDCLIENTEMODIFICAR.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TXTIDCLIENTEMODIFICAR.Name = "TXTIDCLIENTEMODIFICAR";
            this.TXTIDCLIENTEMODIFICAR.Size = new System.Drawing.Size(118, 23);
            this.TXTIDCLIENTEMODIFICAR.TabIndex = 92;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label78.Location = new System.Drawing.Point(7, 310);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(97, 16);
            this.label78.TabIndex = 93;
            this.label78.Text = "Fecha de entrega";
            // 
            // panel57
            // 
            this.panel57.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel57.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel57.Location = new System.Drawing.Point(342, -16);
            this.panel57.Name = "panel57";
            this.panel57.Size = new System.Drawing.Size(428, 5);
            this.panel57.TabIndex = 91;
            // 
            // panel58
            // 
            this.panel58.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel58.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel58.Location = new System.Drawing.Point(345, -65);
            this.panel58.Name = "panel58";
            this.panel58.Size = new System.Drawing.Size(428, 5);
            this.panel58.TabIndex = 90;
            // 
            // textBox33
            // 
            this.textBox33.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox33.Location = new System.Drawing.Point(441, -102);
            this.textBox33.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox33.Multiline = true;
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(332, 32);
            this.textBox33.TabIndex = 81;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(334, -45);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(68, 18);
            this.label44.TabIndex = 88;
            this.label44.Text = "CORREO:";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(337, -97);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(73, 18);
            this.label45.TabIndex = 83;
            this.label45.Text = "APELLIDO";
            // 
            // textBox36
            // 
            this.textBox36.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox36.Location = new System.Drawing.Point(438, -53);
            this.textBox36.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox36.Multiline = true;
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(332, 32);
            this.textBox36.TabIndex = 86;
            // 
            // Orden2
            // 
            this.Orden2.Controls.Add(this.label34);
            this.Orden2.Controls.Add(this.txtIDOrdenModificar);
            this.Orden2.Controls.Add(this.txtIDPEDIDOMODIFICAR);
            this.Orden2.Controls.Add(this.panel104);
            this.Orden2.Controls.Add(this.label87);
            this.Orden2.Controls.Add(this.CBBTamañodePedidoModificar);
            this.Orden2.Controls.Add(this.CBBRellenodePanModificar);
            this.Orden2.Controls.Add(this.panel52);
            this.Orden2.Controls.Add(this.label29);
            this.Orden2.Controls.Add(this.CBBCantidadDePisosModificar);
            this.Orden2.Controls.Add(this.txtPrecioOrdenModificar);
            this.Orden2.Controls.Add(this.label39);
            this.Orden2.Controls.Add(this.label40);
            this.Orden2.Controls.Add(this.txtCantidadDePersonasModificar);
            this.Orden2.Controls.Add(this.panel53);
            this.Orden2.Controls.Add(this.panel54);
            this.Orden2.Controls.Add(this.label41);
            this.Orden2.Controls.Add(this.panel55);
            this.Orden2.Controls.Add(this.panel56);
            this.Orden2.Controls.Add(this.label42);
            this.Orden2.Controls.Add(this.txtNotasModificar);
            this.Orden2.Controls.Add(this.label43);
            this.Orden2.Controls.Add(this.panel59);
            this.Orden2.Controls.Add(this.txtTipodePanModificar);
            this.Orden2.Controls.Add(this.label50);
            this.Orden2.Controls.Add(this.PBMODIFICARPEDIDO);
            this.Orden2.Controls.Add(this.btnSubirImagenModificar);
            this.Orden2.Location = new System.Drawing.Point(4, 23);
            this.Orden2.Name = "Orden2";
            this.Orden2.Padding = new System.Windows.Forms.Padding(3);
            this.Orden2.Size = new System.Drawing.Size(743, 442);
            this.Orden2.TabIndex = 1;
            this.Orden2.Text = "Orden";
            this.Orden2.UseVisualStyleBackColor = true;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(14, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(18, 16);
            this.label34.TabIndex = 158;
            this.label34.Text = "ID";
            // 
            // txtIDOrdenModificar
            // 
            this.txtIDOrdenModificar.Location = new System.Drawing.Point(97, 3);
            this.txtIDOrdenModificar.Name = "txtIDOrdenModificar";
            this.txtIDOrdenModificar.ReadOnly = true;
            this.txtIDOrdenModificar.Size = new System.Drawing.Size(41, 22);
            this.txtIDOrdenModificar.TabIndex = 157;
            // 
            // txtIDPEDIDOMODIFICAR
            // 
            this.txtIDPEDIDOMODIFICAR.Location = new System.Drawing.Point(232, 18);
            this.txtIDPEDIDOMODIFICAR.Name = "txtIDPEDIDOMODIFICAR";
            this.txtIDPEDIDOMODIFICAR.Size = new System.Drawing.Size(121, 22);
            this.txtIDPEDIDOMODIFICAR.TabIndex = 156;
            // 
            // panel104
            // 
            this.panel104.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel104.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel104.Location = new System.Drawing.Point(19, 46);
            this.panel104.Name = "panel104";
            this.panel104.Size = new System.Drawing.Size(337, 5);
            this.panel104.TabIndex = 155;
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label87.Location = new System.Drawing.Point(14, 23);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(74, 16);
            this.label87.TabIndex = 154;
            this.label87.Text = "ID de pedido";
            // 
            // CBBTamañodePedidoModificar
            // 
            this.CBBTamañodePedidoModificar.FormattingEnabled = true;
            this.CBBTamañodePedidoModificar.Items.AddRange(new object[] {
            "Pequeño",
            "Mediano",
            "Grande",
            "Extra Grande",
            "Quinceñera"});
            this.CBBTamañodePedidoModificar.Location = new System.Drawing.Point(232, 187);
            this.CBBTamañodePedidoModificar.Name = "CBBTamañodePedidoModificar";
            this.CBBTamañodePedidoModificar.Size = new System.Drawing.Size(121, 22);
            this.CBBTamañodePedidoModificar.TabIndex = 152;
            // 
            // CBBRellenodePanModificar
            // 
            this.CBBRellenodePanModificar.FormattingEnabled = true;
            this.CBBRellenodePanModificar.Items.AddRange(new object[] {
            "Vainilla",
            "Fresa",
            "Chocolate"});
            this.CBBRellenodePanModificar.Location = new System.Drawing.Point(232, 103);
            this.CBBRellenodePanModificar.Name = "CBBRellenodePanModificar";
            this.CBBRellenodePanModificar.Size = new System.Drawing.Size(124, 22);
            this.CBBRellenodePanModificar.TabIndex = 151;
            // 
            // panel52
            // 
            this.panel52.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel52.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel52.Location = new System.Drawing.Point(20, 266);
            this.panel52.Name = "panel52";
            this.panel52.Size = new System.Drawing.Size(337, 5);
            this.panel52.TabIndex = 150;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(16, 241);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(43, 16);
            this.label29.TabIndex = 149;
            this.label29.Text = "Precio ";
            // 
            // CBBCantidadDePisosModificar
            // 
            this.CBBCantidadDePisosModificar.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBBCantidadDePisosModificar.FormattingEnabled = true;
            this.CBBCantidadDePisosModificar.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6"});
            this.CBBCantidadDePisosModificar.Location = new System.Drawing.Point(234, 291);
            this.CBBCantidadDePisosModificar.Margin = new System.Windows.Forms.Padding(4);
            this.CBBCantidadDePisosModificar.Name = "CBBCantidadDePisosModificar";
            this.CBBCantidadDePisosModificar.Size = new System.Drawing.Size(122, 24);
            this.CBBCantidadDePisosModificar.TabIndex = 137;
            // 
            // txtPrecioOrdenModificar
            // 
            this.txtPrecioOrdenModificar.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrecioOrdenModificar.Location = new System.Drawing.Point(232, 241);
            this.txtPrecioOrdenModificar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtPrecioOrdenModificar.Name = "txtPrecioOrdenModificar";
            this.txtPrecioOrdenModificar.Size = new System.Drawing.Size(125, 23);
            this.txtPrecioOrdenModificar.TabIndex = 148;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(17, 107);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(85, 16);
            this.label39.TabIndex = 136;
            this.label39.Text = "Relleno de pan";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(17, 145);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(121, 16);
            this.label40.TabIndex = 140;
            this.label40.Text = "Cantidad de personas";
            // 
            // txtCantidadDePersonasModificar
            // 
            this.txtCantidadDePersonasModificar.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCantidadDePersonasModificar.Location = new System.Drawing.Point(232, 142);
            this.txtCantidadDePersonasModificar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCantidadDePersonasModificar.Name = "txtCantidadDePersonasModificar";
            this.txtCantidadDePersonasModificar.Size = new System.Drawing.Size(124, 23);
            this.txtCantidadDePersonasModificar.TabIndex = 139;
            // 
            // panel53
            // 
            this.panel53.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel53.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel53.Location = new System.Drawing.Point(20, 215);
            this.panel53.Name = "panel53";
            this.panel53.Size = new System.Drawing.Size(337, 5);
            this.panel53.TabIndex = 147;
            // 
            // panel54
            // 
            this.panel54.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel54.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel54.Location = new System.Drawing.Point(19, 173);
            this.panel54.Name = "panel54";
            this.panel54.Size = new System.Drawing.Size(337, 5);
            this.panel54.TabIndex = 146;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(16, 193);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(107, 16);
            this.label41.TabIndex = 138;
            this.label41.Text = "Tamaño de Pedido";
            // 
            // panel55
            // 
            this.panel55.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel55.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel55.Location = new System.Drawing.Point(19, 130);
            this.panel55.Name = "panel55";
            this.panel55.Size = new System.Drawing.Size(337, 5);
            this.panel55.TabIndex = 145;
            // 
            // panel56
            // 
            this.panel56.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel56.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel56.Location = new System.Drawing.Point(19, 85);
            this.panel56.Name = "panel56";
            this.panel56.Size = new System.Drawing.Size(337, 5);
            this.panel56.TabIndex = 144;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(14, 62);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(70, 16);
            this.label42.TabIndex = 135;
            this.label42.Text = "Tipo de pan";
            // 
            // txtNotasModificar
            // 
            this.txtNotasModificar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNotasModificar.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNotasModificar.Location = new System.Drawing.Point(19, 346);
            this.txtNotasModificar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNotasModificar.Multiline = true;
            this.txtNotasModificar.Name = "txtNotasModificar";
            this.txtNotasModificar.Size = new System.Drawing.Size(338, 87);
            this.txtNotasModificar.TabIndex = 141;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(18, 328);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(38, 16);
            this.label43.TabIndex = 142;
            this.label43.Text = "Notas";
            // 
            // panel59
            // 
            this.panel59.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel59.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel59.Location = new System.Drawing.Point(22, 317);
            this.panel59.Name = "panel59";
            this.panel59.Size = new System.Drawing.Size(337, 5);
            this.panel59.TabIndex = 143;
            // 
            // txtTipodePanModificar
            // 
            this.txtTipodePanModificar.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTipodePanModificar.Location = new System.Drawing.Point(232, 59);
            this.txtTipodePanModificar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTipodePanModificar.Name = "txtTipodePanModificar";
            this.txtTipodePanModificar.Size = new System.Drawing.Size(121, 23);
            this.txtTipodePanModificar.TabIndex = 133;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(14, 291);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(104, 16);
            this.label50.TabIndex = 134;
            this.label50.Text = "Cantidad de pisos:";
            // 
            // PBMODIFICARPEDIDO
            // 
            this.PBMODIFICARPEDIDO.BackColor = System.Drawing.Color.Transparent;
            this.PBMODIFICARPEDIDO.ErrorImage = global::BakeBookerGUI_1._0.Properties.Resources.Logo_para_pastelería_postres_minimalista_rosa__1_;
            this.PBMODIFICARPEDIDO.InitialImage = global::BakeBookerGUI_1._0.Properties.Resources.Logo_para_pastelería_postres_minimalista_rosa__1_;
            this.PBMODIFICARPEDIDO.Location = new System.Drawing.Point(372, 212);
            this.PBMODIFICARPEDIDO.Margin = new System.Windows.Forms.Padding(4);
            this.PBMODIFICARPEDIDO.Name = "PBMODIFICARPEDIDO";
            this.PBMODIFICARPEDIDO.Size = new System.Drawing.Size(364, 221);
            this.PBMODIFICARPEDIDO.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.PBMODIFICARPEDIDO.TabIndex = 126;
            this.PBMODIFICARPEDIDO.TabStop = false;
            // 
            // btnSubirImagenModificar
            // 
            this.btnSubirImagenModificar.Font = new System.Drawing.Font("Gadugi", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubirImagenModificar.Image = global::BakeBookerGUI_1._0.Properties.Resources.camara_fotografica;
            this.btnSubirImagenModificar.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnSubirImagenModificar.Location = new System.Drawing.Point(372, 130);
            this.btnSubirImagenModificar.Name = "btnSubirImagenModificar";
            this.btnSubirImagenModificar.Size = new System.Drawing.Size(364, 71);
            this.btnSubirImagenModificar.TabIndex = 132;
            this.btnSubirImagenModificar.Text = "Subir Imagen";
            this.btnSubirImagenModificar.UseVisualStyleBackColor = true;
            this.btnSubirImagenModificar.Click += new System.EventHandler(this.btnSubirImagenModificar_Click);
            // 
            // Producto2
            // 
            this.Producto2.Controls.Add(this.textBox3);
            this.Producto2.Controls.Add(this.panel95);
            this.Producto2.Controls.Add(this.label84);
            this.Producto2.Controls.Add(this.textBox4);
            this.Producto2.Controls.Add(this.panel105);
            this.Producto2.Controls.Add(this.label86);
            this.Producto2.Controls.Add(this.txtIDPEDIDOPRODUCTOMODIFICAR);
            this.Producto2.Controls.Add(this.panel93);
            this.Producto2.Controls.Add(this.label81);
            this.Producto2.Controls.Add(this.txtIDPedidoModifcar);
            this.Producto2.Controls.Add(this.panel96);
            this.Producto2.Controls.Add(this.label85);
            this.Producto2.Controls.Add(this.txtIDPRODUCTOMODIFICAR);
            this.Producto2.Controls.Add(this.panel92);
            this.Producto2.Controls.Add(this.label80);
            this.Producto2.Controls.Add(this.label82);
            this.Producto2.Controls.Add(this.panel94);
            this.Producto2.Controls.Add(this.CBBCANTIDADMODIFICAR);
            this.Producto2.Location = new System.Drawing.Point(4, 23);
            this.Producto2.Name = "Producto2";
            this.Producto2.Size = new System.Drawing.Size(743, 442);
            this.Producto2.TabIndex = 2;
            this.Producto2.Text = "Producto";
            this.Producto2.UseVisualStyleBackColor = true;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(593, 34);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(122, 22);
            this.textBox3.TabIndex = 149;
            // 
            // panel95
            // 
            this.panel95.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel95.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel95.Location = new System.Drawing.Point(382, 62);
            this.panel95.Name = "panel95";
            this.panel95.Size = new System.Drawing.Size(337, 5);
            this.panel95.TabIndex = 148;
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label84.Location = new System.Drawing.Point(379, 36);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(56, 16);
            this.label84.TabIndex = 147;
            this.label84.Text = "Producto";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(593, 73);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(122, 22);
            this.textBox4.TabIndex = 146;
            // 
            // panel105
            // 
            this.panel105.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel105.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel105.Location = new System.Drawing.Point(382, 101);
            this.panel105.Name = "panel105";
            this.panel105.Size = new System.Drawing.Size(337, 5);
            this.panel105.TabIndex = 145;
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label86.Location = new System.Drawing.Point(379, 75);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(40, 16);
            this.label86.TabIndex = 144;
            this.label86.Text = "Precio";
            // 
            // txtIDPEDIDOPRODUCTOMODIFICAR
            // 
            this.txtIDPEDIDOPRODUCTOMODIFICAR.Location = new System.Drawing.Point(227, 34);
            this.txtIDPEDIDOPRODUCTOMODIFICAR.Name = "txtIDPEDIDOPRODUCTOMODIFICAR";
            this.txtIDPEDIDOPRODUCTOMODIFICAR.Size = new System.Drawing.Size(122, 22);
            this.txtIDPEDIDOPRODUCTOMODIFICAR.TabIndex = 143;
            // 
            // panel93
            // 
            this.panel93.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel93.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel93.Location = new System.Drawing.Point(16, 62);
            this.panel93.Name = "panel93";
            this.panel93.Size = new System.Drawing.Size(337, 5);
            this.panel93.TabIndex = 142;
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label81.Location = new System.Drawing.Point(13, 36);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(131, 16);
            this.label81.TabIndex = 141;
            this.label81.Text = "ID del Pedido-producto";
            // 
            // txtIDPedidoModifcar
            // 
            this.txtIDPedidoModifcar.Location = new System.Drawing.Point(227, 73);
            this.txtIDPedidoModifcar.Name = "txtIDPedidoModifcar";
            this.txtIDPedidoModifcar.Size = new System.Drawing.Size(122, 22);
            this.txtIDPedidoModifcar.TabIndex = 140;
            // 
            // panel96
            // 
            this.panel96.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel96.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel96.Location = new System.Drawing.Point(16, 101);
            this.panel96.Name = "panel96";
            this.panel96.Size = new System.Drawing.Size(337, 5);
            this.panel96.TabIndex = 139;
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label85.Location = new System.Drawing.Point(13, 75);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(58, 16);
            this.label85.TabIndex = 138;
            this.label85.Text = "ID Pedido";
            // 
            // txtIDPRODUCTOMODIFICAR
            // 
            this.txtIDPRODUCTOMODIFICAR.Location = new System.Drawing.Point(227, 139);
            this.txtIDPRODUCTOMODIFICAR.Name = "txtIDPRODUCTOMODIFICAR";
            this.txtIDPRODUCTOMODIFICAR.Size = new System.Drawing.Size(122, 22);
            this.txtIDPRODUCTOMODIFICAR.TabIndex = 137;
            // 
            // panel92
            // 
            this.panel92.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel92.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel92.Location = new System.Drawing.Point(16, 167);
            this.panel92.Name = "panel92";
            this.panel92.Size = new System.Drawing.Size(337, 5);
            this.panel92.TabIndex = 109;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label80.Location = new System.Drawing.Point(13, 141);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(70, 16);
            this.label80.TabIndex = 108;
            this.label80.Text = "ID producto";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label82.Location = new System.Drawing.Point(13, 199);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(55, 16);
            this.label82.TabIndex = 103;
            this.label82.Text = "Cantidad";
            // 
            // panel94
            // 
            this.panel94.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel94.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel94.Location = new System.Drawing.Point(13, 226);
            this.panel94.Name = "panel94";
            this.panel94.Size = new System.Drawing.Size(337, 5);
            this.panel94.TabIndex = 106;
            // 
            // CBBCANTIDADMODIFICAR
            // 
            this.CBBCANTIDADMODIFICAR.FormattingEnabled = true;
            this.CBBCANTIDADMODIFICAR.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.CBBCANTIDADMODIFICAR.Location = new System.Drawing.Point(227, 199);
            this.CBBCANTIDADMODIFICAR.Name = "CBBCANTIDADMODIFICAR";
            this.CBBCANTIDADMODIFICAR.Size = new System.Drawing.Size(122, 22);
            this.CBBCANTIDADMODIFICAR.TabIndex = 96;
            // 
            // btnModGen
            // 
            this.btnModGen.BackColor = System.Drawing.Color.Transparent;
            this.btnModGen.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnModGen.FlatAppearance.BorderSize = 0;
            this.btnModGen.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.btnModGen.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnModGen.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModGen.Image = global::BakeBookerGUI_1._0.Properties.Resources.conversion;
            this.btnModGen.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btnModGen.Location = new System.Drawing.Point(751, 23);
            this.btnModGen.Name = "btnModGen";
            this.btnModGen.Size = new System.Drawing.Size(164, 93);
            this.btnModGen.TabIndex = 4;
            this.btnModGen.Text = "Modificar";
            this.btnModGen.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnModGen.UseVisualStyleBackColor = false;
            this.btnModGen.Click += new System.EventHandler(this.btnModGen_Click);
            // 
            // btnEliminarGen
            // 
            this.btnEliminarGen.BackColor = System.Drawing.Color.Transparent;
            this.btnEliminarGen.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnEliminarGen.FlatAppearance.BorderSize = 0;
            this.btnEliminarGen.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.btnEliminarGen.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnEliminarGen.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEliminarGen.Image = global::BakeBookerGUI_1._0.Properties.Resources.contenedor_de_basura;
            this.btnEliminarGen.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btnEliminarGen.Location = new System.Drawing.Point(751, 369);
            this.btnEliminarGen.Name = "btnEliminarGen";
            this.btnEliminarGen.Size = new System.Drawing.Size(164, 93);
            this.btnEliminarGen.TabIndex = 3;
            this.btnEliminarGen.Text = "Eliminar";
            this.btnEliminarGen.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnEliminarGen.UseVisualStyleBackColor = false;
            this.btnEliminarGen.Click += new System.EventHandler(this.btnEliminarGen_Click);
            // 
            // panel60
            // 
            this.panel60.BackColor = System.Drawing.Color.White;
            this.panel60.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel60.Controls.Add(this.RADTELEFONOPEDIDO);
            this.panel60.Controls.Add(this.RADNOMBREPEDIDO);
            this.panel60.Controls.Add(this.DGVCLIENTEBUSQUEDA);
            this.panel60.Controls.Add(this.btnBuscarPedido);
            this.panel60.Controls.Add(this.label46);
            this.panel60.Controls.Add(this.txtBusquedaPedido);
            this.panel60.Controls.Add(this.panel61);
            this.panel60.Controls.Add(this.pictureBox4);
            this.panel60.Location = new System.Drawing.Point(2, 5);
            this.panel60.Name = "panel60";
            this.panel60.Size = new System.Drawing.Size(454, 251);
            this.panel60.TabIndex = 0;
            // 
            // RADTELEFONOPEDIDO
            // 
            this.RADTELEFONOPEDIDO.AutoSize = true;
            this.RADTELEFONOPEDIDO.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RADTELEFONOPEDIDO.Location = new System.Drawing.Point(125, 37);
            this.RADTELEFONOPEDIDO.Name = "RADTELEFONOPEDIDO";
            this.RADTELEFONOPEDIDO.Size = new System.Drawing.Size(89, 23);
            this.RADTELEFONOPEDIDO.TabIndex = 21;
            this.RADTELEFONOPEDIDO.Text = "Telefono";
            this.RADTELEFONOPEDIDO.UseVisualStyleBackColor = true;
            // 
            // RADNOMBREPEDIDO
            // 
            this.RADNOMBREPEDIDO.AutoSize = true;
            this.RADNOMBREPEDIDO.Font = new System.Drawing.Font("Gadugi", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RADNOMBREPEDIDO.Location = new System.Drawing.Point(22, 37);
            this.RADNOMBREPEDIDO.Name = "RADNOMBREPEDIDO";
            this.RADNOMBREPEDIDO.Size = new System.Drawing.Size(85, 23);
            this.RADNOMBREPEDIDO.TabIndex = 20;
            this.RADNOMBREPEDIDO.Text = "Nombre";
            this.RADNOMBREPEDIDO.UseVisualStyleBackColor = true;
            // 
            // DGVCLIENTEBUSQUEDA
            // 
            this.DGVCLIENTEBUSQUEDA.AllowUserToAddRows = false;
            this.DGVCLIENTEBUSQUEDA.AllowUserToDeleteRows = false;
            this.DGVCLIENTEBUSQUEDA.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DGVCLIENTEBUSQUEDA.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.DGVCLIENTEBUSQUEDA.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DGVCLIENTEBUSQUEDA.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.DGVCLIENTEBUSQUEDA.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
            this.DGVCLIENTEBUSQUEDA.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.DGVCLIENTEBUSQUEDA.ColumnHeadersHeight = 29;
            this.DGVCLIENTEBUSQUEDA.Location = new System.Drawing.Point(7, 145);
            this.DGVCLIENTEBUSQUEDA.Name = "DGVCLIENTEBUSQUEDA";
            this.DGVCLIENTEBUSQUEDA.ReadOnly = true;
            this.DGVCLIENTEBUSQUEDA.RowHeadersWidth = 51;
            this.DGVCLIENTEBUSQUEDA.RowTemplate.Height = 24;
            this.DGVCLIENTEBUSQUEDA.Size = new System.Drawing.Size(438, 87);
            this.DGVCLIENTEBUSQUEDA.TabIndex = 46;
            this.DGVCLIENTEBUSQUEDA.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVCLIENTEBUSQUEDA_CellClick);
            // 
            // btnBuscarPedido
            // 
            this.btnBuscarPedido.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarPedido.Image = global::BakeBookerGUI_1._0.Properties.Resources.ciencias_sociales__1_;
            this.btnBuscarPedido.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBuscarPedido.Location = new System.Drawing.Point(291, 63);
            this.btnBuscarPedido.Name = "btnBuscarPedido";
            this.btnBuscarPedido.Size = new System.Drawing.Size(152, 65);
            this.btnBuscarPedido.TabIndex = 18;
            this.btnBuscarPedido.Text = "Buscar";
            this.btnBuscarPedido.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBuscarPedido.UseVisualStyleBackColor = true;
            this.btnBuscarPedido.Click += new System.EventHandler(this.btnBuscarPedido_Click);
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Gadugi", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(18, 10);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(121, 19);
            this.label46.TabIndex = 17;
            this.label46.Text = "Ingrese cliente";
            // 
            // txtBusquedaPedido
            // 
            this.txtBusquedaPedido.AccessibleDescription = "Ingresar usuario";
            this.txtBusquedaPedido.AccessibleName = "Ingresa usuario";
            this.txtBusquedaPedido.AccessibleRole = System.Windows.Forms.AccessibleRole.Text;
            this.txtBusquedaPedido.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtBusquedaPedido.BackColor = System.Drawing.Color.White;
            this.txtBusquedaPedido.Font = new System.Drawing.Font("Nirmala UI", 14F, System.Drawing.FontStyle.Bold);
            this.txtBusquedaPedido.ForeColor = System.Drawing.Color.Black;
            this.txtBusquedaPedido.Location = new System.Drawing.Point(53, 96);
            this.txtBusquedaPedido.Margin = new System.Windows.Forms.Padding(0);
            this.txtBusquedaPedido.Name = "txtBusquedaPedido";
            this.txtBusquedaPedido.Size = new System.Drawing.Size(161, 32);
            this.txtBusquedaPedido.TabIndex = 14;
            this.txtBusquedaPedido.Tag = "";
            this.txtBusquedaPedido.UseWaitCursor = true;
            // 
            // panel61
            // 
            this.panel61.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel61.Location = new System.Drawing.Point(7, 134);
            this.panel61.Name = "panel61";
            this.panel61.Size = new System.Drawing.Size(434, 5);
            this.panel61.TabIndex = 16;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::BakeBookerGUI_1._0.Properties.Resources.usuario__3_;
            this.pictureBox4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox4.Location = new System.Drawing.Point(7, 90);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(43, 39);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 15;
            this.pictureBox4.TabStop = false;
            // 
            // panel40
            // 
            this.panel40.BackColor = System.Drawing.Color.White;
            this.panel40.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel40.Controls.Add(this.panel41);
            this.panel40.Controls.Add(this.panel42);
            this.panel40.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel40.Location = new System.Drawing.Point(3, 3);
            this.panel40.Name = "panel40";
            this.panel40.Size = new System.Drawing.Size(1389, 80);
            this.panel40.TabIndex = 2;
            // 
            // panel41
            // 
            this.panel41.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel41.Controls.Add(this.btnBEMPedidos);
            this.panel41.Location = new System.Drawing.Point(211, 3);
            this.panel41.Name = "panel41";
            this.panel41.Size = new System.Drawing.Size(239, 76);
            this.panel41.TabIndex = 1;
            // 
            // btnBEMPedidos
            // 
            this.btnBEMPedidos.BackColor = System.Drawing.Color.Transparent;
            this.btnBEMPedidos.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnBEMPedidos.FlatAppearance.BorderSize = 0;
            this.btnBEMPedidos.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.btnBEMPedidos.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBEMPedidos.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBEMPedidos.Image = global::BakeBookerGUI_1._0.Properties.Resources.personalizacion;
            this.btnBEMPedidos.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btnBEMPedidos.Location = new System.Drawing.Point(3, 3);
            this.btnBEMPedidos.Name = "btnBEMPedidos";
            this.btnBEMPedidos.Size = new System.Drawing.Size(229, 70);
            this.btnBEMPedidos.TabIndex = 2;
            this.btnBEMPedidos.Text = "Buscar, Eliminar o Modificar Pedido";
            this.btnBEMPedidos.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnBEMPedidos.UseVisualStyleBackColor = false;
            this.btnBEMPedidos.Click += new System.EventHandler(this.btnBEMPedidos_Click);
            // 
            // panel42
            // 
            this.panel42.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel42.Controls.Add(this.btnIniciarPedido);
            this.panel42.Location = new System.Drawing.Point(4, 3);
            this.panel42.Name = "panel42";
            this.panel42.Size = new System.Drawing.Size(201, 76);
            this.panel42.TabIndex = 2;
            // 
            // btnIniciarPedido
            // 
            this.btnIniciarPedido.BackColor = System.Drawing.Color.Transparent;
            this.btnIniciarPedido.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnIniciarPedido.FlatAppearance.BorderSize = 0;
            this.btnIniciarPedido.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.btnIniciarPedido.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnIniciarPedido.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIniciarPedido.Image = global::BakeBookerGUI_1._0.Properties.Resources.usuario__4_;
            this.btnIniciarPedido.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btnIniciarPedido.Location = new System.Drawing.Point(3, 3);
            this.btnIniciarPedido.Name = "btnIniciarPedido";
            this.btnIniciarPedido.Size = new System.Drawing.Size(192, 70);
            this.btnIniciarPedido.TabIndex = 2;
            this.btnIniciarPedido.Text = "Iniciar Pedido";
            this.btnIniciarPedido.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnIniciarPedido.UseVisualStyleBackColor = false;
            // 
            // tabProductos
            // 
            this.tabProductos.Controls.Add(this.panel97);
            this.tabProductos.Controls.Add(this.panel75);
            this.tabProductos.Location = new System.Drawing.Point(4, 25);
            this.tabProductos.Name = "tabProductos";
            this.tabProductos.Padding = new System.Windows.Forms.Padding(3);
            this.tabProductos.Size = new System.Drawing.Size(1395, 759);
            this.tabProductos.TabIndex = 2;
            this.tabProductos.Text = "Productos";
            this.tabProductos.UseVisualStyleBackColor = true;
            // 
            // panel97
            // 
            this.panel97.BackColor = System.Drawing.Color.White;
            this.panel97.Controls.Add(this.btnModificarProducto2);
            this.panel97.Controls.Add(this.btnAgregarProducto);
            this.panel97.Location = new System.Drawing.Point(3, 9);
            this.panel97.Name = "panel97";
            this.panel97.Size = new System.Drawing.Size(770, 83);
            this.panel97.TabIndex = 49;
            // 
            // btnModificarProducto2
            // 
            this.btnModificarProducto2.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModificarProducto2.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnModificarProducto2.Location = new System.Drawing.Point(381, 3);
            this.btnModificarProducto2.Name = "btnModificarProducto2";
            this.btnModificarProducto2.Size = new System.Drawing.Size(381, 71);
            this.btnModificarProducto2.TabIndex = 45;
            this.btnModificarProducto2.Text = "Modificar, Eliminar Producto";
            this.btnModificarProducto2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnModificarProducto2.UseVisualStyleBackColor = true;
            this.btnModificarProducto2.Click += new System.EventHandler(this.btnModificarProducto2_Click);
            // 
            // btnAgregarProducto
            // 
            this.btnAgregarProducto.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAgregarProducto.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAgregarProducto.Location = new System.Drawing.Point(7, 3);
            this.btnAgregarProducto.Name = "btnAgregarProducto";
            this.btnAgregarProducto.Size = new System.Drawing.Size(372, 71);
            this.btnAgregarProducto.TabIndex = 44;
            this.btnAgregarProducto.Text = "Agregar Producto";
            this.btnAgregarProducto.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAgregarProducto.UseVisualStyleBackColor = true;
            this.btnAgregarProducto.Click += new System.EventHandler(this.btnAgregarProducto_Click);
            // 
            // panel75
            // 
            this.panel75.BackColor = System.Drawing.Color.LightCoral;
            this.panel75.Controls.Add(this.TABCONTROLPRODUCTO);
            this.panel75.Controls.Add(this.dgvResultadoProductos);
            this.panel75.Location = new System.Drawing.Point(4, 6);
            this.panel75.Name = "panel75";
            this.panel75.Size = new System.Drawing.Size(1391, 694);
            this.panel75.TabIndex = 6;
            // 
            // TABCONTROLPRODUCTO
            // 
            this.TABCONTROLPRODUCTO.Controls.Add(this.InsertarProducto);
            this.TABCONTROLPRODUCTO.Controls.Add(this.Modificar);
            this.TABCONTROLPRODUCTO.ItemSize = new System.Drawing.Size(10, 5);
            this.TABCONTROLPRODUCTO.Location = new System.Drawing.Point(3, 86);
            this.TABCONTROLPRODUCTO.Name = "TABCONTROLPRODUCTO";
            this.TABCONTROLPRODUCTO.SelectedIndex = 0;
            this.TABCONTROLPRODUCTO.Size = new System.Drawing.Size(766, 393);
            this.TABCONTROLPRODUCTO.TabIndex = 48;
            // 
            // InsertarProducto
            // 
            this.InsertarProducto.Controls.Add(this.PBInsertarImagenProducto);
            this.InsertarProducto.Controls.Add(this.btnAgregarImagenProducto);
            this.InsertarProducto.Controls.Add(this.label77);
            this.InsertarProducto.Controls.Add(this.txtNombreProducto);
            this.InsertarProducto.Controls.Add(this.button2);
            this.InsertarProducto.Controls.Add(this.txtPrecioProducto);
            this.InsertarProducto.Controls.Add(this.label89);
            this.InsertarProducto.Controls.Add(this.panel98);
            this.InsertarProducto.Controls.Add(this.label90);
            this.InsertarProducto.Controls.Add(this.DTPFechaExpiracionProducto);
            this.InsertarProducto.Controls.Add(this.label91);
            this.InsertarProducto.Controls.Add(this.label92);
            this.InsertarProducto.Controls.Add(this.txtDescripcionProducto);
            this.InsertarProducto.Controls.Add(this.panel99);
            this.InsertarProducto.Controls.Add(this.txtCantidadProducto);
            this.InsertarProducto.Controls.Add(this.DTPFechaIngresoProducto);
            this.InsertarProducto.Controls.Add(this.label93);
            this.InsertarProducto.Controls.Add(this.label94);
            this.InsertarProducto.Controls.Add(this.panel100);
            this.InsertarProducto.Controls.Add(this.panel101);
            this.InsertarProducto.Controls.Add(this.panel102);
            this.InsertarProducto.Controls.Add(this.panel103);
            this.InsertarProducto.Location = new System.Drawing.Point(4, 9);
            this.InsertarProducto.Name = "InsertarProducto";
            this.InsertarProducto.Padding = new System.Windows.Forms.Padding(3);
            this.InsertarProducto.Size = new System.Drawing.Size(758, 380);
            this.InsertarProducto.TabIndex = 0;
            this.InsertarProducto.Text = "INSERTARPRODUCTO";
            this.InsertarProducto.UseVisualStyleBackColor = true;
            // 
            // PBInsertarImagenProducto
            // 
            this.PBInsertarImagenProducto.BackColor = System.Drawing.Color.Transparent;
            this.PBInsertarImagenProducto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PBInsertarImagenProducto.ErrorImage = global::BakeBookerGUI_1._0.Properties.Resources.Logo_para_pastelería_postres_minimalista_rosa__1_;
            this.PBInsertarImagenProducto.InitialImage = global::BakeBookerGUI_1._0.Properties.Resources.Logo_para_pastelería_postres_minimalista_rosa__1_;
            this.PBInsertarImagenProducto.Location = new System.Drawing.Point(504, 152);
            this.PBInsertarImagenProducto.Margin = new System.Windows.Forms.Padding(4);
            this.PBInsertarImagenProducto.Name = "PBInsertarImagenProducto";
            this.PBInsertarImagenProducto.Size = new System.Drawing.Size(247, 221);
            this.PBInsertarImagenProducto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.PBInsertarImagenProducto.TabIndex = 64;
            this.PBInsertarImagenProducto.TabStop = false;
            // 
            // btnAgregarImagenProducto
            // 
            this.btnAgregarImagenProducto.Font = new System.Drawing.Font("Gadugi", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAgregarImagenProducto.Image = global::BakeBookerGUI_1._0.Properties.Resources.camara_fotografica;
            this.btnAgregarImagenProducto.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnAgregarImagenProducto.Location = new System.Drawing.Point(504, 69);
            this.btnAgregarImagenProducto.Name = "btnAgregarImagenProducto";
            this.btnAgregarImagenProducto.Size = new System.Drawing.Size(245, 71);
            this.btnAgregarImagenProducto.TabIndex = 65;
            this.btnAgregarImagenProducto.Text = "Subir Imagen";
            this.btnAgregarImagenProducto.UseVisualStyleBackColor = true;
            this.btnAgregarImagenProducto.Click += new System.EventHandler(this.btnAgregarImagenProducto_Click);
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Font = new System.Drawing.Font("Gadugi", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label77.Location = new System.Drawing.Point(6, 19);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(205, 19);
            this.label77.TabIndex = 62;
            this.label77.Text = "Información del Producto";
            // 
            // txtNombreProducto
            // 
            this.txtNombreProducto.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombreProducto.Location = new System.Drawing.Point(304, 45);
            this.txtNombreProducto.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNombreProducto.Name = "txtNombreProducto";
            this.txtNombreProducto.Size = new System.Drawing.Size(189, 23);
            this.txtNombreProducto.TabIndex = 46;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button2.Location = new System.Drawing.Point(18, 301);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(180, 71);
            this.button2.TabIndex = 63;
            this.button2.Text = "Agregar Producto";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // txtPrecioProducto
            // 
            this.txtPrecioProducto.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrecioProducto.Location = new System.Drawing.Point(304, 136);
            this.txtPrecioProducto.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtPrecioProducto.Name = "txtPrecioProducto";
            this.txtPrecioProducto.Size = new System.Drawing.Size(189, 23);
            this.txtPrecioProducto.TabIndex = 45;
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label89.Location = new System.Drawing.Point(15, 54);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(59, 16);
            this.label89.TabIndex = 49;
            this.label89.Text = "NOMBRE:";
            // 
            // panel98
            // 
            this.panel98.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel98.Location = new System.Drawing.Point(21, 285);
            this.panel98.Name = "panel98";
            this.panel98.Size = new System.Drawing.Size(476, 10);
            this.panel98.TabIndex = 61;
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label90.Location = new System.Drawing.Point(15, 139);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(50, 16);
            this.label90.TabIndex = 48;
            this.label90.Text = "PRECIO:";
            // 
            // DTPFechaExpiracionProducto
            // 
            this.DTPFechaExpiracionProducto.Location = new System.Drawing.Point(304, 260);
            this.DTPFechaExpiracionProducto.Margin = new System.Windows.Forms.Padding(4);
            this.DTPFechaExpiracionProducto.Name = "DTPFechaExpiracionProducto";
            this.DTPFechaExpiracionProducto.Size = new System.Drawing.Size(193, 20);
            this.DTPFechaExpiracionProducto.TabIndex = 60;
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label91.Location = new System.Drawing.Point(15, 101);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(81, 16);
            this.label91.TabIndex = 47;
            this.label91.Text = "DESCRIPCION";
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Location = new System.Drawing.Point(18, 266);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(110, 13);
            this.label92.TabIndex = 59;
            this.label92.Text = "FECHA EXPIRACION";
            // 
            // txtDescripcionProducto
            // 
            this.txtDescripcionProducto.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDescripcionProducto.Location = new System.Drawing.Point(304, 91);
            this.txtDescripcionProducto.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtDescripcionProducto.Name = "txtDescripcionProducto";
            this.txtDescripcionProducto.Size = new System.Drawing.Size(189, 23);
            this.txtDescripcionProducto.TabIndex = 44;
            // 
            // panel99
            // 
            this.panel99.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel99.Location = new System.Drawing.Point(19, 237);
            this.panel99.Name = "panel99";
            this.panel99.Size = new System.Drawing.Size(477, 10);
            this.panel99.TabIndex = 57;
            // 
            // txtCantidadProducto
            // 
            this.txtCantidadProducto.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCantidadProducto.Location = new System.Drawing.Point(304, 172);
            this.txtCantidadProducto.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCantidadProducto.Name = "txtCantidadProducto";
            this.txtCantidadProducto.Size = new System.Drawing.Size(192, 23);
            this.txtCantidadProducto.TabIndex = 50;
            // 
            // DTPFechaIngresoProducto
            // 
            this.DTPFechaIngresoProducto.Location = new System.Drawing.Point(304, 215);
            this.DTPFechaIngresoProducto.Margin = new System.Windows.Forms.Padding(4);
            this.DTPFechaIngresoProducto.Name = "DTPFechaIngresoProducto";
            this.DTPFechaIngresoProducto.Size = new System.Drawing.Size(192, 20);
            this.DTPFechaIngresoProducto.TabIndex = 58;
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label93.Location = new System.Drawing.Point(15, 175);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(69, 16);
            this.label93.TabIndex = 51;
            this.label93.Text = "CANTIDAD:";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Location = new System.Drawing.Point(18, 215);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(94, 13);
            this.label94.TabIndex = 56;
            this.label94.Text = "FECHA INGRESO";
            // 
            // panel100
            // 
            this.panel100.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel100.Location = new System.Drawing.Point(19, 76);
            this.panel100.Name = "panel100";
            this.panel100.Size = new System.Drawing.Size(474, 5);
            this.panel100.TabIndex = 52;
            // 
            // panel101
            // 
            this.panel101.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel101.Location = new System.Drawing.Point(19, 197);
            this.panel101.Name = "panel101";
            this.panel101.Size = new System.Drawing.Size(477, 5);
            this.panel101.TabIndex = 55;
            // 
            // panel102
            // 
            this.panel102.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel102.Location = new System.Drawing.Point(19, 123);
            this.panel102.Name = "panel102";
            this.panel102.Size = new System.Drawing.Size(474, 5);
            this.panel102.TabIndex = 53;
            // 
            // panel103
            // 
            this.panel103.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel103.Location = new System.Drawing.Point(19, 159);
            this.panel103.Name = "panel103";
            this.panel103.Size = new System.Drawing.Size(477, 5);
            this.panel103.TabIndex = 54;
            // 
            // Modificar
            // 
            this.Modificar.BackColor = System.Drawing.Color.White;
            this.Modificar.Controls.Add(this.PBProductoModificar);
            this.Modificar.Controls.Add(this.btnModificarImagenproducto);
            this.Modificar.Controls.Add(this.lblIDProducto2);
            this.Modificar.Controls.Add(this.btnModificarProducto);
            this.Modificar.Controls.Add(this.label65);
            this.Modificar.Controls.Add(this.btnEliminarProducto);
            this.Modificar.Controls.Add(this.txtNombreProducto2);
            this.Modificar.Controls.Add(this.txtPrecioProducto2);
            this.Modificar.Controls.Add(this.label71);
            this.Modificar.Controls.Add(this.panel77);
            this.Modificar.Controls.Add(this.label70);
            this.Modificar.Controls.Add(this.DTPFecha_expiracion);
            this.Modificar.Controls.Add(this.label69);
            this.Modificar.Controls.Add(this.label66);
            this.Modificar.Controls.Add(this.txtDescripcionProducto2);
            this.Modificar.Controls.Add(this.panel76);
            this.Modificar.Controls.Add(this.txtCantidadProducto2);
            this.Modificar.Controls.Add(this.DTPFecha_ingreso);
            this.Modificar.Controls.Add(this.label68);
            this.Modificar.Controls.Add(this.label67);
            this.Modificar.Controls.Add(this.panel81);
            this.Modificar.Controls.Add(this.panel78);
            this.Modificar.Controls.Add(this.panel80);
            this.Modificar.Controls.Add(this.panel79);
            this.Modificar.Location = new System.Drawing.Point(4, 9);
            this.Modificar.Name = "Modificar";
            this.Modificar.Padding = new System.Windows.Forms.Padding(3);
            this.Modificar.Size = new System.Drawing.Size(758, 380);
            this.Modificar.TabIndex = 1;
            this.Modificar.Text = "Modificar";
            // 
            // PBProductoModificar
            // 
            this.PBProductoModificar.BackColor = System.Drawing.Color.Transparent;
            this.PBProductoModificar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PBProductoModificar.ErrorImage = global::BakeBookerGUI_1._0.Properties.Resources.Logo_para_pastelería_postres_minimalista_rosa__1_;
            this.PBProductoModificar.InitialImage = global::BakeBookerGUI_1._0.Properties.Resources.Logo_para_pastelería_postres_minimalista_rosa__1_;
            this.PBProductoModificar.Location = new System.Drawing.Point(507, 152);
            this.PBProductoModificar.Margin = new System.Windows.Forms.Padding(4);
            this.PBProductoModificar.Name = "PBProductoModificar";
            this.PBProductoModificar.Size = new System.Drawing.Size(247, 221);
            this.PBProductoModificar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.PBProductoModificar.TabIndex = 49;
            this.PBProductoModificar.TabStop = false;
            // 
            // btnModificarImagenproducto
            // 
            this.btnModificarImagenproducto.Font = new System.Drawing.Font("Gadugi", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModificarImagenproducto.Image = global::BakeBookerGUI_1._0.Properties.Resources.camara_fotografica;
            this.btnModificarImagenproducto.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnModificarImagenproducto.Location = new System.Drawing.Point(507, 69);
            this.btnModificarImagenproducto.Name = "btnModificarImagenproducto";
            this.btnModificarImagenproducto.Size = new System.Drawing.Size(245, 71);
            this.btnModificarImagenproducto.TabIndex = 50;
            this.btnModificarImagenproducto.Text = "Subir Imagen";
            this.btnModificarImagenproducto.UseVisualStyleBackColor = true;
            this.btnModificarImagenproducto.Click += new System.EventHandler(this.btnModificarImagenproducto_Click);
            // 
            // lblIDProducto2
            // 
            this.lblIDProducto2.AutoSize = true;
            this.lblIDProducto2.Location = new System.Drawing.Point(460, 18);
            this.lblIDProducto2.Name = "lblIDProducto2";
            this.lblIDProducto2.Size = new System.Drawing.Size(0, 13);
            this.lblIDProducto2.TabIndex = 48;
            // 
            // btnModificarProducto
            // 
            this.btnModificarProducto.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModificarProducto.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnModificarProducto.Location = new System.Drawing.Point(2, 303);
            this.btnModificarProducto.Name = "btnModificarProducto";
            this.btnModificarProducto.Size = new System.Drawing.Size(255, 71);
            this.btnModificarProducto.TabIndex = 47;
            this.btnModificarProducto.Text = "Modificar Producto";
            this.btnModificarProducto.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnModificarProducto.UseVisualStyleBackColor = true;
            this.btnModificarProducto.Click += new System.EventHandler(this.btnModificarProducto_Click);
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Gadugi", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.Location = new System.Drawing.Point(6, 14);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(205, 19);
            this.label65.TabIndex = 42;
            this.label65.Text = "Información del Producto";
            // 
            // btnEliminarProducto
            // 
            this.btnEliminarProducto.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEliminarProducto.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEliminarProducto.Location = new System.Drawing.Point(263, 303);
            this.btnEliminarProducto.Name = "btnEliminarProducto";
            this.btnEliminarProducto.Size = new System.Drawing.Size(241, 71);
            this.btnEliminarProducto.TabIndex = 46;
            this.btnEliminarProducto.Text = "Eliminar Producto";
            this.btnEliminarProducto.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEliminarProducto.UseVisualStyleBackColor = true;
            this.btnEliminarProducto.Click += new System.EventHandler(this.btnEliminarProducto_Click);
            // 
            // txtNombreProducto2
            // 
            this.txtNombreProducto2.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombreProducto2.Location = new System.Drawing.Point(303, 43);
            this.txtNombreProducto2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNombreProducto2.Name = "txtNombreProducto2";
            this.txtNombreProducto2.Size = new System.Drawing.Size(198, 23);
            this.txtNombreProducto2.TabIndex = 27;
            // 
            // txtPrecioProducto2
            // 
            this.txtPrecioProducto2.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrecioProducto2.Location = new System.Drawing.Point(303, 134);
            this.txtPrecioProducto2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtPrecioProducto2.Name = "txtPrecioProducto2";
            this.txtPrecioProducto2.Size = new System.Drawing.Size(198, 23);
            this.txtPrecioProducto2.TabIndex = 26;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label71.Location = new System.Drawing.Point(2, 52);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(59, 16);
            this.label71.TabIndex = 30;
            this.label71.Text = "NOMBRE:";
            // 
            // panel77
            // 
            this.panel77.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel77.Location = new System.Drawing.Point(8, 267);
            this.panel77.Name = "panel77";
            this.panel77.Size = new System.Drawing.Size(492, 10);
            this.panel77.TabIndex = 41;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.Location = new System.Drawing.Point(2, 137);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(50, 16);
            this.label70.TabIndex = 29;
            this.label70.Text = "PRECIO:";
            // 
            // DTPFecha_expiracion
            // 
            this.DTPFecha_expiracion.Location = new System.Drawing.Point(303, 248);
            this.DTPFecha_expiracion.Margin = new System.Windows.Forms.Padding(4);
            this.DTPFecha_expiracion.Name = "DTPFecha_expiracion";
            this.DTPFecha_expiracion.Size = new System.Drawing.Size(197, 20);
            this.DTPFecha_expiracion.TabIndex = 40;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.Location = new System.Drawing.Point(2, 99);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(81, 16);
            this.label69.TabIndex = 28;
            this.label69.Text = "DESCRIPCION";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(5, 248);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(110, 13);
            this.label66.TabIndex = 39;
            this.label66.Text = "FECHA EXPIRACION";
            // 
            // txtDescripcionProducto2
            // 
            this.txtDescripcionProducto2.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDescripcionProducto2.Location = new System.Drawing.Point(303, 89);
            this.txtDescripcionProducto2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtDescripcionProducto2.Name = "txtDescripcionProducto2";
            this.txtDescripcionProducto2.Size = new System.Drawing.Size(198, 23);
            this.txtDescripcionProducto2.TabIndex = 25;
            // 
            // panel76
            // 
            this.panel76.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel76.Location = new System.Drawing.Point(6, 235);
            this.panel76.Name = "panel76";
            this.panel76.Size = new System.Drawing.Size(494, 10);
            this.panel76.TabIndex = 37;
            // 
            // txtCantidadProducto2
            // 
            this.txtCantidadProducto2.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCantidadProducto2.Location = new System.Drawing.Point(303, 173);
            this.txtCantidadProducto2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCantidadProducto2.Name = "txtCantidadProducto2";
            this.txtCantidadProducto2.Size = new System.Drawing.Size(198, 23);
            this.txtCantidadProducto2.TabIndex = 31;
            // 
            // DTPFecha_ingreso
            // 
            this.DTPFecha_ingreso.Location = new System.Drawing.Point(303, 213);
            this.DTPFecha_ingreso.Margin = new System.Windows.Forms.Padding(4);
            this.DTPFecha_ingreso.Name = "DTPFecha_ingreso";
            this.DTPFecha_ingreso.Size = new System.Drawing.Size(197, 20);
            this.DTPFecha_ingreso.TabIndex = 38;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Gadugi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.Location = new System.Drawing.Point(2, 173);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(69, 16);
            this.label68.TabIndex = 32;
            this.label68.Text = "CANTIDAD:";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(5, 213);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(94, 13);
            this.label67.TabIndex = 37;
            this.label67.Text = "FECHA INGRESO";
            // 
            // panel81
            // 
            this.panel81.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel81.Location = new System.Drawing.Point(6, 74);
            this.panel81.Name = "panel81";
            this.panel81.Size = new System.Drawing.Size(495, 10);
            this.panel81.TabIndex = 33;
            // 
            // panel78
            // 
            this.panel78.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel78.Location = new System.Drawing.Point(6, 195);
            this.panel78.Name = "panel78";
            this.panel78.Size = new System.Drawing.Size(495, 10);
            this.panel78.TabIndex = 36;
            // 
            // panel80
            // 
            this.panel80.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel80.Location = new System.Drawing.Point(6, 121);
            this.panel80.Name = "panel80";
            this.panel80.Size = new System.Drawing.Size(495, 10);
            this.panel80.TabIndex = 34;
            // 
            // panel79
            // 
            this.panel79.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.panel79.Location = new System.Drawing.Point(6, 157);
            this.panel79.Name = "panel79";
            this.panel79.Size = new System.Drawing.Size(495, 10);
            this.panel79.TabIndex = 35;
            // 
            // dgvResultadoProductos
            // 
            this.dgvResultadoProductos.AllowUserToAddRows = false;
            this.dgvResultadoProductos.AllowUserToDeleteRows = false;
            this.dgvResultadoProductos.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.dgvResultadoProductos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResultadoProductos.GridColor = System.Drawing.SystemColors.AppWorkspace;
            this.dgvResultadoProductos.Location = new System.Drawing.Point(775, 3);
            this.dgvResultadoProductos.Name = "dgvResultadoProductos";
            this.dgvResultadoProductos.ReadOnly = true;
            this.dgvResultadoProductos.RowHeadersWidth = 51;
            this.dgvResultadoProductos.RowTemplate.Height = 24;
            this.dgvResultadoProductos.Size = new System.Drawing.Size(613, 476);
            this.dgvResultadoProductos.TabIndex = 7;
            this.dgvResultadoProductos.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvResultadoProductos_CellClick);
            // 
            // tabReportes
            // 
            this.tabReportes.Controls.Add(this.chart1);
            this.tabReportes.Location = new System.Drawing.Point(4, 25);
            this.tabReportes.Name = "tabReportes";
            this.tabReportes.Padding = new System.Windows.Forms.Padding(3);
            this.tabReportes.Size = new System.Drawing.Size(1395, 759);
            this.tabReportes.TabIndex = 3;
            this.tabReportes.Text = "Reportes";
            this.tabReportes.UseVisualStyleBackColor = true;
            // 
            // chart1
            // 
            chartArea3.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea3);
            this.chart1.Cursor = System.Windows.Forms.Cursors.Default;
            legend3.Name = "Legend1";
            this.chart1.Legends.Add(legend3);
            this.chart1.Location = new System.Drawing.Point(26, 23);
            this.chart1.Name = "chart1";
            this.chart1.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Fire;
            series3.ChartArea = "ChartArea1";
            series3.IsVisibleInLegend = false;
            series3.IsXValueIndexed = true;
            series3.Legend = "Legend1";
            series3.Name = "Mes";
            this.chart1.Series.Add(series3);
            this.chart1.Size = new System.Drawing.Size(589, 328);
            this.chart1.TabIndex = 0;
            this.chart1.Text = "chart1";
            // 
            // tabPage5
            // 
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(1395, 759);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Información Personal";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label95.Location = new System.Drawing.Point(168, 46);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(108, 17);
            this.label95.TabIndex = 54;
            this.label95.Text = "Fecha de pedido";
            // 
            // DTPfechadepedido
            // 
            this.DTPfechadepedido.Font = new System.Drawing.Font("Gadugi", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DTPfechadepedido.Location = new System.Drawing.Point(171, 67);
            this.DTPfechadepedido.Name = "DTPfechadepedido";
            this.DTPfechadepedido.Size = new System.Drawing.Size(159, 26);
            this.DTPfechadepedido.TabIndex = 53;
            // 
            // frmADMIN
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1406, 819);
            this.Controls.Add(this.tabCentral);
            this.Controls.Add(this.panelCentral);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmADMIN";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BakeBooker";
            this.Load += new System.EventHandler(this.frmADMIN_Load);
            this.panelHome.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxHome)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panelCentral.ResumeLayout(false);
            this.panel19.ResumeLayout(false);
            this.tabCentral.ResumeLayout(false);
            this.tabHome.ResumeLayout(false);
            this.tabHome.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabEmpleados.ResumeLayout(false);
            this.panelEmpleados.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.tabEmpleado.ResumeLayout(false);
            this.tabEmpleadoNuevo.ResumeLayout(false);
            this.panelNuevoEmpleado.ResumeLayout(false);
            this.panelNuevoEmpleado.PerformLayout();
            this.tabEmpleadoBuscar.ResumeLayout(false);
            this.gbxMostrarEmpleados.ResumeLayout(false);
            this.gbxMostrarEmpleados.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResultadosEmpleados)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.tabClientes.ResumeLayout(false);
            this.panel21.ResumeLayout(false);
            this.tabCliente.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.panel30.ResumeLayout(false);
            this.panel30.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.gpbMostrarCliente.ResumeLayout(false);
            this.gpbMostrarCliente.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResultadosClientes)).EndInit();
            this.panel28.ResumeLayout(false);
            this.panel28.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel20.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            this.tabPedidos.ResumeLayout(false);
            this.tabPedido.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.panel85.ResumeLayout(false);
            this.panel85.PerformLayout();
            this.panel83.ResumeLayout(false);
            this.panel83.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel74.ResumeLayout(false);
            this.panel74.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVListaPedido)).EndInit();
            this.panel62.ResumeLayout(false);
            this.panel63.ResumeLayout(false);
            this.PanelPastel.ResumeLayout(false);
            this.PanelPastel.PerformLayout();
            this.PedidosYProductos.ResumeLayout(false);
            this.Pedido.ResumeLayout(false);
            this.Pedido.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxImagenPastel)).EndInit();
            this.Producto.ResumeLayout(false);
            this.Producto.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.panel43.ResumeLayout(false);
            this.panel43.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVPEDIDOINICIO)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.panel48.ResumeLayout(false);
            this.panel86.ResumeLayout(false);
            this.panel86.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVBUSQUEDAPEDIDO)).EndInit();
            this.panel87.ResumeLayout(false);
            this.panel87.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVBUSQUEDADETALLESPEDIDO)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.TABMODIFICARPEDIDO.ResumeLayout(false);
            this.Pedido2.ResumeLayout(false);
            this.Pedido2.PerformLayout();
            this.Orden2.ResumeLayout(false);
            this.Orden2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PBMODIFICARPEDIDO)).EndInit();
            this.Producto2.ResumeLayout(false);
            this.Producto2.PerformLayout();
            this.panel60.ResumeLayout(false);
            this.panel60.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVCLIENTEBUSQUEDA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panel40.ResumeLayout(false);
            this.panel41.ResumeLayout(false);
            this.panel42.ResumeLayout(false);
            this.tabProductos.ResumeLayout(false);
            this.panel97.ResumeLayout(false);
            this.panel75.ResumeLayout(false);
            this.TABCONTROLPRODUCTO.ResumeLayout(false);
            this.InsertarProducto.ResumeLayout(false);
            this.InsertarProducto.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PBInsertarImagenProducto)).EndInit();
            this.Modificar.ResumeLayout(false);
            this.Modificar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PBProductoModificar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResultadoProductos)).EndInit();
            this.tabReportes.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panelHome;
        private System.Windows.Forms.PictureBox pbxHome;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btnEmpleados;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnPedidos;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnProductos;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button btnReportes;
        private System.Windows.Forms.Panel panelCentral;
        private System.Windows.Forms.TabControl tabCentral;
        private System.Windows.Forms.TabPage tabEmpleados;
        private System.Windows.Forms.TabPage tabPedidos;
        private System.Windows.Forms.TabPage tabProductos;
        private System.Windows.Forms.TabPage tabReportes;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Panel panelEmpleados;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button btnEmpleadoNuevo;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnBEMempleado;
        private System.Windows.Forms.TabPage tabHome;
        private System.Windows.Forms.PictureBox pictureBox1;
        public System.Windows.Forms.Label labelBienvenida;
        private System.Windows.Forms.TabControl tabEmpleado;
        private System.Windows.Forms.TabPage tabEmpleadoBuscar;
        private System.Windows.Forms.GroupBox gbxMostrarEmpleados;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.RadioButton rdbGeneral;
        private System.Windows.Forms.TextBox txtApellidoEmpleado2;
        private System.Windows.Forms.RadioButton rdbAdmin;
        private System.Windows.Forms.TextBox txtNombreEmpleado2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnModificarEmpleado;
        private System.Windows.Forms.Button btnEliminarEmpleado;
        private System.Windows.Forms.DataGridView dgvResultadosEmpleados;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton radNombreEmpleado;
        private System.Windows.Forms.RadioButton radIDempleado;
        private System.Windows.Forms.Button btnBuscarEmpleado;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtBuscarEmpleado;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.TabPage tabEmpleadoNuevo;
        private System.Windows.Forms.Panel panelNuevoEmpleado;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Button btnCrearEmpleado;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton rbdGeneral;
        private System.Windows.Forms.TextBox txtApellidoEmpleado;
        private System.Windows.Forms.RadioButton rbdAdmin;
        private System.Windows.Forms.TextBox txtnombreEmpleado;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Button btnClientes;
        private System.Windows.Forms.TabPage tabClientes;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtContraseñaEmpleado2;
        private System.Windows.Forms.TextBox txtUsuarioEmpleado2;
        private System.Windows.Forms.TabControl tabCliente;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox gpbMostrarCliente;
        private System.Windows.Forms.Button btnModificarCliente;
        private System.Windows.Forms.Button btnEliminarCliente;
        private System.Windows.Forms.DataGridView dgvResultadosClientes;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.RadioButton radNombreCliente;
        private System.Windows.Forms.Button btnBuscarCliente;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtBuscarCliente;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.TextBox txtNumExteriorCliente;
        private System.Windows.Forms.TextBox txtCalleCliente;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtRFCCliente;
        private System.Windows.Forms.TextBox txtNumInteriorCliente;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.Button btnCrearCliente;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtApellidoCliente;
        private System.Windows.Forms.TextBox txtNombreCliente;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtTelefonoCliente;
        private System.Windows.Forms.TextBox txtCorreoCliente;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Button btnBEMclientes;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Button btnClienteNuevo;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.TextBox txtNumExteriorBCliente;
        private System.Windows.Forms.TextBox txtCalleBCliente;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtRFCBCliente;
        private System.Windows.Forms.TextBox txtNumInteriorBCliente;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Panel panel38;
        private System.Windows.Forms.Panel panel39;
        private System.Windows.Forms.TextBox txtApellidoBCliente;
        private System.Windows.Forms.TextBox txtNombreBCliente;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtTelefonoBCliente;
        private System.Windows.Forms.TextBox txtCorreoBCliente;
        private System.Windows.Forms.Panel panel40;
        private System.Windows.Forms.Panel panel41;
        private System.Windows.Forms.Button btnBEMPedidos;
        private System.Windows.Forms.Panel panel42;
        private System.Windows.Forms.Button btnIniciarPedido;
        private System.Windows.Forms.TabControl tabPedido;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Panel panel43;
        private System.Windows.Forms.DateTimePicker DTPFechaDeEntregaPedido;
        private System.Windows.Forms.Panel panel51;
        private System.Windows.Forms.Button btnPedidoPastel;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox txtNombreClientePedido;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnModGen;
        private System.Windows.Forms.Button btnEliminarGen;
        private System.Windows.Forms.Panel PanelPastel;
        private System.Windows.Forms.DataGridView DGVListaPedido;
        private System.Windows.Forms.PictureBox pbxImagenPastel;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtNotasPedido;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox txtCantidaddePersonas;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.ComboBox CBBCantdidadPisos;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox txtTipoDePan;
        private System.Windows.Forms.Button btnPedidoProducto;
        private System.Windows.Forms.Button btnCargarImagen;
        private System.Windows.Forms.Panel panel50;
        private System.Windows.Forms.Panel panel49;
        private System.Windows.Forms.Panel panel47;
        private System.Windows.Forms.Panel panel46;
        private System.Windows.Forms.Panel panel45;
        private System.Windows.Forms.Panel panel44;
        private System.Windows.Forms.Panel panel62;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Panel panel63;
        private System.Windows.Forms.Button btnAgregarAPedido;
        private System.Windows.Forms.Panel panel64;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox txtPrecioPastel;
        private System.Windows.Forms.Button btnTerminarPedido;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox txtPedidos_Anticipo;
        private System.Windows.Forms.RadioButton radiobuttonRecoger;
        private System.Windows.Forms.RadioButton radioButtonLlevar;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.DataGridView DGVPEDIDOINICIO;
        private System.Windows.Forms.Panel panel65;
        private System.Windows.Forms.TextBox txtIDBCliente;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Button btnBuscarClientePedido;
        private System.Windows.Forms.Panel panel66;
        private System.Windows.Forms.Panel panel67;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox txtContraseñaEmpleado;
        private System.Windows.Forms.TextBox txtUsuarioEmpleado;
        private System.Windows.Forms.Panel panel68;
        private System.Windows.Forms.TextBox txtIDEmpleado2;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TabControl PedidosYProductos;
        private System.Windows.Forms.TabPage Pedido;
        private System.Windows.Forms.TabPage Producto;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.TextBox TXTDescripcion;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.DataGridView dgvResultadoProductos;
        private System.Windows.Forms.Panel panel75;
        private System.Windows.Forms.Button btnModificarProducto;
        private System.Windows.Forms.Button btnEliminarProducto;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Panel panel77;
        private System.Windows.Forms.DateTimePicker DTPFecha_expiracion;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Panel panel76;
        private System.Windows.Forms.DateTimePicker DTPFecha_ingreso;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Panel panel78;
        private System.Windows.Forms.Panel panel79;
        private System.Windows.Forms.Panel panel80;
        private System.Windows.Forms.Panel panel81;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.TextBox txtCantidadProducto2;
        private System.Windows.Forms.TextBox txtDescripcionProducto2;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.TextBox txtPrecioProducto2;
        private System.Windows.Forms.TextBox txtNombreProducto2;
        private System.Windows.Forms.Label LBLCantidadDisponible;
        private System.Windows.Forms.Label LBLcostoUnitarioProducto;
        private System.Windows.Forms.Label LBLIDPRODUCTO;
        private System.Windows.Forms.ComboBox comboboxCantidadProducto;
        private System.Windows.Forms.ComboBox CBBNombreProducto;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Panel panel69;
        private System.Windows.Forms.Panel panel70;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Panel panel71;
        private System.Windows.Forms.Panel panel72;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Panel panel73;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Button btnCrearPedido;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Panel panel74;
        private System.Windows.Forms.Panel panel83;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label asdasdasd;
        private System.Windows.Forms.Panel panel85;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Panel panel86;
        private System.Windows.Forms.DataGridView DGVBUSQUEDAPEDIDO;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Panel panel87;
        private System.Windows.Forms.DataGridView DGVBUSQUEDADETALLESPEDIDO;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Button btnOrdenMod;
        private System.Windows.Forms.Button bntProductoMod;
        private System.Windows.Forms.DataGridView DGVCLIENTEBUSQUEDA;
        private System.Windows.Forms.Panel panel60;
        private System.Windows.Forms.RadioButton RADTELEFONOPEDIDO;
        private System.Windows.Forms.RadioButton RADNOMBREPEDIDO;
        private System.Windows.Forms.Button btnBuscarPedido;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox txtBusquedaPedido;
        private System.Windows.Forms.Panel panel61;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Panel panel48;
        private System.Windows.Forms.Button btnPedidoMod;
        private System.Windows.Forms.TabControl TABMODIFICARPEDIDO;
        private System.Windows.Forms.TabPage Pedido2;
        private System.Windows.Forms.Panel panel57;
        private System.Windows.Forms.Panel panel58;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TabPage Orden2;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TabPage Producto2;
        private System.Windows.Forms.Panel panel82;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.TextBox TXTANTICIPOMODIFICAR;
        private System.Windows.Forms.Panel panel84;
        private System.Windows.Forms.TextBox TXTTOTALMODIFICAR;
        private System.Windows.Forms.Panel panel88;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Panel panel89;
        private System.Windows.Forms.Panel panel90;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Panel panel91;
        private System.Windows.Forms.TextBox TXTIDCLIENTEMODIFICAR;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.PictureBox PBMODIFICARPEDIDO;
        private System.Windows.Forms.Button btnSubirImagenModificar;
        private System.Windows.Forms.Panel panel92;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Panel panel94;
        private System.Windows.Forms.ComboBox CBBCANTIDADMODIFICAR;
        private System.Windows.Forms.ComboBox CBBTamañoPedido;
        private System.Windows.Forms.ComboBox CBBRellenoPan;
        private System.Windows.Forms.ComboBox CBBTamañodePedidoModificar;
        private System.Windows.Forms.ComboBox CBBRellenodePanModificar;
        private System.Windows.Forms.Panel panel52;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ComboBox CBBCantidadDePisosModificar;
        private System.Windows.Forms.TextBox txtPrecioOrdenModificar;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox txtCantidadDePersonasModificar;
        private System.Windows.Forms.Panel panel53;
        private System.Windows.Forms.Panel panel54;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Panel panel55;
        private System.Windows.Forms.Panel panel56;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox txtNotasModificar;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Panel panel59;
        private System.Windows.Forms.TextBox txtTipodePanModificar;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Panel panel97;
        private System.Windows.Forms.TabControl TABCONTROLPRODUCTO;
        private System.Windows.Forms.TabPage InsertarProducto;
        private System.Windows.Forms.TabPage Modificar;
        private System.Windows.Forms.Button btnModificarProducto2;
        private System.Windows.Forms.Button btnAgregarProducto;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.TextBox txtNombreProducto;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox txtPrecioProducto;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Panel panel98;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.DateTimePicker DTPFechaExpiracionProducto;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.TextBox txtDescripcionProducto;
        private System.Windows.Forms.Panel panel99;
        private System.Windows.Forms.TextBox txtCantidadProducto;
        private System.Windows.Forms.DateTimePicker DTPFechaIngresoProducto;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Panel panel100;
        private System.Windows.Forms.Panel panel101;
        private System.Windows.Forms.Panel panel102;
        private System.Windows.Forms.Panel panel103;
        private System.Windows.Forms.TextBox txtIDPEDIDOMODIFICAR;
        private System.Windows.Forms.Panel panel104;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.TextBox txtIDPRODUCTOMODIFICAR;
        private System.Windows.Forms.TextBox txtIDPedidoModifcar;
        private System.Windows.Forms.Panel panel96;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.DateTimePicker DTPFECHAENTREGAMOD;
        private System.Windows.Forms.DateTimePicker DTPFECHAPEDIDOMODIFICAR;
        private System.Windows.Forms.RadioButton RADRECOGERMODIFICAR;
        private System.Windows.Forms.RadioButton RADLLEVARMODIFICAR;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox txtIDOrdenModificar;
        private System.Windows.Forms.TextBox txtIDPEDIDOPRODUCTOMODIFICAR;
        private System.Windows.Forms.Panel panel93;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Panel panel95;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Panel panel105;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Panel panel106;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.TextBox txtIDPEDIDOMODFICIAR;
        private System.Windows.Forms.Label lblIDProducto2;
        private System.Windows.Forms.PictureBox PBInsertarImagenProducto;
        private System.Windows.Forms.Button btnAgregarImagenProducto;
        private System.Windows.Forms.PictureBox PBProductoModificar;
        private System.Windows.Forms.Button btnModificarImagenproducto;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.DateTimePicker DTPfechadepedido;
    }
}